# Overview

This project is a Telegram Mini App (TMA) showcase and portfolio application demonstrating various business-focused demo applications. It acts as an "app within an app," allowing users to explore different demo projects, each simulating a complete business application (e.g., clothing stores, restaurants, fitness centers) with full functionality and dedicated navigation. The primary purpose is to showcase the capabilities of Telegram Mini Apps across diverse business verticals.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Frameworks**: React 18 with TypeScript, Vite.
- **Styling**: Tailwind CSS with custom CSS variables, Glassmorphism design pattern (dark theme, semi-transparent elements, accent colors).
- **UI Components**: Shadcn/ui (built on Radix UI), Lucide React for icons.
- **State Management**: React Query for server state management.
- **Design System**: Mobile-first, responsive design, Inter font, subtle CSS animations.
- **Structure**: Main App router, ShowcasePage for demo cards, DemoAppShell for universal navigation, and individual Demo Components for business simulations.
- **Navigation**: Comprehensive 4-level hash-based navigation system (ShowcasePage → ProjectsPage → DemoAppLanding → DemoAppShell).

## Backend Architecture
- **Server**: Express.js with TypeScript.
- **Database**: PostgreSQL with Drizzle ORM (type-safe operations).
- **Schema**: User management with username/password authentication structure.
- **Storage**: Abstracted storage interface supporting memory and database implementations.
- **API**: Endpoints for user project management (fetch, create, update status, initialize demo data).

## Technical Implementations
- **Telegram Integration**: Uses `@twa-dev/sdk` for native features and haptic feedback.
- **Data Management**: Static TypeScript objects for demo data, comprehensive TypeScript interfaces for type safety, external Unsplash URLs for imagery.
- **Project Management**: Dynamic user profile system with real project data management, tracking development stages (Paid → In Development → Ready).
- **Payment Integration**: Checkout automatically creates projects after successful payment.

# External Dependencies

- **React Ecosystem**: React, React DOM, TypeScript.
- **Build & Styling**: Vite, Tailwind CSS, PostCSS.
- **UI Libraries**: Radix UI, Shadcn/ui, Lucide React, Class Variance Authority.
- **Data Fetching**: @tanstack/react-query.
- **Telegram**: @twa-dev/sdk.
- **Backend**: Express.js, Drizzle ORM, @neondatabase/serverless (PostgreSQL connector), Zod (schema validation), Connect PG Simple.
- **Development Tools**: ESBuild, TSX.
- **Database**: PostgreSQL, Drizzle Kit.