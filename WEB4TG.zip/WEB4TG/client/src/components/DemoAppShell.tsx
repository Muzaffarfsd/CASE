import { useState } from "react";
import { ArrowLeft, Share2, Home, Grid3X3, ShoppingCart, User } from "lucide-react";
import { demoApps } from "../data/demoApps";
import { useTelegram } from "../hooks/useTelegram";
import ClothingStore from "./demos/ClothingStore";
import Restaurant from "./demos/Restaurant";
import Fitness from "./demos/Fitness";
import Coffee from "./demos/Coffee";
import Beauty from "./demos/Beauty";
import Electronics from "./demos/Electronics";
import Bookstore from "./demos/Bookstore";
import Florist from "./demos/Florist";
import CarWash from "./demos/CarWash";
import Courses from "./demos/Courses";
import Pharmacy from "./demos/Pharmacy";
import Realty from "./demos/Realty";
import Taxi from "./demos/Taxi";
import Banking from "./demos/Banking";
import Hotel from "./demos/Hotel";

interface DemoAppShellProps {
  demoId: string;
  onClose: () => void;
}

type TabType = 'home' | 'catalog' | 'cart' | 'profile';

const navItems: { id: TabType; icon: any; label: string }[] = [
  { id: 'home', icon: Home, label: 'Главная' },
  { id: 'catalog', icon: Grid3X3, label: 'Каталог' },
  { id: 'cart', icon: ShoppingCart, label: 'Корзина' },
  { id: 'profile', icon: User, label: 'Профиль' },
];

export default function DemoAppShell({ demoId, onClose }: DemoAppShellProps) {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const { hapticFeedback } = useTelegram();
  
  // Extract base app type from ID to support variants (e.g., 'clothing-store-2' → 'clothing-store')
  const getBaseAppType = (id: string): string => {
    // Remove variant suffixes (-2, -3, etc.) to get base type
    return id.replace(/-\d+$/, '');
  };

  // Find demo app - first try exact match, then base type fallback
  const demoApp = demoApps.find(app => app.id === demoId) || 
                  demoApps.find(app => app.id === getBaseAppType(demoId));
  
  if (!demoApp) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center text-label">
        <div className="ios-card p-6 mx-4 text-center">
          <h3 className="ios-title3 mb-2">Демо не найдено</h3>
          <p className="ios-body text-secondary-label">
            Приложение временно недоступно
          </p>
        </div>
      </div>
    );
  }

  const handleTabSwitch = (tab: TabType) => {
    setActiveTab(tab);
    if (hapticFeedback?.selection) {
      hapticFeedback.selection();
    }
  };

  const renderDemoContent = () => {
    const baseAppType = getBaseAppType(demoId);
    
    switch (baseAppType) {
      case 'clothing-store':
        return <ClothingStore activeTab={activeTab} />;
      case 'restaurant':
        return <Restaurant activeTab={activeTab} />;
      case 'fitness':
        return <Fitness activeTab={activeTab} />;
      case 'coffee':
        return <Coffee activeTab={activeTab} />;
      case 'beauty':
        return <Beauty activeTab={activeTab} />;
      case 'electronics':
        return <Electronics activeTab={activeTab} />;
      case 'bookstore':
        return <Bookstore activeTab={activeTab} />;
      case 'florist':
        return <Florist activeTab={activeTab} />;
      case 'carwash':
        return <CarWash activeTab={activeTab} />;
      case 'courses':
        return <Courses activeTab={activeTab} />;
      case 'pharmacy':
        return <Pharmacy activeTab={activeTab} />;
      case 'realty':
        return <Realty activeTab={activeTab} />;
      case 'taxi':
        return <Taxi activeTab={activeTab} />;
      case 'banking':
        return <Banking activeTab={activeTab} />;
      case 'hotel':
        return <Hotel activeTab={activeTab} />;
      default:
        return (
          <div className="px-4 py-6 max-w-md mx-auto">
            <div className="ios-card p-6 text-center">
              <h3 className="ios-title3 mb-4">
                🚀 Демо в разработке
              </h3>
              <p className="ios-body text-secondary-label mb-4">
                Это демо скоро будет готово
              </p>
              <div className="ios-card bg-system-blue/5 border-system-blue/20 p-4">
                <p className="ios-footnote text-system-blue">
                  ✨ Следите за обновлениями
                </p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-label">
      {/* iOS Navigation Bar */}
      <header className="ios-navbar border-b border-separator" data-testid="header-demo">
        <div className="max-w-md mx-auto flex items-center justify-between px-4 py-3">
          <button
            onClick={onClose}
            className="ios-button-plain"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <h1 className="ios-headline font-semibold text-center flex-1" data-testid="text-demo-title">
            {demoApp.title}
          </h1>
          
          <button
            className="ios-button-plain"
            data-testid="button-share"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </header>


      {/* Demo Content Area */}
      <div className="flex-1 pb-20" data-testid="demo-content">
        {renderDemoContent()}
      </div>

      {/* iOS Tab Bar */}
      <nav className="fixed bottom-0 left-0 right-0 ios-tabbar z-50" 
           style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
           data-testid="nav-bottom">
        <div className="max-w-md mx-auto">
          <div className="grid grid-cols-4">
            {navItems.map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                className="ios-tabbar-item"
                onClick={() => handleTabSwitch(id)}
                data-testid={`nav-${id}`}
              >
                <Icon className={`${
                  activeTab === id ? 'ios-tabbar-icon-active' : 'ios-tabbar-icon'
                }`} />
                <span className={`${
                  activeTab === id ? 'ios-tabbar-label-active' : 'ios-tabbar-label'
                }`}>
                  {label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}