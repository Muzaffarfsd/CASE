import { useState } from "react";
import { 
  Pill, 
  Heart, 
  Star, 
  Clock, 
  Search,
  Plus,
  Minus,
  X,
  ChevronRight,
  ShieldCheck,
  Truck,
  AlertCircle,
  User,
  Phone
} from "lucide-react";

interface PharmacyProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
  prescription?: boolean;
}

const medicines = [
  { id: 1, name: 'Парацетамол 500мг', price: 2.5, image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Жаропонижающее и обезболивающее средство', category: 'Обезболивающие', manufacturer: 'Фармстандарт', form: 'Таблетки', dosage: '500мг', prescription: false, inStock: 45, rating: 4.6, contraindications: ['Печеночная недостаточность', 'Аллергия на парацетамол'] },
  { id: 2, name: 'Амоксиклав 625мг', price: 12.8, image: 'https://images.unsplash.com/photo-1550572017-4d26d8065179?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антибиотик широкого спектра действия', category: 'Антибиотики', manufacturer: 'Лек', form: 'Таблетки', dosage: '625мг', prescription: true, inStock: 23, rating: 4.8, contraindications: ['Аллергия на пенициллин', 'Инфекционный мононуклеоз'] },
  { id: 3, name: 'Ибупрофен 400мг', price: 3.2, image: 'https://images.unsplash.com/photo-1554349645-4e52c9571e97?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Противовоспалительное и обезболивающее средство', category: 'Обезболивающие', manufacturer: 'Тева', form: 'Таблетки', dosage: '400мг', prescription: false, inStock: 67, rating: 4.5, contraindications: ['Язвенная болезнь', 'Бронхиальная астма'] },
  { id: 4, name: 'Омепразол 20мг', price: 5.6, image: 'https://images.unsplash.com/photo-1517244683827-7187df241510?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Препарат для лечения заболеваний желудка', category: 'Пищеварение', manufacturer: 'Акрихин', form: 'Капсулы', dosage: '20мг', prescription: false, inStock: 34, rating: 4.7, contraindications: ['Аллергия на компоненты', 'Беременность'] },
  { id: 5, name: 'Лоратадин 10мг', price: 1.8, image: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антигистаминный препарат против аллергии', category: 'Антигистаминные', manufacturer: 'Вертекс', form: 'Таблетки', dosage: '10мг', prescription: false, inStock: 89, rating: 4.4, contraindications: ['Детский возраст до 2 лет', 'Лактация'] },
  { id: 6, name: 'Аскорбиновая кислота 100мг', price: 1.2, image: 'https://images.unsplash.com/photo-1523263269420-3c8d04ae830a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Витамин C для укрепления иммунитета', category: 'Витамины', manufacturer: 'Упсавит', form: 'Таблетки', dosage: '100мг', prescription: false, inStock: 156, rating: 4.2, contraindications: ['Тромбофлебит', 'Сахарный диабет'] },
  { id: 7, name: 'Мирамистин 0.01%', price: 8.9, image: 'https://images.unsplash.com/photo-1576671081837-49000212a370?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антисептическое средство для наружного применения', category: 'Антисептики', manufacturer: 'Инфамед', form: 'Раствор', dosage: '0.01%', prescription: false, inStock: 78, rating: 4.8, contraindications: ['Индивидуальная непереносимость'] },
  { id: 8, name: 'Мелатонин 3мг', price: 15.4, image: 'https://images.unsplash.com/photo-1567095751004-aa51a2690368?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Регулятор циркадных ритмов для улучшения сна', category: 'Сон и стресс', manufacturer: 'Натуральная аптека', form: 'Таблетки', dosage: '3мг', prescription: false, inStock: 25, rating: 4.6, contraindications: ['Беременность', 'Детский возраст'] },
  { id: 9, name: 'Симвастатин 20мг', price: 7.3, image: 'https://images.unsplash.com/photo-1541108564102-e6e4cadc4b5c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Статин для снижения уровня холестерина', category: 'Сердечно-сосудистые', manufacturer: 'Гедеон Рихтер', form: 'Таблетки', dosage: '20мг', prescription: true, inStock: 18, rating: 4.5, contraindications: ['Печеночная недостаточность', 'Миопатия'] },
  { id: 10, name: 'Эналаприл 10мг', price: 4.8, image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'АПФ-ингибитор для лечения гипертонии', category: 'Сердечно-сосудистые', manufacturer: 'Биосинтез', form: 'Таблетки', dosage: '10мг', prescription: true, inStock: 42, rating: 4.7, contraindications: ['Ангионевротический отек', 'Беременность'] },
  { id: 11, name: 'Кетопрофен гель 2.5%', price: 6.5, image: 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Противовоспалительный гель для наружного применения', category: 'Наружные средства', manufacturer: 'Сандоз', form: 'Гель', dosage: '2.5%', prescription: false, inStock: 56, rating: 4.3, contraindications: ['Открытые раны', 'Экзема'] },
  { id: 12, name: 'Флуконазол 150мг', price: 9.2, image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Противогрибковый препарат', category: 'Противогрибковые', manufacturer: 'Озон', form: 'Капсулы', dosage: '150мг', prescription: true, inStock: 31, rating: 4.6, contraindications: ['Совместный прием с терфенадином', 'Печеночная недостаточность'] },
  { id: 13, name: 'Фенистил капли', price: 11.7, image: 'https://images.unsplash.com/photo-1586776977607-310e9c725c37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антигистаминные капли для детей и взрослых', category: 'Антигистаминные', manufacturer: 'Новартис', form: 'Капли', dosage: '20мл', prescription: false, inStock: 47, rating: 4.5, contraindications: ['Глаукома', 'Гиперплазия простаты'] },
  { id: 14, name: 'Супрастин 25мг', price: 3.1, image: 'https://images.unsplash.com/photo-1607616053700-a2d4c9d39c91?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Быстродействующий антигистаминный препарат', category: 'Антигистаминные', manufacturer: 'Эгис', form: 'Таблетки', dosage: '25мг', prescription: false, inStock: 73, rating: 4.4, contraindications: ['Новорожденные', 'Приступ бронхиальной астмы'] },
  { id: 15, name: 'Ренни', price: 4.6, image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антацидное средство от изжоги', category: 'Пищеварение', manufacturer: 'Байер', form: 'Жевательные таблетки', dosage: '12 таблеток', prescription: false, inStock: 92, rating: 4.3, contraindications: ['Почечная недостаточность', 'Гиперкальциемия'] },
  { id: 16, name: 'Називин 0.05%', price: 7.8, image: 'https://images.unsplash.com/photo-1518965345946-f3139b27cc09?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Сосудосуживающие капли в нос', category: 'Простуда и грипп', manufacturer: 'Мерк', form: 'Капли назальные', dosage: '0.05%', prescription: false, inStock: 65, rating: 4.2, contraindications: ['Атрофический ринит', 'Закрытоугольная глаукома'] },
  { id: 17, name: 'Терафлю', price: 6.9, image: 'https://images.unsplash.com/photo-1586776977607-310e9c725c37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Комплексное средство от симптомов простуды', category: 'Простуда и грипп', manufacturer: 'Новартис', form: 'Порошок', dosage: '10 пакетиков', prescription: false, inStock: 84, rating: 4.1, contraindications: ['Детский возраст до 12 лет', 'Сахарный диабет'] },
  { id: 18, name: 'Но-шпа 40мг', price: 8.4, image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Спазмолитик для снятия болей', category: 'Спазмолитики', manufacturer: 'Хиноин', form: 'Таблетки', dosage: '40мг', prescription: false, inStock: 58, rating: 4.8, contraindications: ['Тяжелая печеночная недостаточность', 'Сердечная недостаточность'] },
  { id: 19, name: 'Валериана экстракт', price: 2.9, image: 'https://images.unsplash.com/photo-1567095751004-aa51a2690368?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Натуральное успокоительное средство', category: 'Сон и стресс', manufacturer: 'Фармстандарт', form: 'Таблетки', dosage: '200мг', prescription: false, inStock: 143, rating: 4.0, contraindications: ['Депрессия', 'Детский возраст до 3 лет'] },
  { id: 20, name: 'Цинковая мазь 10%', price: 1.8, image: 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Противовоспалительная мазь для кожи', category: 'Наружные средства', manufacturer: 'Тульская фармацевтическая фабрика', form: 'Мазь', dosage: '10%', prescription: false, inStock: 76, rating: 4.1, contraindications: ['Гиперчувствительность к цинку'] }
];

const categories = ['Все', 'Обезболивающие', 'Антибиотики', 'Антигистаминные', 'Витамины', 'Пищеварение', 'Сердечно-сосудистые', 'Простуда и грипп', 'Наружные средства', 'Сон и стресс'];

const initialCartItems: CartItem[] = [
  { id: 1, name: 'Парацетамол 500мг', price: 2.5, quantity: 2, image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60', prescription: false },
  { id: 7, name: 'Мирамистин 0.01%', price: 8.9, quantity: 1, image: 'https://images.unsplash.com/photo-1576671081837-49000212a370?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60', prescription: false },
];

export default function Pharmacy({ activeTab }: PharmacyProps) {
  const [selectedMedicine, setSelectedMedicine] = useState<typeof medicines[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 7, 15, 18]);
  const [searchQuery, setSearchQuery] = useState('');

  const openMedicineModal = (medicine: typeof medicines[0]) => {
    setSelectedMedicine(medicine);
    setIsModalOpen(true);
  };

  const closeMedicineModal = () => {
    setIsModalOpen(false);
    setSelectedMedicine(null);
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCartItems(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeFromCart = (itemId: number) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const toggleFavorite = (medicineId: number) => {
    setFavorites(prev => 
      prev.includes(medicineId) 
        ? prev.filter(id => id !== medicineId)
        : [...prev, medicineId]
    );
  };

  const filteredMedicines = medicines.filter(medicine => {
    const matchesCategory = selectedCategory === 'Все' || medicine.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      medicine.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const hasPrescriptionItems = cartItems.some(item => item.prescription);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">АптекаПлюс</h1>
        <p className="ios-subheadline text-secondary-label">Лекарства с доставкой 24/7 💊</p>
      </div>

      {/* Быстрая доставка */}
      <div className="ios-card p-4 bg-gradient-to-r from-teal-500 to-green-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="ios-headline font-semibold">Доставка за 30 минут</h3>
            <p className="ios-body">Круглосуточно по городу</p>
          </div>
          <Truck className="w-8 h-8" />
        </div>
      </div>

      {/* Популярные категории */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Популярные категории</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Обезболивающие', icon: '💊', color: 'bg-red-500' },
            { name: 'Витамины', icon: '🌟', color: 'bg-orange-500' },
            { name: 'Простуда и грипп', icon: '🤧', color: 'bg-blue-500' },
            { name: 'Антисептики', icon: '🧴', color: 'bg-green-500' }
          ].map((category) => (
            <div 
              key={category.name} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => setSelectedCategory(category.name)}
            >
              <div className={`w-12 h-12 ${category.color} rounded-lg mb-2 flex items-center justify-center`}>
                <span className="text-2xl">{category.icon}</span>
              </div>
              <h4 className="ios-footnote font-semibold">{category.name}</h4>
            </div>
          ))}
        </div>
      </div>

      {/* Часто покупаемые */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Часто покупаемые</h2>
        <div className="space-y-3">
          {medicines.slice(0, 3).map((medicine) => (
            <div 
              key={medicine.id} 
              className="ios-card p-3 cursor-pointer flex items-center space-x-3"
              onClick={() => openMedicineModal(medicine)}
            >
              <img src={medicine.image} alt={medicine.name} className="w-12 h-12 object-cover rounded-lg" />
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{medicine.name}</h4>
                <p className="ios-footnote text-secondary-label">{medicine.manufacturer} • ${medicine.price}</p>
                <div className="flex items-center space-x-2">
                  {medicine.prescription && (
                    <span className="px-2 py-1 rounded-full ios-caption2 font-semibold bg-red-100 text-red-700">
                      По рецепту
                    </span>
                  )}
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span className="ios-caption2">{medicine.rating}</span>
                  </div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-tertiary-label" />
            </div>
          ))}
        </div>
      </div>

      {/* Информация об аптеке */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Наши гарантии</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-system-teal" />
            <span className="ios-body">Только сертифицированные препараты</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-system-teal" />
            <span className="ios-body">Круглосуточная доставка</span>
          </div>
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4 text-system-teal" />
            <span className="ios-body">Консультация фармацевта</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Каталог лекарств</h1>
      
      {/* Поиск */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-secondary-label" />
        <input
          type="text"
          placeholder="Поиск лекарств..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-quaternary-system-fill rounded-xl ios-body"
        />
      </div>

      {/* Категории */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
              selectedCategory === category
                ? 'bg-system-teal text-white'
                : 'bg-quaternary-system-fill text-label'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Список лекарств */}
      <div className="space-y-3">
        {filteredMedicines.map((medicine) => (
          <div 
            key={medicine.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openMedicineModal(medicine)}
          >
            <div className="flex items-center space-x-3">
              <img src={medicine.image} alt={medicine.name} className="w-16 h-16 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold line-clamp-1">{medicine.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(medicine.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(medicine.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-1">{medicine.manufacturer}</p>
                <p className="ios-caption2 text-tertiary-label mb-2 line-clamp-2">{medicine.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="ios-caption2 px-2 py-1 bg-quaternary-system-fill rounded">{medicine.category}</span>
                    {medicine.prescription && (
                      <span className="ios-caption2 px-2 py-1 bg-red-100 text-red-700 rounded">
                        Рецепт
                      </span>
                    )}
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="ios-caption2">{medicine.rating}</span>
                    </div>
                  </div>
                  <span className="ios-body font-bold text-system-teal">${medicine.price}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Корзина</h1>
      
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <Pill className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Корзина пуста</p>
          <p className="ios-footnote text-tertiary-label">Добавьте лекарства из каталога</p>
        </div>
      ) : (
        <>
          {hasPrescriptionItems && (
            <div className="ios-card p-4 bg-orange-50 border border-orange-200">
              <div className="flex items-center space-x-2 mb-2">
                <AlertCircle className="w-4 h-4 text-orange-600" />
                <span className="ios-body font-semibold text-orange-600">Требуется рецепт</span>
              </div>
              <p className="ios-footnote text-secondary-label">
                В корзине есть рецептурные препараты. Загрузите фото рецепта при оформлении заказа.
              </p>
            </div>
          )}

          <div className="space-y-3">
            {cartItems.map((item) => (
              <div key={item.id} className="ios-card p-4">
                <div className="flex items-center space-x-3">
                  <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="ios-body font-semibold">{item.name}</h4>
                      {item.prescription && (
                        <span className="px-2 py-1 rounded-full ios-caption2 font-semibold bg-red-100 text-red-700">
                          Рецепт
                        </span>
                      )}
                    </div>
                    <p className="ios-footnote text-secondary-label">${item.price} за упаковку</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full bg-quaternary-system-fill flex items-center justify-center"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="ios-body font-semibold w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full bg-system-teal text-white flex items-center justify-center"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="ios-body font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ios-footnote text-system-red"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-card p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="ios-body">Подытог:</span>
              <span className="ios-body font-semibold">${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="ios-body">Доставка:</span>
              <span className="ios-body font-semibold">$2.00</span>
            </div>
            <hr className="border-separator" />
            <div className="flex justify-between items-center">
              <span className="ios-headline font-bold">Итого:</span>
              <span className="ios-headline font-bold text-system-teal">${(cartTotal + 2).toFixed(2)}</span>
            </div>
            
            <button className="w-full bg-system-teal text-white ios-body font-semibold py-3 rounded-xl flex items-center justify-center space-x-2">
              <Truck className="w-5 h-5" />
              <span>Оформить заказ</span>
            </button>
          </div>

          {/* Контакты аптеки */}
          <div className="ios-card p-4 bg-system-teal/5 border border-system-teal/20">
            <div className="flex items-center space-x-2 mb-2">
              <Phone className="w-4 h-4 text-system-teal" />
              <span className="ios-body font-semibold text-system-teal">Консультация фармацевта</span>
            </div>
            <p className="ios-footnote text-secondary-label">
              Бесплатная консультация: +7 (800) 123-45-67
            </p>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль пациента</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-teal rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">АП</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Постоянный клиент</h3>
            <p className="ios-body text-secondary-label">Карта лояльности №12345</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-teal">127</p>
            <p className="ios-footnote text-secondary-label">Заказов</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">5%</p>
            <p className="ios-footnote text-secondary-label">Скидка</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Избранные препараты</h2>
        {medicines.filter(medicine => favorites.includes(medicine.id)).map((medicine) => (
          <div key={medicine.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={medicine.image} alt={medicine.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold line-clamp-1">{medicine.name}</h4>
              <p className="ios-footnote text-secondary-label">{medicine.manufacturer} • ${medicine.price}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">История заказов</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Последний заказ:</span>
            <span className="ios-body font-medium">19 дек 2024</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Часто покупаемое:</span>
            <span className="ios-body font-medium">Парацетамол</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Потрачено всего:</span>
            <span className="ios-body font-medium text-system-teal">$2,840</span>
          </div>
        </div>
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Медицинская информация</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Аллергии:</span>
            <span className="ios-body font-medium">Пенициллин</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Хронические заболевания:</span>
            <span className="ios-body font-medium">Гипертония</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Лечащий врач:</span>
            <span className="ios-body font-medium">Иванов И.И.</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedMedicine && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold line-clamp-2">{selectedMedicine.name}</h3>
              <button onClick={closeMedicineModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedMedicine.image} alt={selectedMedicine.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <span className="ios-body font-medium">{selectedMedicine.manufacturer}</span>
                {selectedMedicine.prescription && (
                  <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-red-100 text-red-700">
                    По рецепту
                  </span>
                )}
              </div>
              
              <p className="ios-body text-secondary-label">{selectedMedicine.description}</p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="ios-card p-3">
                  <p className="ios-caption2 text-secondary-label">Форма выпуска</p>
                  <p className="ios-body font-semibold">{selectedMedicine.form}</p>
                </div>
                <div className="ios-card p-3">
                  <p className="ios-caption2 text-secondary-label">Дозировка</p>
                  <p className="ios-body font-semibold">{selectedMedicine.dosage}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Противопоказания:</h4>
                <div className="space-y-1">
                  {selectedMedicine.contraindications.map((item, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 text-red-500" />
                      <span className="ios-footnote text-secondary-label">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedMedicine.rating}</span>
                </div>
                <span className="ios-footnote text-secondary-label">
                  В наличии: {selectedMedicine.inStock} шт.
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="ios-title font-bold text-system-teal">${selectedMedicine.price}</span>
                <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-quaternary-system-fill text-label">
                  {selectedMedicine.category}
                </span>
              </div>
              
              <button className="w-full bg-system-teal text-white ios-body font-semibold py-3 rounded-xl">
                В корзину
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}