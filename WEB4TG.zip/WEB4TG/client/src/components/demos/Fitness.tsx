import { useState } from "react";
import { 
  Flame, 
  Dumbbell, 
  Users, 
  Calendar, 
  TrendingUp, 
  Trophy, 
  ChevronRight, 
  X, 
  Star,
  Clock,
  Target,
  Activity,
  User,
  Award,
  Timer
} from "lucide-react";

interface FitnessProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

const todaysClasses = [
  { id: 1, name: 'HIIT Тренировка', instructor: 'Сара Джонсон', time: '10:00', spots: '8/12', price: 20, description: 'Интенсивная интервальная тренировка', level: 'Средний', duration: '45 мин' },
  { id: 2, name: 'Йога Флоу', instructor: 'Майк Чен', time: '18:00', spots: '5/15', price: 15, description: 'Плавная йога для расслабления', level: 'Начинающий', duration: '60 мин' },
  { id: 3, name: 'Силовая тренировка', instructor: 'Макс Петров', time: '14:00', spots: '6/10', price: 25, description: 'Тренировка с отягощениями', level: 'Продвинутый', duration: '50 мин' },
  { id: 4, name: 'Пилатес', instructor: 'Анна Ковалева', time: '16:30', spots: '4/12', price: 18, description: 'Оздоровительная гимнастика', level: 'Начинающий', duration: '50 мин' }
];

const allClasses = [
  ...todaysClasses,
  { id: 5, name: 'Стретчинг', instructor: 'Лена Смирнова', time: '20:00', spots: '8/15', price: 12, description: 'Развитие гибкости и подвижности суставов', level: 'Любой', duration: '30 мин' },
  { id: 6, name: 'Кроссфит', instructor: 'Дмитрий Кузнецов', time: '17:00', spots: '2/8', price: 28, description: 'Многофункциональная высокоинтенсивная тренировка', level: 'Продвинутый', duration: '60 мин' },
  { id: 7, name: 'Танцы', instructor: 'Наталья Козлова', time: '19:30', spots: '6/20', price: 19, description: 'Танцевальная аэробика под современную музыку', level: 'Начинающий', duration: '55 мин' },
  { id: 8, name: 'Аквааэробика', instructor: 'Игорь Морозов', time: '15:30', spots: '10/12', price: 16, description: 'Водная аэробика в бассейне для всех возрастов', level: 'Любой', duration: '40 мин' },
  { id: 9, name: 'Функциональный тренинг', instructor: 'Алексей Волков', time: '13:00', spots: '4/10', price: 22, description: 'Тренировка функциональных движений с собственным весом', level: 'Средний', duration: '45 мин' },
  { id: 10, name: 'TRX', instructor: 'Валерия Петрова', time: '11:00', spots: '3/8', price: 24, description: 'Тренировка с подвесными ремнями TRX', level: 'Средний', duration: '50 мин' },
  { id: 11, name: 'Бокс', instructor: 'Роман Белов', time: '18:30', spots: '5/12', price: 26, description: 'Тренировка боксерской техники и общей физподготовки', level: 'Любой', duration: '60 мин' },
  { id: 12, name: 'Калистеника', instructor: 'Артем Соколов', time: '12:30', spots: '7/15', price: 20, description: 'Тренировка с собственным весом на турниках и брусьях', level: 'Продвинутый', duration: '55 мин' },
  { id: 13, name: 'Медитация', instructor: 'Елена Зубова', time: '21:00', spots: '12/20', price: 10, description: 'Расслабляющая медитация и дыхательные практики', level: 'Любой', duration: '30 мин' },
  { id: 14, name: 'Кикбоксинг', instructor: 'Сергей Титов', time: '19:00', spots: '6/10', price: 25, description: 'Динамичная тренировка с элементами боевых искусств', level: 'Средний', duration: '50 мин' },
  { id: 15, name: 'Зумба', instructor: 'Мария Кравцова', time: '17:30', spots: '8/25', price: 18, description: 'Зажигательные танцы под латинскую музыку', level: 'Начинающий', duration: '45 мин' },
  { id: 16, name: 'Миофасциальный релиз', instructor: 'Дарья Иванова', time: '20:30', spots: '4/8', price: 15, description: 'Расслабление мышц с использованием массажных роллов', level: 'Любой', duration: '35 мин' }
];

const additionalServices = [
  { id: 17, name: 'Спортивный массаж', instructor: 'Татьяна Белова', time: 'По записи', spots: 'Индивидуально', price: 45, description: 'Профессиональный массаж для восстановления мышц', level: 'Любой', duration: '60 мин' },
  { id: 18, name: 'Консультация диетолога', instructor: 'Ольга Крылова', time: 'По записи', spots: 'Индивидуально', price: 35, description: 'Составление персонального плана питания', level: 'Любой', duration: '45 мин' },
  { id: 19, name: 'Фитнес-тестирование', instructor: 'Игорь Смирнов', time: 'По записи', spots: 'Индивидуально', price: 25, description: 'Комплексная оценка физической подготовки', level: 'Любой', duration: '30 мин' },
  { id: 20, name: 'Криотерапия', instructor: 'Специалист', time: 'По записи', spots: 'Индивидуально', price: 30, description: 'Восстановительная процедура в криокамере', level: 'Любой', duration: '15 мин' }
];

const allServices = [...allClasses, ...additionalServices];

const trainers = [
  { id: 1, name: 'Сара Джонсон', specialty: 'Силовые тренировки', price: 60, image: 'https://images.unsplash.com/photo-1594736797933-d0d4bce9b91a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '8 лет', rating: 4.9 },
  { id: 2, name: 'Майк Чен', specialty: 'Йога и медитация', price: 70, image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '6 лет', rating: 4.8 },
  { id: 3, name: 'Алекс Родригес', specialty: 'Кардио и HIIT', price: 80, image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '10 лет', rating: 4.9 },
  { id: 4, name: 'Мария Петрова', specialty: 'Пилатес и стретчинг', price: 65, image: 'https://images.unsplash.com/photo-1594736797933-d0d4bce9b91a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '7 лет', rating: 4.7 },
  { id: 5, name: 'Дмитрий Кузнецов', specialty: 'Кроссфит и функциональный тренинг', price: 75, image: 'https://images.unsplash.com/photo-1566753323558-f4e0952af115?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '9 лет', rating: 4.8 },
  { id: 6, name: 'Анна Ковалева', specialty: 'Танцы и аэробика', price: 55, image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', experience: '5 лет', rating: 4.6 }
];

const myBookings = [
  { id: 1, name: 'HIIT Тренировка', date: 'Завтра, 10:00', instructor: 'Сара Джонсон', price: 20, type: 'Групповое занятие' },
  { id: 2, name: 'Персональная Тренировка', date: 'Пятница, 15:00', instructor: 'Майк Чен', price: 70, type: 'Персональная тренировка' },
  { id: 3, name: 'Йога для начинающих', date: 'Суббота, 11:00', instructor: 'Майк Чен', price: 20, type: 'Групповое занятие' }
];

export default function Fitness({ activeTab }: FitnessProps) {
  const [selectedService, setSelectedService] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeClassCategory, setActiveClassCategory] = useState('today');

  const openServiceModal = (service: any) => {
    setSelectedService(service);
    setIsModalOpen(true);
  };

  const closeServiceModal = () => {
    setIsModalOpen(false);
    setSelectedService(null);
  };

  const renderHomeTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Fitness Hero */}
        <section className="ios-slide-up">
          <div className="ios-card overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"
              alt="Спортивное оборудование"
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="ios-title3 mb-2">PowerFit Зал</h2>
              <p className="ios-body text-secondary-label mb-4">
                Премиум оборудование и экспертные тренеры
              </p>
              <button className="ios-button-filled" data-testid="button-join-now">
                Присоединиться
              </button>
            </div>
          </div>
        </section>

        {/* Today's Classes */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Классы сегодня</h3>
          <div className="space-y-3">
            {todaysClasses.slice(0, 3).map((classItem) => (
              <div 
                key={classItem.id} 
                className="ios-card p-4 cursor-pointer" 
                onClick={() => openServiceModal(classItem)}
                data-testid={`class-${classItem.id}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="ios-body font-semibold">{classItem.name}</h4>
                  <span className="ios-footnote font-bold text-system-blue">{classItem.price} $</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-secondary-label" />
                      <span className="ios-caption2 text-secondary-label">{classItem.time}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="w-3 h-3 text-secondary-label" />
                      <span className="ios-caption2 text-secondary-label">{classItem.spots}</span>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded-full ios-caption2 font-semibold ${
                    classItem.level === 'Начинающий' ? 'bg-system-green/10 text-system-green' :
                    classItem.level === 'Средний' ? 'bg-system-orange/10 text-system-orange' :
                    'bg-system-red/10 text-system-red'
                  }`}>
                    {classItem.level}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Stats Cards */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Ваша статистика</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="ios-card p-4 text-center">
              <div className="w-12 h-12 bg-system-orange/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <Flame className="w-6 h-6 text-system-orange" />
              </div>
              <p className="ios-title3 font-bold">1,247</p>
              <p className="ios-caption2 text-secondary-label">Калорий сожжено</p>
            </div>
            <div className="ios-card p-4 text-center">
              <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="w-6 h-6 text-system-blue" />
              </div>
              <p className="ios-title3 font-bold">12</p>
              <p className="ios-caption2 text-secondary-label">Тренировок</p>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="ios-slide-up">
          <div className="grid grid-cols-2 gap-3">
            <div className="ios-card p-4 text-center cursor-pointer">
              <div className="w-12 h-12 bg-system-purple/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <Calendar className="w-6 h-6 text-system-purple" />
              </div>
              <p className="ios-footnote font-semibold">Расписание</p>
            </div>
            <div className="ios-card p-4 text-center cursor-pointer">
              <div className="w-12 h-12 bg-system-green/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <Target className="w-6 h-6 text-system-green" />
              </div>
              <p className="ios-footnote font-semibold">Цели</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Class Categories */}
        <section className="ios-slide-up">
          <div className="ios-segmented">
            <div className="flex space-x-1">
              <button
                className={`${
                  activeClassCategory === 'today' ? 'ios-segmented-item-active' : 'ios-segmented-item'
                }`}
                onClick={() => setActiveClassCategory('today')}
              >
                Сегодня
              </button>
              <button
                className={`${
                  activeClassCategory === 'all' ? 'ios-segmented-item-active' : 'ios-segmented-item'
                }`}
                onClick={() => setActiveClassCategory('all')}
              >
                Все классы
              </button>
              <button
                className={`${
                  activeClassCategory === 'trainers' ? 'ios-segmented-item-active' : 'ios-segmented-item'
                }`}
                onClick={() => setActiveClassCategory('trainers')}
              >
                Тренеры
              </button>
            </div>
          </div>
        </section>

        {/* Content based on category */}
        <section className="ios-slide-up">
          {activeClassCategory === 'today' && (
            <div className="space-y-3">
              {todaysClasses.map((classItem) => (
                <div 
                  key={classItem.id} 
                  className="ios-card p-4 cursor-pointer" 
                  onClick={() => openServiceModal(classItem)}
                  data-testid={`today-class-${classItem.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="ios-headline font-semibold">{classItem.name}</h4>
                    <span className="ios-body font-bold text-system-blue">{classItem.price} $</span>
                  </div>
                  <div className="ios-footnote text-secondary-label mb-3">{classItem.description}</div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4 text-secondary-label" />
                        <span className="ios-footnote">{classItem.time} • {classItem.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4 text-secondary-label" />
                        <span className="ios-footnote">{classItem.spots}</span>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full ios-caption2 font-semibold ${
                      classItem.level === 'Начинающий' ? 'bg-system-green/10 text-system-green' :
                      classItem.level === 'Средний' ? 'bg-system-orange/10 text-system-orange' :
                      'bg-system-red/10 text-system-red'
                    }`}>
                      {classItem.level}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeClassCategory === 'all' && (
            <div className="space-y-3">
              {allServices.map((classItem) => (
                <div 
                  key={classItem.id} 
                  className="ios-card p-4 cursor-pointer" 
                  onClick={() => openServiceModal(classItem)}
                  data-testid={`all-class-${classItem.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="ios-headline font-semibold">{classItem.name}</h4>
                    <span className="ios-body font-bold text-system-blue">{classItem.price} $</span>
                  </div>
                  <div className="ios-footnote text-secondary-label mb-3">{classItem.description}</div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="ios-caption2 text-secondary-label">{classItem.instructor}</div>
                      <div className="ios-caption2 text-secondary-label">{classItem.duration}</div>
                    </div>
                    <span className={`px-2 py-1 rounded-full ios-caption2 font-semibold ${
                      classItem.level === 'Начинающий' ? 'bg-system-green/10 text-system-green' :
                      classItem.level === 'Средний' ? 'bg-system-orange/10 text-system-orange' :
                      classItem.level === 'Любой' ? 'bg-system-blue/10 text-system-blue' :
                      'bg-system-red/10 text-system-red'
                    }`}>
                      {classItem.level}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeClassCategory === 'trainers' && (
            <div className="space-y-3">
              {trainers.map((trainer) => (
                <div 
                  key={trainer.id} 
                  className="ios-card p-4 cursor-pointer" 
                  onClick={() => openServiceModal(trainer)}
                  data-testid={`trainer-${trainer.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <img
                      src={trainer.image}
                      alt={trainer.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="ios-headline font-semibold">{trainer.name}</h4>
                      <p className="ios-footnote text-secondary-label">{trainer.specialty}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="ios-body font-bold text-system-blue">{trainer.price} $ / час</span>
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3 text-system-orange" />
                          <span className="ios-caption2">{trainer.rating}</span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-tertiary-label" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {myBookings.length === 0 ? (
          <div className="ios-card p-8 text-center">
            <Calendar className="w-12 h-12 text-secondary-label mx-auto mb-4" />
            <h3 className="ios-title3 mb-2">Нет бронирований</h3>
            <p className="ios-body text-secondary-label mb-4">
              Забронируйте тренировку или класс
            </p>
            <button className="ios-button-filled">
              Посмотреть расписание
            </button>
          </div>
        ) : (
          <section className="ios-slide-up">
            <div className="ios-list">
              <div className="ios-list-header">Мои бронирования</div>
              {myBookings.map((booking) => (
                <div key={booking.id} className="ios-list-item" data-testid={`booking-${booking.id}`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center">
                      <Activity className="w-6 h-6 text-system-blue" />
                    </div>
                    <div className="flex-1">
                      <div className="ios-body font-semibold">{booking.name}</div>
                      <div className="ios-footnote text-secondary-label">{booking.date}</div>
                      <div className="ios-footnote text-secondary-label">{booking.instructor}</div>
                      <div className="ios-footnote font-bold text-system-blue">{booking.price} $</div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-tertiary-label" />
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );

  const renderProfileTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* User Profile */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 text-center">
            <div className="w-16 h-16 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-system-blue" />
            </div>
            <h2 className="ios-title2 mb-2">Алексей Петров</h2>
            <p className="ios-footnote text-secondary-label">
              Активный участник
            </p>
          </div>
        </section>

        {/* Achievements */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Достижения</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="ios-card p-3 text-center">
              <Trophy className="w-8 h-8 text-system-orange mx-auto mb-2" />
              <p className="ios-caption2 font-semibold">30 дней</p>
            </div>
            <div className="ios-card p-3 text-center">
              <Flame className="w-8 h-8 text-system-red mx-auto mb-2" />
              <p className="ios-caption2 font-semibold">5000 кал</p>
            </div>
            <div className="ios-card p-3 text-center">
              <Award className="w-8 h-8 text-system-blue mx-auto mb-2" />
              <p className="ios-caption2 font-semibold">Топ 10</p>
            </div>
          </div>
        </section>

        {/* Menu Options */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <TrendingUp className="w-5 h-5 text-system-blue" />
                <div className="flex-1">
                  <div className="ios-body">Прогресс</div>
                  <div className="ios-footnote text-secondary-label">
                    Статистика тренировок
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <Target className="w-5 h-5 text-system-green" />
                <div className="flex-1">
                  <div className="ios-body">Цели</div>
                  <div className="ios-footnote text-secondary-label">
                    Фитнес планы
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <Calendar className="w-5 h-5 text-system-purple" />
                <div className="flex-1">
                  <div className="ios-body">Расписание</div>
                  <div className="ios-footnote text-secondary-label">
                    Мои тренировки
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return renderHomeTab();
      case 'catalog':
        return renderCatalogTab();
      case 'cart':
        return renderCartTab();
      case 'profile':
        return renderProfileTab();
      default:
        return renderHomeTab();
    }
  };

  return (
    <>
      {renderContent()}

      {/* Premium Fitness Service Modal */}
      {isModalOpen && selectedService && (
        <div className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm animate-in fade-in duration-300" data-testid="service-modal">
          <div className="safe-area-top h-full flex flex-col">
            {/* Animated Modal Container */}
            <div className="bg-white rounded-t-3xl mt-16 flex-1 overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-500">
              {/* Enhanced Modal Header */}
              <div className="relative bg-gradient-to-r from-white via-white/95 to-white backdrop-blur-md border-b border-separator/30">
                <div className="max-w-md mx-auto flex items-center justify-between px-6 py-4">
                  <button
                    onClick={closeServiceModal}
                    className="w-10 h-10 bg-secondary-system-fill rounded-full flex items-center justify-center hover:bg-tertiary-system-fill transition-all duration-200 active:scale-95"
                    data-testid="button-close-modal"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <h1 className="ios-headline font-bold text-center flex-1">
                    💪 {selectedService.specialty ? 'Персональный тренер' : 'Фитнес-класс'}
                  </h1>
                  <div className="w-10" />
                </div>
              </div>

              {/* Enhanced Modal Content */}
              <div className="flex-1 overflow-y-auto">
                <div className="max-w-md mx-auto">
                  {/* Hero Image with Overlays */}
                  {selectedService.image && (
                    <div className="relative overflow-hidden">
                      <img
                        src={selectedService.image}
                        alt={selectedService.name}
                        className="w-full h-80 object-cover transition-transform duration-700 hover:scale-105"
                        onError={(e) => {
                          e.currentTarget.src = `https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400`;
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
                      
                      {/* Pro Badge */}
                      <div className="absolute top-4 left-4 animate-in slide-in-from-left duration-700">
                        <div className="bg-gradient-to-r from-system-green to-system-teal px-3 py-1.5 rounded-full shadow-lg">
                          <span className="text-white text-xs font-bold">
                            {selectedService.specialty ? 'PRO TRAINER' : 'FITNESS CLASS'}
                          </span>
                        </div>
                      </div>
                      
                      {/* Rating Badge */}
                      {selectedService.rating && (
                        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-right duration-700">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 text-system-yellow fill-current" />
                            <span className="text-sm font-bold">{selectedService.rating}</span>
                          </div>
                        </div>
                      )}
                      
                      {/* Duration Badge */}
                      {selectedService.duration && (
                        <div className="absolute bottom-4 right-4 bg-system-purple/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-bottom duration-700">
                          <div className="flex items-center space-x-1">
                            <Timer className="w-3 h-3 text-white" />
                            <span className="text-white text-xs font-medium">{selectedService.duration}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="px-6 py-6 space-y-6">
                    {/* Service Info */}
                    <div className="space-y-4 animate-in slide-in-from-bottom duration-500 delay-200">
                      <div>
                        <h2 className="ios-title1 font-bold mb-3 bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                          {selectedService.name}
                        </h2>
                        <p className="ios-body text-secondary-label leading-relaxed">
                          {selectedService.description || selectedService.specialty}
                        </p>
                      </div>
                    </div>
                    
                    {/* Price Card */}
                    <div className="bg-gradient-to-r from-system-green/5 via-system-teal/5 to-system-blue/5 rounded-2xl p-6 border border-system-green/10 shadow-sm animate-in slide-in-from-bottom duration-500 delay-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="ios-large-title font-black bg-gradient-to-r from-system-green to-system-teal bg-clip-text text-transparent">
                            {selectedService.price} $
                          </span>
                          <p className="ios-caption1 text-secondary-label mt-1">
                            {selectedService.specialty ? 'За час тренировки' : 'За класс'}
                          </p>
                        </div>
                        {selectedService.rating && (
                          <div className="text-right">
                            <div className="flex items-center space-x-1 justify-end">
                              <Star className="w-5 h-5 text-system-orange fill-current" />
                              <span className="ios-headline font-bold">{selectedService.rating}</span>
                            </div>
                            <p className="ios-caption1 text-secondary-label">
                              Рейтинг клиентов
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Instructor Info */}
                    {selectedService.instructor && (
                      <div className="bg-white rounded-2xl border border-separator/50 p-4 shadow-sm animate-in slide-in-from-bottom duration-500 delay-400">
                        <h3 className="ios-headline font-semibold mb-3 flex items-center">
                          <User className="w-4 h-4 mr-2 text-system-blue" />
                          Тренер
                        </h3>
                        <div className="bg-system-blue/5 rounded-xl p-3">
                          <p className="ios-body font-bold text-system-blue">{selectedService.instructor}</p>
                          {selectedService.experience && (
                            <p className="ios-caption1 text-secondary-label mt-1">
                              Опыт: {selectedService.experience}
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Details Grid */}
                    <div className="bg-white rounded-2xl border border-separator/50 p-4 shadow-sm animate-in slide-in-from-bottom duration-500 delay-500">
                      <h3 className="ios-headline font-semibold mb-3 flex items-center">
                        <Activity className="w-4 h-4 mr-2 text-system-purple" />
                        Детали программы
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        {selectedService.duration && (
                          <div className="text-center p-3 bg-system-purple/5 rounded-xl">
                            <Timer className="w-5 h-5 text-system-purple mx-auto mb-1" />
                            <p className="text-sm font-bold">{selectedService.duration}</p>
                            <p className="text-xs text-secondary-label">Время</p>
                          </div>
                        )}
                        {selectedService.rating && (
                          <div className="text-center p-3 bg-system-green/5 rounded-xl">
                            <Star className="w-5 h-5 text-system-orange mx-auto mb-1" />
                            <p className="text-sm font-bold">{selectedService.rating}</p>
                            <p className="text-xs text-secondary-label">Рейтинг</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Benefits Card */}
                    <div className="bg-gradient-to-r from-system-purple/5 to-system-pink/5 rounded-2xl p-4 border border-system-purple/20 animate-in slide-in-from-bottom duration-500 delay-600">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-system-purple/20 rounded-full flex items-center justify-center">
                          <Activity className="w-5 h-5 text-system-purple" />
                        </div>
                        <div>
                          <p className="ios-body font-semibold text-system-purple">
                            {selectedService.specialty ? 'Персональный подход' : 'Групповые тренировки'}
                          </p>
                          <p className="ios-caption1 text-secondary-label">
                            {selectedService.specialty 
                              ? 'Индивидуальная программа для достижения ваших целей'
                              : 'Мотивирующая атмосфера и профессиональный инструктор'
                            }
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced Modal Footer */}
              <div className="bg-white/95 backdrop-blur-md border-t border-separator/30">
                <div className="max-w-md mx-auto px-6 py-4">
                  <button 
                    className="w-full bg-gradient-to-r from-system-green to-system-teal text-white font-bold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-3 animate-in slide-in-from-bottom duration-500 delay-700"
                    onClick={closeServiceModal}
                    data-testid="button-book"
                  >
                    <Calendar className="w-5 h-5" />
                    <span>Записаться</span>
                    <span className="bg-white/20 px-2 py-1 rounded-lg text-sm">
                      {selectedService.price} $
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}