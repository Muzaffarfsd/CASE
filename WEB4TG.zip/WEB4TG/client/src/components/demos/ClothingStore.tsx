import { useState } from "react";
import { 
  Shirt, 
  ShoppingBag, 
  Heart, 
  Star, 
  Plus, 
  Minus, 
  X, 
  ChevronRight,
  Grid,
  Tag,
  Filter,
  Search
} from "lucide-react";

interface ClothingStoreProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  size: string;
  quantity: number;
  image: string;
}

const products = [
  { id: 1, name: 'Летний Топ', price: 79, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Легкий хлопковый топ с воздушной текстурой, идеален для жарких дней', sizes: ['XS', 'S', 'M', 'L'], colors: ['Белый', 'Розовый', 'Голубой'], category: 'Топы', inStock: 15, rating: 4.8 },
  { id: 2, name: 'Дизайнерская Блуза', price: 95, image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Элегантная шелковая блуза с утонченным кроем и изысканной отделкой', sizes: ['S', 'M', 'L'], colors: ['Черный', 'Белый'], category: 'Блузы', inStock: 8, rating: 4.9 },
  { id: 3, name: 'Джинсы Casual', price: 65, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Комфортные джинсы прямого кроя из премиум денима, подходят для любого случая', sizes: ['26', '27', '28', '29'], colors: ['Синий', 'Черный'], category: 'Джинсы', inStock: 12, rating: 4.7 },
  { id: 4, name: 'Вечернее Платье', price: 125, image: 'https://images.unsplash.com/photo-1566479179817-c96d1d86b4a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Роскошное вечернее платье с атласной отделкой и изящным силуэтом', sizes: ['XS', 'S', 'M'], colors: ['Черный', 'Бордовый'], category: 'Платья', inStock: 6, rating: 5.0 },
  { id: 5, name: 'Блейзер', price: 89, image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильный блейзер с классическими лацканами и подчеркнутой талией', sizes: ['S', 'M', 'L'], colors: ['Серый', 'Черный'], category: 'Пиджаки', inStock: 10, rating: 4.6 },
  { id: 6, name: 'Юбка', price: 55, image: 'https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Универсальная юбка-карандаш средней длины с высокой посадкой', sizes: ['XS', 'S', 'M'], colors: ['Черный', 'Серый'], category: 'Юбки', inStock: 18, rating: 4.4 },
  { id: 7, name: 'Кардиган', price: 72, image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Мягкий кашемировый кардиган с V-образным вырезом и удлиненным силуэтом', sizes: ['S', 'M', 'L'], colors: ['Бежевый', 'Серый'], category: 'Кардиганы', inStock: 14, rating: 4.8 },
  { id: 8, name: 'Свитер Оверсайз', price: 85, image: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уютный свитер oversize из мериносовой шерсти с объемными рукавами', sizes: ['S', 'M', 'L', 'XL'], colors: ['Кремовый', 'Серый', 'Терракотовый'], category: 'Свитеры', inStock: 9, rating: 4.7 },
  { id: 9, name: 'Брюки Wide Leg', price: 78, image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Трендовые брюки широкого кроя с высокой талией и поясом', sizes: ['XS', 'S', 'M', 'L'], colors: ['Черный', 'Бежевый', 'Оливковый'], category: 'Брюки', inStock: 11, rating: 4.5 },
  { id: 10, name: 'Куртка Бомбер', price: 120, image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильная куртка-бомбер из качественной экокожи с металлической фурнитурой', sizes: ['S', 'M', 'L'], colors: ['Черный', 'Коричневый'], category: 'Куртки', inStock: 7, rating: 4.9 },
  { id: 11, name: 'Платье Миди', price: 98, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Женственное платье-миди с цветочным принтом и поясом на талии', sizes: ['XS', 'S', 'M', 'L'], colors: ['Цветочный', 'Однотонный синий'], category: 'Платья', inStock: 13, rating: 4.6 },
  { id: 12, name: 'Рубашка Классическая', price: 65, image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классическая белая рубашка из хлопка с манжетами и воротником', sizes: ['S', 'M', 'L', 'XL'], colors: ['Белый', 'Голубой'], category: 'Рубашки', inStock: 16, rating: 4.8 },
  { id: 13, name: 'Пальто Удлиненное', price: 185, image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Элегантное удлиненное пальто из шерстяного микса с поясом', sizes: ['S', 'M', 'L'], colors: ['Кэмел', 'Черный', 'Серый'], category: 'Пальто', inStock: 5, rating: 4.9 },
  { id: 14, name: 'Шорты Высокая Посадка', price: 48, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильные джинсовые шорты с высокой посадкой и подворотами', sizes: ['XS', 'S', 'M', 'L'], colors: ['Светло-синий', 'Темно-синий'], category: 'Шорты', inStock: 20, rating: 4.4 },
  { id: 15, name: 'Водолазка', price: 52, image: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Базовая водолазка из мягкого трикотажа с высоким воротником', sizes: ['XS', 'S', 'M', 'L', 'XL'], colors: ['Черный', 'Белый', 'Серый', 'Темно-синий'], category: 'Топы', inStock: 22, rating: 4.7 },
  { id: 16, name: 'Комбинезон', price: 115, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Модный комбинезон с широкими штанинами и поясом на талии', sizes: ['S', 'M', 'L'], colors: ['Черный', 'Хаки'], category: 'Комбинезоны', inStock: 8, rating: 4.5 },
  { id: 17, name: 'Жилет Трикотажный', price: 62, image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильный трикотажный жилет без рукавов с V-образным вырезом', sizes: ['S', 'M', 'L'], colors: ['Бежевый', 'Коричневый', 'Черный'], category: 'Жилеты', inStock: 12, rating: 4.6 },
  { id: 18, name: 'Плащ Тренч', price: 145, image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический тренч из водостойкой ткани с поясом и погонами', sizes: ['S', 'M', 'L'], colors: ['Бежевый', 'Черный'], category: 'Плащи', inStock: 6, rating: 4.8 },
  { id: 19, name: 'Леггинсы Спортивные', price: 42, image: 'https://images.unsplash.com/photo-1506629905183-462b7b3e9004?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Удобные спортивные леггинсы из дышащей ткани с высокой посадкой', sizes: ['XS', 'S', 'M', 'L'], colors: ['Черный', 'Серый', 'Темно-синий'], category: 'Спорт', inStock: 25, rating: 4.5 },
  { id: 20, name: 'Худи Oversize', price: 88, image: 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильное худи oversize из плотного хлопка с капюшоном и карманом-кенгуру', sizes: ['S', 'M', 'L', 'XL'], colors: ['Серый', 'Черный', 'Белый', 'Бежевый'], category: 'Худи', inStock: 17, rating: 4.7 }
];

const categories = ['Все', 'Топы', 'Платья', 'Джинсы', 'Блузы', 'Пиджаки', 'Свитеры', 'Брюки', 'Куртки', 'Рубашки', 'Пальто', 'Шорты', 'Комбинезоны', 'Жилеты', 'Плащи', 'Спорт', 'Худи'];

const initialCartItems: CartItem[] = [
  { id: 1, name: 'Летний Топ', price: 79, size: 'M', quantity: 1, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
  { id: 2, name: 'Дизайнерская Блуза', price: 95, size: 'S', quantity: 1, image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
];

export default function ClothingStore({ activeTab }: ClothingStoreProps) {
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 4]);

  const openProductModal = (product: typeof products[0]) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeProductModal = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCartItems(prev => 
      prev.map(item => 
        item.id === itemId 
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const calculateTotal = () => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const toggleFavorite = (productId: number) => {
    setFavorites(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const filteredProducts = selectedCategory === 'Все' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const renderHomeTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Hero Section */}
        <section className="ios-slide-up">
          <div className="ios-card overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"
              alt="Fashion collection"
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="ios-title3 mb-2">Весенняя Коллекция 2024</h2>
              <p className="ios-body text-secondary-label mb-4">
                Откройте последние тенденции моды
              </p>
              <button className="ios-button-filled" data-testid="button-shop-now">
                Смотреть коллекцию
              </button>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Категории</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="ios-card p-4 text-center cursor-pointer" data-testid="category-tops">
              <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <Shirt className="w-6 h-6 text-system-blue" />
              </div>
              <p className="ios-footnote font-semibold">Топы и Блузы</p>
            </div>
            <div className="ios-card p-4 text-center cursor-pointer" data-testid="category-dresses">
              <div className="w-12 h-12 bg-system-purple/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <Grid className="w-6 h-6 text-system-purple" />
              </div>
              <p className="ios-footnote font-semibold">Платья</p>
            </div>
          </div>
        </section>

        {/* Popular Items */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Популярное</h3>
          <div className="grid grid-cols-2 gap-3">
            {products.slice(0, 4).map((product) => (
              <div 
                key={product.id} 
                className="ios-card overflow-hidden cursor-pointer" 
                onClick={() => openProductModal(product)}
                data-testid={`product-card-${product.id}`}
              >
                <div className="relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-32 object-cover aspect-square"
                    loading="lazy"
                  />
                  <button
                    className="absolute top-2 right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(product.id);
                    }}
                  >
                    <Heart className={`w-4 h-4 ${
                      favorites.includes(product.id) 
                        ? 'text-system-red fill-current' 
                        : 'text-secondary-label'
                    }`} />
                  </button>
                </div>
                <div className="p-3">
                  <p className="ios-footnote font-semibold text-label">{product.name}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="ios-caption font-bold text-system-blue">{product.price} ₽</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-system-orange" />
                      <span className="ios-caption2 text-secondary-label">{product.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Search and Filters */}
        <section className="ios-slide-up">
          <div className="ios-card p-4 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="flex-1 flex items-center space-x-2 bg-secondary-system-fill rounded-lg px-3 py-2">
                <Search className="w-4 h-4 text-secondary-label" />
                <input
                  type="text"
                  placeholder="Поиск товаров..."
                  className="flex-1 bg-transparent border-none outline-none ios-body"
                />
              </div>
              <button className="w-10 h-10 bg-system-blue/10 rounded-lg flex items-center justify-center">
                <Filter className="w-5 h-5 text-system-blue" />
              </button>
            </div>
          </div>
        </section>

        {/* Category Filter */}
        <section className="ios-slide-up">
          <div className="ios-segmented overflow-x-auto">
            <div className="flex space-x-1 min-w-max">
              {categories.map((category) => (
                <button
                  key={category}
                  className={`${
                    selectedCategory === category ? 'ios-segmented-item-active' : 'ios-segmented-item'
                  } whitespace-nowrap`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="ios-slide-up">
          <div className="grid grid-cols-2 gap-3">
            {filteredProducts.map((product) => (
              <div 
                key={product.id} 
                className="ios-card overflow-hidden cursor-pointer" 
                onClick={() => openProductModal(product)}
                data-testid={`catalog-product-${product.id}`}
              >
                <div className="relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-40 object-cover aspect-square"
                    loading="lazy"
                  />
                  <button
                    className="absolute top-2 right-2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(product.id);
                    }}
                  >
                    <Heart className={`w-4 h-4 ${
                      favorites.includes(product.id) 
                        ? 'text-system-red fill-current' 
                        : 'text-secondary-label'
                    }`} />
                  </button>
                  {product.inStock < 10 && (
                    <div className="absolute top-2 left-2 px-2 py-1 bg-system-orange rounded-md">
                      <span className="ios-caption2 text-white font-semibold">
                        {product.inStock} шт
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <p className="ios-footnote font-semibold text-label">{product.name}</p>
                  <p className="ios-caption2 text-secondary-label mt-1">{product.description}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="ios-body font-bold text-system-blue">{product.price} ₽</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-system-orange" />
                      <span className="ios-caption2 text-secondary-label">{product.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {cartItems.length === 0 ? (
          <div className="ios-card p-8 text-center">
            <ShoppingBag className="w-12 h-12 text-secondary-label mx-auto mb-4" />
            <h3 className="ios-title3 mb-2">Корзина пуста</h3>
            <p className="ios-body text-secondary-label mb-4">
              Добавьте товары для покупки
            </p>
            <button className="ios-button-filled">
              Перейти к покупкам
            </button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <section className="ios-slide-up">
              <div className="ios-list">
                <div className="ios-list-header">Товары в корзине</div>
                {cartItems.map((item) => (
                  <div key={item.id} className="ios-list-item" data-testid={`cart-item-${item.id}`}>
                    <div className="flex items-center space-x-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <div className="ios-body font-semibold">{item.name}</div>
                        <div className="ios-footnote text-secondary-label">
                          Размер: {item.size}
                        </div>
                        <div className="ios-footnote font-bold text-system-blue">
                          {item.price} ₽
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <button
                          className="w-8 h-8 bg-secondary-system-fill rounded-full flex items-center justify-center"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="ios-body font-semibold w-6 text-center">
                          {item.quantity}
                        </span>
                        <button
                          className="w-8 h-8 bg-system-blue rounded-full flex items-center justify-center"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4 text-white" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Order Summary */}
            <section className="ios-slide-up">
              <div className="ios-card p-4 space-y-3">
                <h3 className="ios-headline font-semibold">Итого</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="ios-body text-secondary-label">Товары</span>
                    <span className="ios-body">{calculateTotal()} ₽</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="ios-body text-secondary-label">Доставка</span>
                    <span className="ios-body text-system-green">Бесплатно</span>
                  </div>
                  <div className="border-t border-separator pt-2">
                    <div className="flex justify-between">
                      <span className="ios-headline font-bold">Всего</span>
                      <span className="ios-title3 font-bold text-system-blue">
                        {calculateTotal()} ₽
                      </span>
                    </div>
                  </div>
                </div>
                <button className="ios-button-filled w-full mt-4" data-testid="button-checkout">
                  Оформить заказ
                </button>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );

  const renderProfileTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* User Profile */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 text-center">
            <div className="w-16 h-16 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-8 h-8 text-system-blue" />
            </div>
            <h2 className="ios-title2 mb-2">Анна Петрова</h2>
            <p className="ios-footnote text-secondary-label">
              VIP покупатель
            </p>
          </div>
        </section>

        {/* Menu Options */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <Heart className="w-5 h-5 text-system-red" />
                <div className="flex-1">
                  <div className="ios-body">Избранное</div>
                  <div className="ios-footnote text-secondary-label">
                    {favorites.length} товаров
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <ShoppingBag className="w-5 h-5 text-system-blue" />
                <div className="flex-1">
                  <div className="ios-body">Мои заказы</div>
                  <div className="ios-footnote text-secondary-label">
                    История покупок
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <Tag className="w-5 h-5 text-system-orange" />
                <div className="flex-1">
                  <div className="ios-body">Промокоды</div>
                  <div className="ios-footnote text-secondary-label">
                    Скидки и акции
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return renderHomeTab();
      case 'catalog':
        return renderCatalogTab();
      case 'cart':
        return renderCartTab();
      case 'profile':
        return renderProfileTab();
      default:
        return renderHomeTab();
    }
  };

  return (
    <>
      {renderContent()}

      {/* Premium Product Detail Modal */}
      {isModalOpen && selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm animate-in fade-in duration-300" data-testid="product-modal">
          <div className="safe-area-top h-full flex flex-col">
            {/* Animated Modal Container */}
            <div className="bg-white rounded-t-3xl mt-16 flex-1 overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-500">
              {/* Enhanced Modal Header */}
              <div className="relative bg-gradient-to-r from-white via-white/95 to-white backdrop-blur-md border-b border-separator/30">
                <div className="max-w-md mx-auto flex items-center justify-between px-6 py-4">
                  <button
                    onClick={closeProductModal}
                    className="w-10 h-10 bg-secondary-system-fill rounded-full flex items-center justify-center hover:bg-tertiary-system-fill transition-all duration-200 active:scale-95"
                    data-testid="button-close-modal"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <h1 className="ios-headline font-bold text-center flex-1">✨ Детали товара</h1>
                  <button 
                    className="w-10 h-10 bg-secondary-system-fill rounded-full flex items-center justify-center hover:bg-red-50 transition-all duration-200 active:scale-95"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(selectedProduct.id);
                    }}
                  >
                    <Heart className={`w-5 h-5 transition-all duration-200 ${
                      favorites.includes(selectedProduct.id) 
                        ? 'text-system-red fill-current scale-110' 
                        : 'text-secondary-label hover:text-system-red'
                    }`} />
                  </button>
                </div>
              </div>

              {/* Enhanced Modal Content */}
              <div className="flex-1 overflow-y-auto">
                <div className="max-w-md mx-auto">
                  {/* Hero Image with Overlays */}
                  <div className="relative overflow-hidden">
                    <img
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      className="w-full h-80 object-cover transition-transform duration-700 hover:scale-105"
                      onError={(e) => {
                        e.currentTarget.src = `https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400`;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
                    
                    {/* Premium Badge */}
                    <div className="absolute top-4 left-4 animate-in slide-in-from-left duration-700">
                      <div className="bg-gradient-to-r from-system-yellow to-system-orange px-3 py-1.5 rounded-full shadow-lg">
                        <span className="text-white text-xs font-bold">PREMIUM</span>
                      </div>
                    </div>
                    
                    {/* Rating Badge */}
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-right duration-700">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-system-yellow fill-current" />
                        <span className="text-sm font-bold">{selectedProduct.rating}</span>
                      </div>
                    </div>
                    
                    {/* Stock Badge */}
                    <div className="absolute bottom-4 right-4 bg-system-green/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-bottom duration-700">
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                        <span className="text-white text-xs font-medium">{selectedProduct.inStock} в наличии</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="px-6 py-6 space-y-6">
                    {/* Product Info */}
                    <div className="space-y-4 animate-in slide-in-from-bottom duration-500 delay-200">
                      <div>
                        <h2 className="ios-title1 font-bold mb-3 bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                          {selectedProduct.name}
                        </h2>
                        <p className="ios-body text-secondary-label leading-relaxed">
                          {selectedProduct.description}
                        </p>
                      </div>
                    </div>
                    
                    {/* Price Card */}
                    <div className="bg-gradient-to-r from-system-blue/5 via-system-purple/5 to-system-pink/5 rounded-2xl p-6 border border-system-blue/10 shadow-sm animate-in slide-in-from-bottom duration-500 delay-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="ios-large-title font-black bg-gradient-to-r from-system-blue to-system-purple bg-clip-text text-transparent">
                            {selectedProduct.price} ₽
                          </span>
                          <p className="ios-caption1 text-secondary-label mt-1">
                            Специальная цена
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-1 justify-end">
                            <Star className="w-5 h-5 text-system-orange fill-current" />
                            <span className="ios-headline font-bold">{selectedProduct.rating}</span>
                          </div>
                          <p className="ios-caption1 text-secondary-label">
                            Отличный рейтинг
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Size Selection */}
                    <div className="bg-white rounded-2xl border border-separator/50 p-4 shadow-sm animate-in slide-in-from-bottom duration-500 delay-400">
                      <h3 className="ios-headline font-semibold mb-3 flex items-center">
                        <Tag className="w-4 h-4 mr-2 text-system-blue" />
                        Выберите размер
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedProduct.sizes.map((size, index) => (
                          <button
                            key={size}
                            className="px-4 py-2 bg-system-blue/10 text-system-blue rounded-xl text-sm font-medium border border-system-blue/20 hover:bg-system-blue hover:text-white transition-all duration-200 active:scale-95"
                            style={{ animationDelay: `${index * 100}ms` }}
                          >
                            {size}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Color Selection */}
                    <div className="bg-white rounded-2xl border border-separator/50 p-4 shadow-sm animate-in slide-in-from-bottom duration-500 delay-500">
                      <h3 className="ios-headline font-semibold mb-3 flex items-center">
                        <div className="w-4 h-4 mr-2 bg-gradient-to-r from-red-400 to-blue-400 rounded-full"></div>
                        Доступные цвета
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedProduct.colors.map((color, index) => (
                          <button
                            key={color}
                            className="px-4 py-2 bg-system-purple/10 text-system-purple rounded-xl text-sm font-medium border border-system-purple/20 hover:bg-system-purple hover:text-white transition-all duration-200 active:scale-95"
                            style={{ animationDelay: `${index * 100}ms` }}
                          >
                            {color}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Features Card */}
                    <div className="bg-gradient-to-r from-system-green/5 to-system-teal/5 rounded-2xl p-4 border border-system-green/20 animate-in slide-in-from-bottom duration-500 delay-600">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-system-green/20 rounded-full flex items-center justify-center">
                          <Shirt className="w-5 h-5 text-system-green" />
                        </div>
                        <div>
                          <p className="ios-body font-semibold text-system-green">
                            Качество Premium
                          </p>
                          <p className="ios-caption1 text-secondary-label">
                            Высококачественные материалы и профессиональный пошив
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced Modal Footer */}
              <div className="bg-white/95 backdrop-blur-md border-t border-separator/30">
                <div className="max-w-md mx-auto px-6 py-4">
                  <button 
                    className="w-full bg-gradient-to-r from-system-blue to-system-purple text-white font-bold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-3 animate-in slide-in-from-bottom duration-500 delay-700"
                    onClick={closeProductModal}
                    data-testid="button-add-to-cart"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    <span>Добавить в корзину</span>
                    <span className="bg-white/20 px-2 py-1 rounded-lg text-sm">
                      {selectedProduct.price} ₽
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}