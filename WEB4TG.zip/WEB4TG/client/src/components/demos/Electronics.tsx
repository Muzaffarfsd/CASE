import { useState } from "react";
import { 
  Smartphone, 
  Heart, 
  Star, 
  ShoppingCart, 
  Zap,
  Plus,
  Minus,
  X,
  ChevronRight,
  Monitor,
  Headphones,
  Camera,
  Search
} from "lucide-react";

interface ElectronicsProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

const products = [
  { id: 1, name: 'iPhone 15 Pro Max', price: 1199, image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Флагманский смартфон Apple с чипом A17 Pro и титановым корпусом', category: 'Смартфоны', brand: 'Apple', inStock: 15, rating: 4.9, specs: ['6.7" дисплей', '256GB памяти', 'Тройная камера'] },
  { id: 2, name: 'Samsung Galaxy S24 Ultra', price: 1099, image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Премиальный Android-смартфон с S Pen и AI-функциями', category: 'Смартфоны', brand: 'Samsung', inStock: 12, rating: 4.8, specs: ['6.8" дисплей', '512GB памяти', 'Квадро камера'] },
  { id: 3, name: 'MacBook Pro 16"', price: 2499, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Мощный ноутбук для профессионалов с чипом M3 Max', category: 'Ноутбуки', brand: 'Apple', inStock: 8, rating: 4.9, specs: ['M3 Max чип', '32GB RAM', '1TB SSD'] },
  { id: 4, name: 'Dell XPS 13', price: 1299, image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Компактный и производительный ультрабук для работы', category: 'Ноутбуки', brand: 'Dell', inStock: 10, rating: 4.7, specs: ['Intel i7-1365U', '16GB RAM', '512GB SSD'] },
  { id: 5, name: 'iPad Pro 12.9"', price: 1099, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональный планшет с M2 чипом и поддержкой Apple Pencil', category: 'Планшеты', brand: 'Apple', inStock: 14, rating: 4.8, specs: ['M2 чип', '128GB памяти', 'Liquid Retina дисплей'] },
  { id: 6, name: 'Sony WH-1000XM5', price: 399, image: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Беспроводные наушники с лучшим шумоподавлением', category: 'Наушники', brand: 'Sony', inStock: 25, rating: 4.8, specs: ['30 часов работы', 'Bluetooth 5.2', 'Шумоподавление'] },
  { id: 7, name: 'AirPods Pro 2', price: 249, image: 'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Беспроводные наушники Apple с адаптивным шумоподавлением', category: 'Наушники', brand: 'Apple', inStock: 30, rating: 4.7, specs: ['H2 чип', '6 часов работы', 'Пространственный звук'] },
  { id: 8, name: 'Canon EOS R6 Mark II', price: 2499, image: 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональная беззеркальная камера для фото и видео', category: 'Камеры', brand: 'Canon', inStock: 6, rating: 4.9, specs: ['24.2MP сенсор', '4K видео', 'Стабилизация'] },
  { id: 9, name: 'GoPro Hero 12', price: 399, image: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Экшн-камера для съемки приключений в 5.3K', category: 'Камеры', brand: 'GoPro', inStock: 18, rating: 4.6, specs: ['5.3K видео', 'Водонепроницаемая', 'HyperSmooth 6.0'] },
  { id: 10, name: 'LG OLED C3 55"', price: 1599, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'OLED телевизор с идеальными черными и яркими цветами', category: 'Телевизоры', brand: 'LG', inStock: 7, rating: 4.8, specs: ['OLED экран', '4K разрешение', 'WebOS 23'] },
  { id: 11, name: 'PlayStation 5', price: 499, image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Игровая консоль нового поколения от Sony', category: 'Игровые консоли', brand: 'Sony', inStock: 20, rating: 4.7, specs: ['Кастомный SSD', '4K игры', 'DualSense контроллер'] },
  { id: 12, name: 'Xbox Series X', price: 499, image: 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Мощная игровая консоль Microsoft с Quick Resume', category: 'Игровые консоли', brand: 'Microsoft', inStock: 15, rating: 4.6, specs: ['12 TFlops GPU', '1TB SSD', 'Quick Resume'] },
  { id: 13, name: 'Apple Watch Series 9', price: 399, image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Умные часы с Double Tap и улучшенным дисплеем', category: 'Умные часы', brand: 'Apple', inStock: 22, rating: 4.8, specs: ['S9 чип', 'Always-On дисплей', 'Датчики здоровья'] },
  { id: 14, name: 'Samsung Galaxy Watch 6', price: 329, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Android-совместимые часы с расширенным мониторингом сна', category: 'Умные часы', brand: 'Samsung', inStock: 18, rating: 4.5, specs: ['Wear OS', 'Анализ сна', 'GPS'] },
  { id: 15, name: 'Steam Deck OLED', price: 649, image: 'https://images.unsplash.com/photo-1625842268584-8f3296236761?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Портативная игровая консоль с OLED экраном', category: 'Портативные консоли', brand: 'Valve', inStock: 12, rating: 4.7, specs: ['OLED дисплей', 'AMD APU', 'Steam OS'] },
  { id: 16, name: 'Nintendo Switch OLED', price: 349, image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Гибридная консоль с улучшенным OLED экраном', category: 'Портативные консоли', brand: 'Nintendo', inStock: 25, rating: 4.6, specs: ['7" OLED экран', '64GB память', 'Joy-Con контроллеры'] },
  { id: 17, name: 'DJI Mini 4 Pro', price: 759, image: 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Компактный дрон с 4K камерой и функциями ИИ', category: 'Дроны', brand: 'DJI', inStock: 9, rating: 4.8, specs: ['4K/60fps камера', '34 мин полета', 'Препятствия'] },
  { id: 18, name: 'Razer DeathAdder V3', price: 89, image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Игровая мышь с фокусом 30K DPI и беспроводным подключением', category: 'Игровые аксессуары', brand: 'Razer', inStock: 35, rating: 4.5, specs: ['30K DPI сенсор', '90 часов работы', 'Эргономичная форма'] },
  { id: 19, name: 'Logitech MX Master 3S', price: 99, image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональная мышь для дизайнеров и программистов', category: 'Компьютерные аксессуары', brand: 'Logitech', inStock: 28, rating: 4.7, specs: ['8K DPI сенсор', '70 дней работы', 'MagSpeed колесо'] },
  { id: 20, name: 'Anker PowerCore 26800', price: 65, image: 'https://images.unsplash.com/photo-1609592806752-3359833bb0de?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Мощный внешний аккумулятор с быстрой зарядкой', category: 'Аксессуары', brand: 'Anker', inStock: 40, rating: 4.6, specs: ['26800mAh емкость', '3 USB порта', 'PowerIQ технология'] }
];

const categories = ['Все', 'Смартфоны', 'Ноутбуки', 'Планшеты', 'Наушники', 'Камеры', 'Телевизоры', 'Игровые консоли', 'Умные часы', 'Портативные консоли', 'Дроны', 'Аксессуары'];

const brands = ['Все', 'Apple', 'Samsung', 'Sony', 'Dell', 'Canon', 'LG', 'Microsoft', 'Valve', 'Nintendo', 'DJI', 'Razer', 'Logitech', 'Anker', 'GoPro'];

const initialCartItems: CartItem[] = [
  { id: 6, name: 'Sony WH-1000XM5', price: 399, quantity: 1, image: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
  { id: 13, name: 'Apple Watch Series 9', price: 399, quantity: 1, image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
];

export default function Electronics({ activeTab }: ElectronicsProps) {
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [selectedBrand, setSelectedBrand] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 3, 6, 11]);
  const [searchQuery, setSearchQuery] = useState('');

  const openProductModal = (product: typeof products[0]) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeProductModal = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCartItems(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeFromCart = (itemId: number) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const toggleFavorite = (productId: number) => {
    setFavorites(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'Все' || product.category === selectedCategory;
    const matchesBrand = selectedBrand === 'Все' || product.brand === selectedBrand;
    const matchesSearch = searchQuery === '' || 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesBrand && matchesSearch;
  });

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">ТехХаб Магазин</h1>
        <p className="ios-subheadline text-secondary-label">Новейшая техника и гаджеты ⚡</p>
      </div>

      {/* Баннер */}
      <div className="ios-card p-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="ios-headline font-semibold">Черная Пятница</h3>
            <p className="ios-body">Скидки до 40% на всю технику</p>
          </div>
          <Zap className="w-8 h-8" />
        </div>
      </div>

      {/* Категории */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Категории товаров</h2>
        <div className="grid grid-cols-4 gap-3">
          {[
            { name: 'Смартфоны', icon: Smartphone, color: 'bg-blue-500' },
            { name: 'Ноутбуки', icon: Monitor, color: 'bg-purple-500' },
            { name: 'Наушники', icon: Headphones, color: 'bg-green-500' },
            { name: 'Камеры', icon: Camera, color: 'bg-red-500' }
          ].map((category) => (
            <div 
              key={category.name} 
              className="ios-card p-3 text-center cursor-pointer"
              onClick={() => setSelectedCategory(category.name)}
            >
              <div className={`w-10 h-10 ${category.color} rounded-full flex items-center justify-center mx-auto mb-2`}>
                <category.icon className="w-5 h-5 text-white" />
              </div>
              <span className="ios-caption2 font-medium">{category.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Хиты продаж */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Хиты продаж</h2>
        <div className="grid grid-cols-2 gap-3">
          {products.slice(0, 4).map((product) => (
            <div 
              key={product.id} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => openProductModal(product)}
            >
              <img src={product.image} alt={product.name} className="w-full h-24 object-cover rounded-lg mb-2" />
              <h4 className="ios-footnote font-semibold line-clamp-2">{product.name}</h4>
              <p className="ios-caption2 text-secondary-label mb-2">{product.brand}</p>
              <div className="flex items-center justify-between">
                <span className="ios-caption font-bold text-system-cyan">${product.price}</span>
                <div className="flex items-center space-x-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="ios-caption2">{product.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Информация о магазине */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Почему выбирают нас</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-system-cyan" />
            <span className="ios-body">Быстрая доставка в течение дня</span>
          </div>
          <div className="flex items-center space-x-2">
            <ShoppingCart className="w-4 h-4 text-system-cyan" />
            <span className="ios-body">Оригинальная техника с гарантией</span>
          </div>
          <div className="flex items-center space-x-2">
            <Heart className="w-4 h-4 text-system-cyan" />
            <span className="ios-body">Лучшие цены и скидки для клиентов</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Каталог техники</h1>
      
      {/* Поиск */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-secondary-label" />
        <input
          type="text"
          placeholder="Поиск товаров..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-quaternary-system-fill rounded-xl ios-body"
        />
      </div>

      {/* Фильтры */}
      <div className="space-y-3">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
                selectedCategory === category
                  ? 'bg-system-cyan text-white'
                  : 'bg-quaternary-system-fill text-label'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
        
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {brands.map((brand) => (
            <button
              key={brand}
              onClick={() => setSelectedBrand(brand)}
              className={`px-3 py-1 rounded-full whitespace-nowrap ios-caption2 font-medium ${
                selectedBrand === brand
                  ? 'bg-system-blue text-white'
                  : 'bg-fill text-secondary-label'
              }`}
            >
              {brand}
            </button>
          ))}
        </div>
      </div>

      {/* Список товаров */}
      <div className="space-y-3">
        {filteredProducts.map((product) => (
          <div 
            key={product.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openProductModal(product)}
          >
            <div className="flex items-center space-x-3">
              <img src={product.image} alt={product.name} className="w-20 h-20 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold line-clamp-1">{product.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(product.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(product.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-2 line-clamp-2">{product.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="ios-caption2 px-2 py-1 bg-quaternary-system-fill rounded">{product.brand}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="ios-caption2">{product.rating}</span>
                    </div>
                  </div>
                  <span className="ios-body font-bold text-system-cyan">${product.price}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Корзина</h1>
      
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingCart className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Корзина пуста</p>
          <p className="ios-footnote text-tertiary-label">Добавьте товары из каталога</p>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {cartItems.map((item) => (
              <div key={item.id} className="ios-card p-4">
                <div className="flex items-center space-x-3">
                  <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-lg" />
                  <div className="flex-1">
                    <h4 className="ios-body font-semibold">{item.name}</h4>
                    <p className="ios-footnote text-secondary-label">${item.price} за шт.</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full bg-quaternary-system-fill flex items-center justify-center"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="ios-body font-semibold w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full bg-system-cyan text-white flex items-center justify-center"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="ios-body font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ios-footnote text-system-red"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-card p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="ios-body">Подытог:</span>
              <span className="ios-body font-semibold">${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="ios-body">Доставка:</span>
              <span className="ios-body font-semibold">Бесплатно</span>
            </div>
            <hr className="border-separator" />
            <div className="flex justify-between items-center">
              <span className="ios-headline font-bold">Итого:</span>
              <span className="ios-headline font-bold text-system-cyan">${cartTotal.toFixed(2)}</span>
            </div>
            
            <button className="w-full bg-system-cyan text-white ios-body font-semibold py-3 rounded-xl flex items-center justify-center space-x-2">
              <ShoppingCart className="w-5 h-5" />
              <span>Оформить заказ</span>
            </button>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль покупателя</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-cyan rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">ТХ</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">ТехГуру PRO</h3>
            <p className="ios-body text-secondary-label">Продвинутый покупатель</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-cyan">42</p>
            <p className="ios-footnote text-secondary-label">Покупок</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">$2,140</p>
            <p className="ios-footnote text-secondary-label">Сэкономлено</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Избранные товары</h2>
        {products.filter(product => favorites.includes(product.id)).map((product) => (
          <div key={product.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={product.image} alt={product.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold">{product.name}</h4>
              <p className="ios-footnote text-secondary-label">${product.price} • {product.brand}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">История заказов</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Последний заказ:</span>
            <span className="ios-body font-medium">18 дек 2024</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Любимый бренд:</span>
            <span className="ios-body font-medium">Apple</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Потрачено всего:</span>
            <span className="ios-body font-medium text-system-cyan">$12,840</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold line-clamp-2">{selectedProduct.name}</h3>
              <button onClick={closeProductModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <p className="ios-body text-secondary-label">{selectedProduct.description}</p>
              
              <div className="flex items-center space-x-4">
                <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-quaternary-system-fill text-label">
                  {selectedProduct.brand}
                </span>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedProduct.rating}</span>
                </div>
                <span className="ios-footnote text-secondary-label">
                  В наличии: {selectedProduct.inStock} шт.
                </span>
              </div>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Характеристики:</h4>
                <div className="space-y-1">
                  {selectedProduct.specs.map((spec, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-1 h-1 bg-secondary-label rounded-full" />
                      <span className="ios-footnote text-secondary-label">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="ios-title font-bold text-system-cyan">${selectedProduct.price}</span>
                <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-system-green/10 text-system-green">
                  {selectedProduct.category}
                </span>
              </div>
              
              <button className="w-full bg-system-cyan text-white ios-body font-semibold py-3 rounded-xl">
                В корзину
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}