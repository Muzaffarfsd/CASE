import { useState } from "react";
import { 
  CreditCard, 
  Heart, 
  Star, 
  Clock, 
  TrendingUp,
  Plus,
  Minus,
  X,
  ChevronRight,
  Shield,
  Eye,
  EyeOff,
  ArrowUpRight,
  ArrowDownLeft,
  DollarSign,
  PiggyBank
} from "lucide-react";

interface BankingProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface Transaction {
  id: number;
  type: 'income' | 'expense';
  description: string;
  amount: number;
  date: string;
  category: string;
  merchant?: string;
}

const services = [
  { id: 1, name: 'Переводы между счетами', price: 0, image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Мгновенные переводы между вашими счетами без комиссии', category: 'Переводы', features: ['Мгновенно', 'Без комиссии', '24/7'], limit: 'Без ограничений', popular: true },
  { id: 2, name: 'Переводы на карты других банков', price: 1.5, image: 'https://images.unsplash.com/photo-1518458028785-8fbcd101ebb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Переводы на карты любых российских банков', category: 'Переводы', features: ['До 100,000₽', 'Комиссия 1.5%', 'В течение часа'], limit: 'До 1,000,000₽/месяц', popular: true },
  { id: 3, name: 'Оплата коммунальных услуг', price: 0, image: 'https://images.unsplash.com/photo-1520333789090-1afc82db536a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Оплата ЖКХ, интернета, мобильной связи', category: 'Платежи', features: ['Без комиссии', 'Автоплатежи', 'Квитанции'], limit: 'Без ограничений', popular: true },
  { id: 4, name: 'Депозит "Накопительный"', price: 7.5, image: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Выгодный депозит с возможностью пополнения', category: 'Депозиты', features: ['7.5% годовых', 'Пополнение', 'От 10,000₽'], limit: 'До 5,000,000₽', popular: false },
  { id: 5, name: 'Кредитная карта "Платинум"', price: 0, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Премиальная кредитная карта с льготным периодом', category: 'Кредиты', features: ['100 дней без %', 'Кэшбэк до 5%', 'Лимит до 1млн'], limit: 'От 500,000₽', popular: false },
  { id: 6, name: 'Валютная карта', price: 2.5, image: 'https://images.unsplash.com/photo-1607863680198-23d4b2565df0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Карта для операций в валюте без конвертации', category: 'Карты', features: ['USD/EUR/GBP', 'Без конвертации', 'Льготная комиссия'], limit: 'По курсу ЦБ', popular: false },
  { id: 7, name: 'Автокредит "Быстрый"', price: 12.9, image: 'https://images.unsplash.com/photo-1607863680198-23d4b2565df0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Кредит на покупку автомобиля с льготной ставкой', category: 'Кредиты', features: ['От 12.9%', 'До 7 лет', 'Первый взнос от 0%'], limit: 'До 5,000,000₽', popular: true },
  { id: 8, name: 'Ипотека "Семейная"', price: 9.8, image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Льготная ипотека для семей с детьми', category: 'Ипотека', features: ['От 9.8%', 'До 30 лет', 'Господдержка'], limit: 'До 20,000,000₽', popular: true },
  { id: 9, name: 'Страхование автомобиля', price: 3.2, image: 'https://images.unsplash.com/photo-1580566009174-ed76b3f7e34c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Полное страхование автомобиля КАСКО', category: 'Страхование', features: ['Полная защита', 'Эвакуация', 'Ремонт у дилера'], limit: 'По стоимости авто', popular: false },
  { id: 10, name: 'Инвестиционный счет', price: 0, image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Индивидуальный инвестиционный счет с налоговыми льготами', category: 'Инвестиции', features: ['ИИС', 'Налоговый вычет', 'Консультации'], limit: '1,000,000₽/год', popular: false },
  { id: 11, name: 'Мобильный банк "Премиум"', price: 299, image: 'https://images.unsplash.com/photo-1512580938427-a0e04be9e43d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Расширенный пакет услуг мобильного банка', category: 'Услуги', features: ['SMS уведомления', 'Push уведомления', 'Личный менеджер'], limit: '299₽/месяц', popular: false },
  { id: 12, name: 'Корпоративная карта', price: 0, image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Корпоративная карта для бизнес-расходов', category: 'Бизнес', features: ['Отчетность', 'Лимиты', 'Интеграция с 1C'], limit: 'По договору', popular: false },
  { id: 13, name: 'Потребительский кредит', price: 15.9, image: 'https://images.unsplash.com/photo-1518458028785-8fbcd101ebb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Кредит наличными на любые цели', category: 'Кредиты', features: ['От 15.9%', 'До 5 лет', 'Без поручителей'], limit: 'До 3,000,000₽', popular: true },
  { id: 14, name: 'Страхование жизни', price: 1200, image: 'https://images.unsplash.com/photo-1580566009174-ed76b3f7e34c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Накопительное страхование жизни', category: 'Страхование', features: ['Накопления', 'Страховая защита', 'Гарантированный доход'], limit: 'До 10,000,000₽', popular: false },
  { id: 15, name: 'Эквайринг для бизнеса', price: 2.3, image: 'https://images.unsplash.com/photo-1607863680198-23d4b2565df0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Прием платежей по картам в вашем бизнесе', category: 'Бизнес', features: ['2.3% комиссия', 'Онлайн платежи', 'Терминалы'], limit: 'Без ограничений', popular: false },
  { id: 16, name: 'Международные переводы', price: 25, image: 'https://images.unsplash.com/photo-1520333789090-1afc82db536a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Переводы в любую страну мира', category: 'Переводы', features: ['SWIFT', 'До 3 дней', 'Отслеживание'], limit: 'По валютному законодательству', popular: false },
  { id: 17, name: 'Детская карта', price: 0, image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Банковская карта для детей с родительским контролем', category: 'Карты', features: ['Родительский контроль', 'Лимиты', 'Уведомления'], limit: 'По решению родителей', popular: true },
  { id: 18, name: 'Конвертация валют', price: 0.5, image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Обмен валюты по выгодному курсу', category: 'Валютные операции', features: ['Выгодный курс', 'Онлайн обмен', '24/7'], limit: 'По валютному законодательству', popular: false },
  { id: 19, name: 'Овердрафт', price: 18.5, image: 'https://images.unsplash.com/photo-1512580938427-a0e04be9e43d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Краткосрочное кредитование по дебетовой карте', category: 'Кредиты', features: ['18.5% годовых', 'Автоматическое подключение', 'Лимит до 300,000₽'], limit: 'До 300,000₽', popular: false },
  { id: 20, name: 'VIP обслуживание', price: 5000, image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Премиальное банковское обслуживание', category: 'VIP услуги', features: ['Личный менеджер', 'Приоритетное обслуживание', 'Консьерж сервис'], limit: '5,000₽/месяц', popular: false }
];

const categories = ['Все', 'Переводы', 'Платежи', 'Кредиты', 'Карты', 'Депозиты', 'Инвестиции', 'Страхование', 'Бизнес', 'VIP услуги'];

const initialTransactions: Transaction[] = [
  { id: 1, type: 'expense', description: 'Покупка в магазине', amount: 2450, date: 'Сегодня 14:32', category: 'Покупки', merchant: 'Пятёрочка' },
  { id: 2, type: 'income', description: 'Зарплата', amount: 85000, date: 'Вчера 09:00', category: 'Доходы', merchant: 'ООО Компания' },
  { id: 3, type: 'expense', description: 'Оплата интернета', amount: 800, date: '18 дек', category: 'Коммунальные', merchant: 'Ростелеком' },
  { id: 4, type: 'expense', description: 'Такси', amount: 420, date: '17 дек', category: 'Транспорт', merchant: 'СуперТакси' },
  { id: 5, type: 'income', description: 'Перевод от друга', amount: 5000, date: '16 дек', category: 'Переводы', merchant: 'Иван П.' },
];

export default function Banking({ activeTab }: BankingProps) {
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [transactions] = useState<Transaction[]>(initialTransactions);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 2, 3, 8]);
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [balance] = useState(127850);

  const openServiceModal = (service: typeof services[0]) => {
    setSelectedService(service);
    setIsModalOpen(true);
  };

  const closeServiceModal = () => {
    setIsModalOpen(false);
    setSelectedService(null);
  };

  const toggleFavorite = (serviceId: number) => {
    setFavorites(prev => 
      prev.includes(serviceId) 
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const filteredServices = selectedCategory === 'Все' 
    ? services 
    : services.filter(service => service.category === selectedCategory);

  const popularServices = services.filter(service => service.popular);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">БанкОнлайн</h1>
        <p className="ios-subheadline text-secondary-label">Ваш надёжный банк 💳</p>
      </div>

      {/* Баланс */}
      <div className="ios-card p-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="flex items-center justify-between mb-2">
          <h3 className="ios-headline font-semibold">Основной счёт</h3>
          <button onClick={() => setBalanceVisible(!balanceVisible)}>
            {balanceVisible ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
          </button>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="ios-title font-bold">
              {balanceVisible ? `${balance.toLocaleString()}₽` : '••• •••'}
            </p>
            <p className="ios-footnote opacity-80">**** 4589</p>
          </div>
          <CreditCard className="w-8 h-8 opacity-80" />
        </div>
      </div>

      {/* Быстрые действия */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Быстрые действия</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Перевод', icon: ArrowUpRight, color: 'bg-green-500' },
            { name: 'Платежи', icon: DollarSign, color: 'bg-blue-500' },
            { name: 'Депозиты', icon: PiggyBank, color: 'bg-purple-500' },
            { name: 'Кредиты', icon: CreditCard, color: 'bg-orange-500' }
          ].map((action) => (
            <div 
              key={action.name} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => setSelectedCategory(action.name === 'Перевод' ? 'Переводы' : action.name === 'Платежи' ? 'Платежи' : action.name === 'Депозиты' ? 'Депозиты' : 'Кредиты')}
            >
              <div className={`w-12 h-12 ${action.color} rounded-lg mb-2 flex items-center justify-center`}>
                <action.icon className="w-6 h-6 text-white" />
              </div>
              <h4 className="ios-footnote font-semibold">{action.name}</h4>
            </div>
          ))}
        </div>
      </div>

      {/* Последние операции */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Последние операции</h2>
        <div className="space-y-3">
          {transactions.slice(0, 3).map((transaction) => (
            <div key={transaction.id} className="ios-card p-3 flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {transaction.type === 'income' ? 
                  <ArrowDownLeft className="w-5 h-5 text-green-600" /> : 
                  <ArrowUpRight className="w-5 h-5 text-red-600" />
                }
              </div>
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{transaction.description}</h4>
                <p className="ios-footnote text-secondary-label">{transaction.date}</p>
              </div>
              <div className="text-right">
                <p className={`ios-body font-bold ${
                  transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'income' ? '+' : '-'}{transaction.amount.toLocaleString()}₽
                </p>
                <p className="ios-caption2 text-secondary-label">{transaction.category}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Популярные услуги */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Популярные услуги</h2>
        <div className="space-y-3">
          {popularServices.slice(0, 3).map((service) => (
            <div 
              key={service.id} 
              className="ios-card p-3 cursor-pointer flex items-center space-x-3"
              onClick={() => openServiceModal(service)}
            >
              <img src={service.image} alt={service.name} className="w-12 h-12 object-cover rounded-lg" />
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{service.name}</h4>
                <p className="ios-footnote text-secondary-label">{service.category}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-tertiary-label" />
            </div>
          ))}
        </div>
      </div>

      {/* Безопасность */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Ваша безопасность</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-system-blue" />
            <span className="ios-body">Защита средств государством</span>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-system-blue" />
            <span className="ios-body">256-битное шифрование</span>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-system-blue" />
            <span className="ios-body">Двухфакторная аутентификация</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Банковские услуги</h1>
      
      {/* Категории */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
              selectedCategory === category
                ? 'bg-system-blue text-white'
                : 'bg-quaternary-system-fill text-label'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Список услуг */}
      <div className="space-y-3">
        {filteredServices.map((service) => (
          <div 
            key={service.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openServiceModal(service)}
          >
            <div className="flex items-center space-x-3">
              <img src={service.image} alt={service.name} className="w-16 h-16 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold line-clamp-1">{service.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(service.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(service.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-2 line-clamp-2">{service.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="ios-caption2 px-2 py-1 bg-quaternary-system-fill rounded">{service.category}</span>
                    {service.popular && (
                      <span className="ios-caption2 px-2 py-1 bg-system-blue/10 text-system-blue rounded">
                        Популярно
                      </span>
                    )}
                  </div>
                  <span className="ios-body font-bold text-system-blue">
                    {service.price === 0 ? 'Бесплатно' : 
                     service.name.includes('Депозит') || service.name.includes('Кредит') || service.name.includes('Ипотека') || service.name.includes('Овердрафт') ? `${service.price}%` :
                     service.price < 100 ? `${service.price}%` : `${service.price}₽`
                    }
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">История операций</h1>
      
      <div className="space-y-3">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="ios-card p-4">
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {transaction.type === 'income' ? 
                  <ArrowDownLeft className="w-6 h-6 text-green-600" /> : 
                  <ArrowUpRight className="w-6 h-6 text-red-600" />
                }
              </div>
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{transaction.description}</h4>
                <p className="ios-footnote text-secondary-label mb-1">{transaction.merchant}</p>
                <p className="ios-footnote text-secondary-label">{transaction.date}</p>
              </div>
              <div className="text-right">
                <p className={`ios-body font-bold ${
                  transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'income' ? '+' : '-'}{transaction.amount.toLocaleString()}₽
                </p>
                <p className="ios-caption2 px-2 py-1 bg-quaternary-system-fill rounded">
                  {transaction.category}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Статистика за месяц</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-green-600">
              +{transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0).toLocaleString()}₽
            </p>
            <p className="ios-footnote text-secondary-label">Доходы</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-red-600">
              -{transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0).toLocaleString()}₽
            </p>
            <p className="ios-footnote text-secondary-label">Расходы</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль клиента</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-blue rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">БО</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Золотой клиент</h3>
            <p className="ios-body text-secondary-label">Статус: Премиум</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-blue">5</p>
            <p className="ios-footnote text-secondary-label">Лет с нами</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">12</p>
            <p className="ios-footnote text-secondary-label">Услуг</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Мои карты</h2>
        {[
          { name: 'Основная карта', number: '**** 4589', type: 'Дебетовая', balance: balance },
          { name: 'Кредитная карта', number: '**** 7821', type: 'Кредитная', balance: 150000 }
        ].map((card, index) => (
          <div key={index} className="ios-card p-3 flex items-center space-x-3">
            <CreditCard className="w-12 h-12 text-system-blue" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold">{card.name}</h4>
              <p className="ios-footnote text-secondary-label">{card.number} • {card.type}</p>
            </div>
            <div className="text-right">
              <p className="ios-body font-bold">{card.balance.toLocaleString()}₽</p>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Избранные услуги</h2>
        {services.filter(service => favorites.includes(service.id)).map((service) => (
          <div key={service.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={service.image} alt={service.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold line-clamp-1">{service.name}</h4>
              <p className="ios-footnote text-secondary-label">{service.category}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Финансовая статистика</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Средний расход в месяц:</span>
            <span className="ios-body font-medium">45,000₽</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Средний доход в месяц:</span>
            <span className="ios-body font-medium">85,000₽</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Категория трат:</span>
            <span className="ios-body font-medium">Покупки</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedService && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold line-clamp-2">{selectedService.name}</h3>
              <button onClick={closeServiceModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedService.image} alt={selectedService.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <p className="ios-body text-secondary-label">{selectedService.description}</p>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Особенности:</h4>
                <div className="space-y-1">
                  {selectedService.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-system-blue rounded-full"></div>
                      <span className="ios-footnote text-secondary-label">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="ios-card p-3">
                <p className="ios-caption2 text-secondary-label">Лимиты и условия</p>
                <p className="ios-body font-semibold">{selectedService.limit}</p>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="ios-title font-bold text-system-blue">
                  {selectedService.price === 0 ? 'Бесплатно' : 
                   selectedService.name.includes('Депозит') || selectedService.name.includes('Кредит') || selectedService.name.includes('Ипотека') || selectedService.name.includes('Овердрафт') ? `${selectedService.price}% годовых` :
                   selectedService.price < 100 ? `${selectedService.price}% комиссия` : `${selectedService.price}₽`
                  }
                </span>
                {selectedService.popular && (
                  <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-system-blue/10 text-system-blue">
                    Популярная услуга
                  </span>
                )}
              </div>
              
              <button className="w-full bg-system-blue text-white ios-body font-semibold py-3 rounded-xl">
                Оформить услугу
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}