import { useState } from "react";
import { 
  Sparkles, 
  Heart, 
  Star, 
  Clock, 
  Calendar,
  Plus,
  Minus,
  X,
  ChevronRight,
  User,
  MapPin,
  Phone
} from "lucide-react";

interface BeautyProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface Booking {
  id: number;
  serviceName: string;
  date: string;
  time: string;
  specialist: string;
  price: number;
}

const services = [
  { id: 1, name: 'Классическая стрижка', price: 35, image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стрижка с мытьем головы и укладкой', category: 'Парикмахерские услуги', duration: '60 мин', specialist: 'Анна Смирнова', rating: 4.9 },
  { id: 2, name: 'Окрашивание волос', price: 85, image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональное окрашивание премиум красками', category: 'Парикмахерские услуги', duration: '180 мин', specialist: 'Елена Козлова', rating: 4.8 },
  { id: 3, name: 'Мелирование', price: 75, image: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Модное мелирование с тонированием', category: 'Парикмахерские услуги', duration: '150 мин', specialist: 'Мария Петрова', rating: 4.7 },
  { id: 4, name: 'Классический маникюр', price: 25, image: 'https://images.unsplash.com/photo-1604654894610-df63bc138bb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический маникюр с покрытием гель-лак', category: 'Маникюр', duration: '90 мин', specialist: 'Ольга Иванова', rating: 4.8 },
  { id: 5, name: 'Френч маникюр', price: 30, image: 'https://images.unsplash.com/photo-1607779097040-26e80aa78e66?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Элегантный французский маникюр', category: 'Маникюр', duration: '75 мин', specialist: 'Наталья Волкова', rating: 4.9 },
  { id: 6, name: 'Дизайн ногтей', price: 40, image: 'https://images.unsplash.com/photo-1610992015732-2449b2604950?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Художественный дизайн ногтей любой сложности', category: 'Маникюр', duration: '120 мин', specialist: 'Дарья Кузнецова', rating: 4.7 },
  { id: 7, name: 'Классический педикюр', price: 35, image: 'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Аппаратный педикюр с покрытием', category: 'Педикюр', duration: '80 мин', specialist: 'Татьяна Морозова', rating: 4.8 },
  { id: 8, name: 'СПА педикюр', price: 45, image: 'https://images.unsplash.com/photo-1595947006841-0dc64011032e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Расслабляющий СПА педикюр с массажем стоп', category: 'Педикюр', duration: '100 мин', specialist: 'Светлана Белова', rating: 4.9 },
  { id: 9, name: 'Чистка лица', price: 55, image: 'https://images.unsplash.com/photo-1559599238-ce08252b5e8a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Глубокая чистка лица с увлажняющей маской', category: 'Косметология', duration: '90 мин', specialist: 'Юлия Титова', rating: 4.8 },
  { id: 10, name: 'Химический пилинг', price: 70, image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональный химический пилинг для обновления кожи', category: 'Косметология', duration: '60 мин', specialist: 'Анна Соколова', rating: 4.7 },
  { id: 11, name: 'Массаж лица', price: 40, image: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Антивозрастной массаж лица с серумами', category: 'Косметология', duration: '45 мин', specialist: 'Валентина Крылова', rating: 4.6 },
  { id: 12, name: 'Ботокс для волос', price: 120, image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Восстанавливающая процедура для поврежденных волос', category: 'Уход за волосами', duration: '180 мин', specialist: 'Роман Зайцев', rating: 4.9 },
  { id: 13, name: 'Кератиновое выпрямление', price: 150, image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Долговременное выпрямление волос кератином', category: 'Уход за волосами', duration: '240 мин', specialist: 'Игорь Белов', rating: 4.8 },
  { id: 14, name: 'Наращивание ресниц', price: 65, image: 'https://images.unsplash.com/photo-1522338140262-f46f5913618f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классическое наращивание ресниц 1D', category: 'Брови и ресницы', duration: '120 мин', specialist: 'Александра Титова', rating: 4.8 },
  { id: 15, name: 'Объемное наращивание ресниц', price: 85, image: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Объемное наращивание ресниц 2D-3D', category: 'Брови и ресницы', duration: '150 мин', specialist: 'Ксения Орлова', rating: 4.9 },
  { id: 16, name: 'Коррекция бровей', price: 20, image: 'https://images.unsplash.com/photo-1583001004096-77d45bbc3f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Моделирование и коррекция формы бровей', category: 'Брови и ресницы', duration: '30 мин', specialist: 'Лилия Волкова', rating: 4.7 },
  { id: 17, name: 'Окрашивание бровей', price: 15, image: 'https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Профессиональное окрашивание бровей хной или краской', category: 'Брови и ресницы', duration: '45 мин', specialist: 'Виктория Семенова', rating: 4.6 },
  { id: 18, name: 'Релакс массаж', price: 60, image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Расслабляющий массаж всего тела с ароматными маслами', category: 'Массаж', duration: '60 мин', specialist: 'Надежда Крылова', rating: 4.8 },
  { id: 19, name: 'Антицеллюлитный массаж', price: 75, image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Интенсивный массаж для борьбы с целлюлитом', category: 'Массаж', duration: '75 мин', specialist: 'Марина Соколова', rating: 4.7 },
  { id: 20, name: 'Горячий стоун-массаж', price: 90, image: 'https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Эксклюзивный массаж горячими камнями для глубокой релаксации', category: 'Массаж', duration: '90 мин', specialist: 'Елена Морозова', rating: 4.9 }
];

const categories = ['Все', 'Парикмахерские услуги', 'Маникюр', 'Педикюр', 'Косметология', 'Уход за волосами', 'Брови и ресницы', 'Массаж'];

const specialists = [
  { id: 1, name: 'Анна Смирнова', specialty: 'Парикмахер-стилист', experience: '8 лет', rating: 4.9, image: 'https://images.unsplash.com/photo-1594736797933-d0d4bce9b91a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400' },
  { id: 2, name: 'Елена Козлова', specialty: 'Колорист', experience: '6 лет', rating: 4.8, image: 'https://images.unsplash.com/photo-1494790108755-2616c9253e6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400' },
  { id: 3, name: 'Ольга Иванова', specialty: 'Мастер маникюра', experience: '5 лет', rating: 4.8, image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400' },
  { id: 4, name: 'Юлия Титова', specialty: 'Косметолог', experience: '7 лет', rating: 4.8, image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400' }
];

const initialBookings: Booking[] = [
  { id: 1, serviceName: 'Классическая стрижка', date: 'Завтра', time: '14:00', specialist: 'Анна Смирнова', price: 35 },
  { id: 2, serviceName: 'Френч маникюр', date: 'Пятница', time: '16:30', specialist: 'Ольга Иванова', price: 30 },
];

export default function Beauty({ activeTab }: BeautyProps) {
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 4, 14]);

  const openServiceModal = (service: typeof services[0]) => {
    setSelectedService(service);
    setIsModalOpen(true);
  };

  const closeServiceModal = () => {
    setIsModalOpen(false);
    setSelectedService(null);
  };

  const toggleFavorite = (serviceId: number) => {
    setFavorites(prev => 
      prev.includes(serviceId) 
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const filteredServices = selectedCategory === 'Все' 
    ? services 
    : services.filter(service => service.category === selectedCategory);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">Glow Студия</h1>
        <p className="ios-subheadline text-secondary-label">Красота и здоровье ✨</p>
      </div>

      {/* Акции */}
      <div className="ios-card p-4 bg-gradient-to-r from-pink-500 to-purple-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="ios-headline font-semibold">Скидка 20%</h3>
            <p className="ios-body">На первое посещение для новых клиентов</p>
          </div>
          <Sparkles className="w-8 h-8" />
        </div>
      </div>

      {/* Популярные услуги */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Популярные услуги</h2>
        <div className="grid grid-cols-2 gap-3">
          {services.slice(0, 4).map((service) => (
            <div 
              key={service.id} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => openServiceModal(service)}
            >
              <img src={service.image} alt={service.name} className="w-full h-24 object-cover rounded-lg mb-2" />
              <h4 className="ios-footnote font-semibold">{service.name}</h4>
              <p className="ios-caption2 text-secondary-label mb-2">{service.duration}</p>
              <div className="flex items-center justify-between">
                <span className="ios-caption font-bold text-system-pink">${service.price}</span>
                <div className="flex items-center space-x-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="ios-caption2">{service.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Наши мастера */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Наши мастера</h2>
        <div className="space-y-3">
          {specialists.slice(0, 2).map((specialist) => (
            <div key={specialist.id} className="ios-card p-3 flex items-center space-x-3">
              <img src={specialist.image} alt={specialist.name} className="w-12 h-12 object-cover rounded-full" />
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{specialist.name}</h4>
                <p className="ios-footnote text-secondary-label">{specialist.specialty}</p>
                <div className="flex items-center space-x-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="ios-caption2">{specialist.rating} • {specialist.experience}</span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-tertiary-label" />
            </div>
          ))}
        </div>
      </div>

      {/* Контакты */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Контакты и часы работы</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-system-pink" />
            <span className="ios-body">Ежедневно с 9:00 до 21:00</span>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-system-pink" />
            <span className="ios-body">ул. Красоты, 15, ТЦ "Гламур"</span>
          </div>
          <div className="flex items-center space-x-2">
            <Phone className="w-4 h-4 text-system-pink" />
            <span className="ios-body">+7 (495) 123-45-67</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Услуги салона</h1>
      
      {/* Категории */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
              selectedCategory === category
                ? 'bg-system-pink text-white'
                : 'bg-quaternary-system-fill text-label'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Список услуг */}
      <div className="space-y-3">
        {filteredServices.map((service) => (
          <div 
            key={service.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openServiceModal(service)}
          >
            <div className="flex items-center space-x-3">
              <img src={service.image} alt={service.name} className="w-16 h-16 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold">{service.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(service.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(service.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-2">{service.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4 text-secondary-label" />
                      <span className="ios-caption2">{service.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4 text-secondary-label" />
                      <span className="ios-caption2">{service.specialist}</span>
                    </div>
                  </div>
                  <span className="ios-body font-bold text-system-pink">${service.price}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Мои записи</h1>
      
      {bookings.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Нет активных записей</p>
          <p className="ios-footnote text-tertiary-label">Запишитесь на процедуру из каталога</p>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {bookings.map((booking) => (
              <div key={booking.id} className="ios-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="ios-body font-semibold">{booking.serviceName}</h4>
                  <span className="ios-body font-bold text-system-pink">${booking.price}</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-secondary-label" />
                    <span className="ios-footnote">{booking.date}, {booking.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-secondary-label" />
                    <span className="ios-footnote">{booking.specialist}</span>
                  </div>
                </div>
                <div className="flex space-x-2 mt-3">
                  <button className="flex-1 bg-quaternary-system-fill text-label ios-footnote font-medium py-2 rounded-lg">
                    Перенести
                  </button>
                  <button className="flex-1 bg-system-red text-white ios-footnote font-medium py-2 rounded-lg">
                    Отменить
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-card p-4">
            <h3 className="ios-headline font-semibold mb-2">Итого записей: {bookings.length}</h3>
            <p className="ios-body text-secondary-label">Общая стоимость: ${bookings.reduce((sum, booking) => sum + booking.price, 0)}</p>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль клиента</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-pink rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">ГС</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Glow VIP</h3>
            <p className="ios-body text-secondary-label">Постоянный клиент</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-pink">24</p>
            <p className="ios-footnote text-secondary-label">Посещений</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">15%</p>
            <p className="ios-footnote text-secondary-label">Скидка</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Любимые услуги</h2>
        {services.filter(service => favorites.includes(service.id)).map((service) => (
          <div key={service.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={service.image} alt={service.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold">{service.name}</h4>
              <p className="ios-footnote text-secondary-label">${service.price} • {service.duration}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">История посещений</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Последнее посещение:</span>
            <span className="ios-body font-medium">15 дек 2024</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Любимый мастер:</span>
            <span className="ios-body font-medium">Анна Смирнова</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Потрачено всего:</span>
            <span className="ios-body font-medium text-system-pink">$1,240</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedService && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold">{selectedService.name}</h3>
              <button onClick={closeServiceModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedService.image} alt={selectedService.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <p className="ios-body text-secondary-label">{selectedService.description}</p>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-secondary-label" />
                  <span className="ios-footnote">{selectedService.duration}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <User className="w-4 h-4 text-secondary-label" />
                  <span className="ios-footnote">{selectedService.specialist}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedService.rating}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="ios-title font-bold text-system-pink">${selectedService.price}</span>
                <span className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-quaternary-system-fill text-label">
                  {selectedService.category}
                </span>
              </div>
              
              <button className="w-full bg-system-pink text-white ios-body font-semibold py-3 rounded-xl">
                Записаться
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}