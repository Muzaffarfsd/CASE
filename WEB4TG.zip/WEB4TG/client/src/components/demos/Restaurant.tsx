import { useState } from "react";
import { 
  Star, 
  Clock, 
  Pizza, 
  Utensils, 
  Leaf, 
  ChefHat, 
  Coffee,
  Plus,
  Minus,
  X,
  ChevronRight,
  MapPin,
  Phone
} from "lucide-react";

interface RestaurantProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

const menuCategories = {
  pizza: {
    name: 'Пицца',
    icon: Pizza,
    items: [
      { id: 1, name: 'Маргарита', description: 'Классическая пицца с томатным соусом, моцареллой и базиликом', price: 22, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '15 мин', rating: 4.8 },
      { id: 2, name: 'Пепперони', description: 'Острая пицца с пепперони и моцареллой', price: 24, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '15 мин', rating: 4.9 },
      { id: 3, name: 'Четыре сыра', description: 'Пицца с четырьмя видами сыра', price: 26, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '15 мин', rating: 4.7 },
      { id: 4, name: 'Дьявола', description: 'Пицца с острой салями, перцем чили и моцареллой', price: 25, image: 'https://images.unsplash.com/photo-1571407970349-bc81e7e96d47?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '16 мин', rating: 4.6 }
    ]
  },
  pasta: {
    name: 'Паста',
    icon: Utensils,
    items: [
      { id: 5, name: 'Карбонара', description: 'Классическая римская паста с беконом и сыром', price: 16, image: 'https://images.unsplash.com/photo-1551892374-ecf8cc4efcfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '12 мин', rating: 4.9 },
      { id: 6, name: 'Болоньезе', description: 'Паста с мясным соусом по-болонски', price: 18, image: 'https://images.unsplash.com/photo-1551892374-ecf8cc4efcfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '14 мин', rating: 4.8 },
      { id: 7, name: 'Песто', description: 'Ароматная паста с соусом песто', price: 20, image: 'https://images.unsplash.com/photo-1551892374-ecf8cc4efcfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '10 мин', rating: 4.6 },
      { id: 8, name: 'Аматричана', description: 'Традиционная паста с томатами, гуанчале и пекорино', price: 17, image: 'https://images.unsplash.com/photo-1563379091339-03246963d7d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '13 мин', rating: 4.7 }
    ]
  },
  salads: {
    name: 'Салаты',
    icon: Leaf,
    items: [
      { id: 9, name: 'Капрезе', description: 'Классический итальянский салат с моцареллой', price: 12, image: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '5 мин', rating: 4.7 },
      { id: 10, name: 'Цезарь', description: 'Салат с курицей, сыром пармезан и соусом цезарь', price: 14, image: 'https://images.unsplash.com/photo-1551248429-40975aa4de74?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '7 мин', rating: 4.8 },
      { id: 11, name: 'Греческий', description: 'Салат с фетой, оливками, огурцами и томатами', price: 13, image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '6 мин', rating: 4.5 },
      { id: 12, name: 'Руккола с пармезаном', description: 'Салат с рукколой, пармезаном и кедровыми орешками', price: 15, image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '5 мин', rating: 4.6 }
    ]
  },
  mains: {
    name: 'Основные блюда',
    icon: ChefHat,
    items: [
      { id: 13, name: 'Стейк Рибай', description: 'Сочный стейк из мраморной говядины с картофелем', price: 35, image: 'https://images.unsplash.com/photo-1558030006-450675393462?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '25 мин', rating: 4.9 },
      { id: 14, name: 'Лосось на гриле', description: 'Филе лосося с овощами и лимонным соусом', price: 28, image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '20 мин', rating: 4.8 },
      { id: 15, name: 'Ризотто с грибами', description: 'Кремовое ризотто с лесными грибами и трюфелем', price: 24, image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '18 мин', rating: 4.7 },
      { id: 16, name: 'Куриная грудка', description: 'Запеченная куриная грудка с овощами и соусом', price: 22, image: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '22 мин', rating: 4.5 }
    ]
  },
  desserts: {
    name: 'Десерты',
    icon: Coffee,
    items: [
      { id: 17, name: 'Тирамису', description: 'Классический итальянский десерт с маскарпоне и кофе', price: 9, image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '2 мин', rating: 4.9 },
      { id: 18, name: 'Панна котта', description: 'Нежный сливочный десерт с ягодным соусом', price: 8, image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '3 мин', rating: 4.6 },
      { id: 19, name: 'Каннолли', description: 'Хрустящие трубочки с рикоттой и шоколадной крошкой', price: 7, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '2 мин', rating: 4.7 },
      { id: 20, name: 'Джелато', description: 'Домашнее итальянское мороженое (3 шарика)', price: 6, image: 'https://images.unsplash.com/photo-1488900128323-21503983a07e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', cookTime: '1 мин', rating: 4.8 }
    ]
  }
};

const initialOrderItems = [
  { id: 1, name: 'Пицца Маргарита', price: 22, quantity: 1 },
  { id: 4, name: 'Паста Карбонара', price: 16, quantity: 1 },
];

export default function Restaurant({ activeTab }: RestaurantProps) {
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [orderItems, setOrderItems] = useState(initialOrderItems);
  const [activeCategory, setActiveCategory] = useState('pizza');

  const openItemModal = (item: any) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const closeItemModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setOrderItems(prev => 
      prev.map(item => 
        item.id === itemId 
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const renderHomeTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Restaurant Hero */}
        <section className="ios-slide-up">
          <div className="ios-card overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"
              alt="Интерьер ресторана"
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="ios-title3 mb-2">Bella Cucina</h2>
              <p className="ios-body text-secondary-label mb-4">
                Подлинная итальянская кухня с доставкой
              </p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-system-orange" />
                  <span className="ios-body" data-testid="rating">4.9</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-system-blue" />
                  <span className="ios-body" data-testid="delivery-time">30–45 мин</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Категории меню</h3>
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(menuCategories).map(([key, category]) => {
              const Icon = category.icon;
              return (
                <div key={key} className="ios-card p-4 text-center cursor-pointer" data-testid={`category-${key}`}>
                  <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Icon className="w-6 h-6 text-system-blue" />
                  </div>
                  <p className="ios-footnote font-semibold">{category.name}</p>
                  <p className="ios-caption2 text-secondary-label">
                    {category.items.length} блюд
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Popular Dishes */}
        <section className="ios-slide-up">
          <h3 className="ios-title3 mb-4">Популярные блюда</h3>
          <div className="space-y-3">
            {menuCategories.pizza.items.slice(0, 2).map((item) => (
              <div 
                key={item.id} 
                className="ios-card p-4 cursor-pointer" 
                onClick={() => openItemModal(item)}
                data-testid={`popular-dish-${item.id}`}
              >
                <div className="flex items-center space-x-3">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="ios-body font-semibold">{item.name}</h4>
                    <p className="ios-footnote text-secondary-label">{item.description}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="ios-body font-bold text-system-blue">{item.price} $</span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-3 h-3 text-system-orange" />
                        <span className="ios-caption2">{item.rating}</span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-tertiary-label" />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Restaurant Info */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-header">Информация</div>
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-system-blue" />
                <div className="flex-1">
                  <div className="ios-body">Адрес</div>
                  <div className="ios-footnote text-secondary-label">
                    ул. Пушкина, 25
                  </div>
                </div>
              </div>
            </div>
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-system-green" />
                <div className="flex-1">
                  <div className="ios-body">Телефон</div>
                  <div className="ios-footnote text-secondary-label">
                    +7 (495) 123-45-67
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Category Selector */}
        <section className="ios-slide-up">
          <div className="ios-segmented overflow-x-auto">
            <div className="flex space-x-1 min-w-max">
              {Object.entries(menuCategories).map(([key, category]) => (
                <button
                  key={key}
                  className={`${
                    activeCategory === key ? 'ios-segmented-item-active' : 'ios-segmented-item'
                  } whitespace-nowrap`}
                  onClick={() => setActiveCategory(key)}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Menu Items */}
        <section className="ios-slide-up">
          <div className="space-y-3">
            {menuCategories[activeCategory as keyof typeof menuCategories].items.map((item) => (
              <div 
                key={item.id} 
                className="ios-card p-4 cursor-pointer" 
                onClick={() => openItemModal(item)}
                data-testid={`menu-item-${item.id}`}
              >
                <div className="flex items-center space-x-3">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="ios-body font-semibold">{item.name}</h4>
                    <p className="ios-footnote text-secondary-label mb-2">{item.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="ios-headline font-bold text-system-blue">{item.price} $</span>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3 h-3 text-secondary-label" />
                          <span className="ios-caption2 text-secondary-label">{item.cookTime}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3 text-system-orange" />
                          <span className="ios-caption2">{item.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {orderItems.length === 0 ? (
          <div className="ios-card p-8 text-center">
            <ChefHat className="w-12 h-12 text-secondary-label mx-auto mb-4" />
            <h3 className="ios-title3 mb-2">Корзина пуста</h3>
            <p className="ios-body text-secondary-label mb-4">
              Добавьте блюда для заказа
            </p>
            <button className="ios-button-filled">
              Посмотреть меню
            </button>
          </div>
        ) : (
          <>
            {/* Order Items */}
            <section className="ios-slide-up">
              <div className="ios-list">
                <div className="ios-list-header">Ваш заказ</div>
                {orderItems.map((item) => (
                  <div key={item.id} className="ios-list-item" data-testid={`order-item-${item.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="ios-body font-semibold">{item.name}</div>
                        <div className="ios-footnote text-secondary-label">
                          {item.price} $ за штуку
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <button
                          className="w-8 h-8 bg-secondary-system-fill rounded-full flex items-center justify-center"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="ios-body font-semibold w-6 text-center">
                          {item.quantity}
                        </span>
                        <button
                          className="w-8 h-8 bg-system-blue rounded-full flex items-center justify-center"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4 text-white" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Order Summary */}
            <section className="ios-slide-up">
              <div className="ios-card p-4 space-y-3">
                <h3 className="ios-headline font-semibold">Итого</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="ios-body text-secondary-label">Блюда</span>
                    <span className="ios-body">{calculateTotal()} $</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="ios-body text-secondary-label">Доставка</span>
                    <span className="ios-body text-system-green">Бесплатно</span>
                  </div>
                  <div className="border-t border-separator pt-2">
                    <div className="flex justify-between">
                      <span className="ios-headline font-bold">Всего</span>
                      <span className="ios-title3 font-bold text-system-blue">
                        {calculateTotal()} $
                      </span>
                    </div>
                  </div>
                </div>
                <button className="ios-button-filled w-full mt-4" data-testid="button-order">
                  Оформить заказ
                </button>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );

  const renderProfileTab = () => (
    <div className="bg-white min-h-screen">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* User Profile */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 text-center">
            <div className="w-16 h-16 bg-system-orange/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <ChefHat className="w-8 h-8 text-system-orange" />
            </div>
            <h2 className="ios-title2 mb-2">Михаил Иванов</h2>
            <p className="ios-footnote text-secondary-label">
              Постоянный клиент
            </p>
          </div>
        </section>

        {/* Menu Options */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <ChefHat className="w-5 h-5 text-system-orange" />
                <div className="flex-1">
                  <div className="ios-body">Мои заказы</div>
                  <div className="ios-footnote text-secondary-label">
                    История заказов
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <Star className="w-5 h-5 text-system-orange" />
                <div className="flex-1">
                  <div className="ios-body">Любимые блюда</div>
                  <div className="ios-footnote text-secondary-label">
                    Сохраненные рецепты
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-system-blue" />
                <div className="flex-1">
                  <div className="ios-body">Адреса доставки</div>
                  <div className="ios-footnote text-secondary-label">
                    Сохраненные адреса
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return renderHomeTab();
      case 'catalog':
        return renderCatalogTab();
      case 'cart':
        return renderCartTab();
      case 'profile':
        return renderProfileTab();
      default:
        return renderHomeTab();
    }
  };

  return (
    <>
      {renderContent()}

      {/* Premium Food Detail Modal */}
      {isModalOpen && selectedItem && (
        <div className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm animate-in fade-in duration-300" data-testid="item-modal">
          <div className="safe-area-top h-full flex flex-col">
            {/* Animated Modal Container */}
            <div className="bg-white rounded-t-3xl mt-16 flex-1 overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-500">
              {/* Enhanced Modal Header */}
              <div className="relative bg-gradient-to-r from-white via-white/95 to-white backdrop-blur-md border-b border-separator/30">
                <div className="max-w-md mx-auto flex items-center justify-between px-6 py-4">
                  <button
                    onClick={closeItemModal}
                    className="w-10 h-10 bg-secondary-system-fill rounded-full flex items-center justify-center hover:bg-tertiary-system-fill transition-all duration-200 active:scale-95"
                    data-testid="button-close-modal"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <h1 className="ios-headline font-bold text-center flex-1">🍽️ Детали блюда</h1>
                  <div className="w-10" />
                </div>
              </div>

              {/* Enhanced Modal Content */}
              <div className="flex-1 overflow-y-auto">
                <div className="max-w-md mx-auto">
                  {/* Hero Image with Overlays */}
                  <div className="relative overflow-hidden">
                    <img
                      src={selectedItem.image}
                      alt={selectedItem.name}
                      className="w-full h-80 object-cover transition-transform duration-700 hover:scale-105"
                      onError={(e) => {
                        e.currentTarget.src = `https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400`;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
                    
                    {/* Chef's Choice Badge */}
                    <div className="absolute top-4 left-4 animate-in slide-in-from-left duration-700">
                      <div className="bg-gradient-to-r from-system-orange to-system-red px-3 py-1.5 rounded-full shadow-lg">
                        <span className="text-white text-xs font-bold">CHEF'S CHOICE</span>
                      </div>
                    </div>
                    
                    {/* Rating Badge */}
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-right duration-700">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-system-yellow fill-current" />
                        <span className="text-sm font-bold">{selectedItem.rating}</span>
                      </div>
                    </div>
                    
                    {/* Cook Time Badge */}
                    <div className="absolute bottom-4 right-4 bg-system-blue/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-lg animate-in slide-in-from-bottom duration-700">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-white" />
                        <span className="text-white text-xs font-medium">{selectedItem.cookTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="px-6 py-6 space-y-6">
                    {/* Food Info */}
                    <div className="space-y-4 animate-in slide-in-from-bottom duration-500 delay-200">
                      <div>
                        <h2 className="ios-title1 font-bold mb-3 bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                          {selectedItem.name}
                        </h2>
                        <p className="ios-body text-secondary-label leading-relaxed">
                          {selectedItem.description}
                        </p>
                      </div>
                    </div>
                    
                    {/* Price & Details Card */}
                    <div className="bg-gradient-to-r from-system-orange/5 via-system-red/5 to-system-pink/5 rounded-2xl p-6 border border-system-orange/10 shadow-sm animate-in slide-in-from-bottom duration-500 delay-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="ios-large-title font-black bg-gradient-to-r from-system-orange to-system-red bg-clip-text text-transparent">
                            {selectedItem.price} $
                          </span>
                          <p className="ios-caption1 text-secondary-label mt-1">
                            Специальная цена
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-1 justify-end">
                            <Clock className="w-5 h-5 text-system-blue" />
                            <span className="ios-headline font-bold">{selectedItem.cookTime}</span>
                          </div>
                          <p className="ios-caption1 text-secondary-label">
                            Время готовки
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Fresh Daily Badge */}
                    <div className="bg-gradient-to-r from-system-green/5 to-system-teal/5 rounded-2xl p-4 border border-system-green/20 animate-in slide-in-from-bottom duration-500 delay-400">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-system-green/20 rounded-full flex items-center justify-center">
                          <ChefHat className="w-5 h-5 text-system-green" />
                        </div>
                        <div>
                          <p className="ios-body font-semibold text-system-green">
                            Готовится свежим каждый день
                          </p>
                          <p className="ios-caption1 text-secondary-label">
                            Только свежие ингредиенты и авторские рецепты шеф-повара
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Nutrition Info */}
                    <div className="bg-white rounded-2xl border border-separator/50 p-4 shadow-sm animate-in slide-in-from-bottom duration-500 delay-500">
                      <h3 className="ios-headline font-semibold mb-3 flex items-center">
                        <Utensils className="w-4 h-4 mr-2 text-system-purple" />
                        О блюде
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-system-blue/5 rounded-xl">
                          <Star className="w-5 h-5 text-system-orange mx-auto mb-1" />
                          <p className="text-sm font-bold">{selectedItem.rating}</p>
                          <p className="text-xs text-secondary-label">Рейтинг</p>
                        </div>
                        <div className="text-center p-3 bg-system-green/5 rounded-xl">
                          <Clock className="w-5 h-5 text-system-blue mx-auto mb-1" />
                          <p className="text-sm font-bold">{selectedItem.cookTime}</p>
                          <p className="text-xs text-secondary-label">Готовка</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced Modal Footer */}
              <div className="bg-white/95 backdrop-blur-md border-t border-separator/30">
                <div className="max-w-md mx-auto px-6 py-4">
                  <button 
                    className="w-full bg-gradient-to-r from-system-orange to-system-red text-white font-bold py-4 px-6 rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-3 animate-in slide-in-from-bottom duration-500 delay-700"
                    onClick={closeItemModal}
                    data-testid="button-add-to-order"
                  >
                    <Utensils className="w-5 h-5" />
                    <span>Добавить в заказ</span>
                    <span className="bg-white/20 px-2 py-1 rounded-lg text-sm">
                      {selectedItem.price} $
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}