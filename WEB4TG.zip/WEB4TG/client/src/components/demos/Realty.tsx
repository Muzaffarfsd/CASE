import { useState } from "react";
import { 
  Home, 
  Heart, 
  Star, 
  MapPin, 
  Ruler,
  Plus,
  Minus,
  X,
  ChevronRight,
  Bath,
  Car,
  Wifi,
  Shield,
  Play,
  Filter
} from "lucide-react";

interface RealtyProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface SavedProperty {
  id: number;
  name: string;
  price: number;
  image: string;
  type: string;
}

const properties = [
  { id: 1, name: 'Уютная студия в центре', price: 1200, image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Современная студия с панорамными окнами и дизайнерским ремонтом', category: 'Аренда', type: 'Студия', area: 35, rooms: 1, floor: 12, totalFloors: 25, address: 'ул. Тверская, 15', district: 'Центр', metro: 'Пушкинская', rating: 4.8, features: ['WiFi', 'Кондиционер', 'Мебель', 'Техника'], amenities: ['Парковка', 'Консьерж', 'Фитнес-зал'], vrTour: true },
  { id: 2, name: 'Просторная 2-комнатная квартира', price: 2800, image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Светлая квартира с евроремонтом в тихом районе', category: 'Аренда', type: '2-комнатная', area: 68, rooms: 2, floor: 5, totalFloors: 9, address: 'Проспект Мира, 45', district: 'Сокольники', metro: 'Сокольники', rating: 4.7, features: ['Балкон', 'Мебель', 'Техника', 'Интернет'], amenities: ['Детская площадка', 'Охрана'], vrTour: true },
  { id: 3, name: 'Элитный пентхаус', price: 8500, image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Роскошный пентхаус с террасой и видом на город', category: 'Аренда', type: 'Пентхаус', area: 180, rooms: 4, floor: 20, totalFloors: 20, address: 'Кутузовский проспект, 2', district: 'Хамовники', metro: 'Парк Победы', rating: 4.9, features: ['Терраса', 'Камин', 'Джакузи', 'Гардеробная'], amenities: ['Консьерж', 'Spa', 'Ресторан'], vrTour: true },
  { id: 4, name: 'Однокомнатная квартира у метро', price: 1800, image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Удобная квартира в 2 минутах от станции метро', category: 'Аренда', type: '1-комнатная', area: 42, rooms: 1, floor: 3, totalFloors: 12, address: 'ул. Арбат, 28', district: 'Арбат', metro: 'Арбатская', rating: 4.5, features: ['Мебель', 'Техника', 'Кондиционер'], amenities: ['Метро рядом', 'Магазины'], vrTour: false },
  { id: 5, name: 'Загородный дом с участком', price: 450000, image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Двухэтажный дом с садом в коттеджном поселке', category: 'Продажа', type: 'Дом', area: 220, rooms: 5, floor: 2, totalFloors: 2, address: 'КП Солнечный берег', district: 'Подмосковье', metro: 'Новопеределкино', rating: 4.8, features: ['Камин', 'Сауна', 'Гараж', 'Сад'], amenities: ['Охрана', 'Детская площадка', 'Пруд'], vrTour: true },
  { id: 6, name: 'Современная студия в новостройке', price: 980, image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Стильная студия с французскими окнами', category: 'Аренда', type: 'Студия', area: 28, rooms: 1, floor: 8, totalFloors: 15, address: 'ул. Новый Арбат, 11', district: 'Арбат', metro: 'Арбатская', rating: 4.4, features: ['Мебель', 'Техника', 'Панорамные окна'], amenities: ['Фитнес-зал', 'Кафе'], vrTour: true },
  { id: 7, name: 'Трёхкомнатная квартира с ремонтом', price: 3200, image: 'https://images.unsplash.com/photo-1505873242700-f289a29e1e0f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Просторная квартира с авторским дизайном', category: 'Аренда', type: '3-комнатная', area: 85, rooms: 3, floor: 7, totalFloors: 16, address: 'Ленинский проспект, 99', district: 'Гагаринский', metro: 'Ленинский проспект', rating: 4.6, features: ['Дизайнерский ремонт', 'Мебель', 'Техника'], amenities: ['Парковка', 'Консьерж'], vrTour: true },
  { id: 8, name: 'Квартира-лофт в историческом центре', price: 4500, image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уникальный лофт с высокими потолками', category: 'Аренда', type: 'Лофт', area: 95, rooms: 2, floor: 4, totalFloors: 5, address: 'Патриаршие пруды, 3', district: 'Пресненский', metro: 'Маяковская', rating: 4.9, features: ['Высокие потолки', 'Кирпичные стены', 'Мебель'], amenities: ['Историческое место', 'Рестораны рядом'], vrTour: true },
  { id: 9, name: 'Коттедж у озера', price: 650000, image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Живописный дом на берегу озера с причалом', category: 'Продажа', type: 'Коттедж', area: 160, rooms: 4, floor: 2, totalFloors: 2, address: 'КП Озёрная гладь', district: 'Подмосковье', metro: 'Митино', rating: 4.7, features: ['Причал', 'Сауна', 'Камин', 'Терраса'], amenities: ['Озеро', 'Лес', 'Охрана'], vrTour: true },
  { id: 10, name: 'Апартаменты в бизнес-центре', price: 2200, image: 'https://images.unsplash.com/photo-1556020685-ae41abfc9365?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Современные апартаменты для деловых людей', category: 'Аренда', type: 'Апартаменты', area: 55, rooms: 1, floor: 15, totalFloors: 25, address: 'Международная, 12', district: 'Пресненский', metro: 'Международная', rating: 4.5, features: ['Мебель', 'Техника', 'Кондиционер', 'Сейф'], amenities: ['Бизнес-центр', 'Ресторан', 'Парковка'], vrTour: false },
  { id: 11, name: 'Семейная квартира в спальном районе', price: 2000, image: 'https://images.unsplash.com/photo-1513584684374-8bab748fbf90?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Тихая квартира идеальная для семьи с детьми', category: 'Аренда', type: '2-комнатная', area: 60, rooms: 2, floor: 2, totalFloors: 9, address: 'ул. Академика Королёва, 15', district: 'Останкинский', metro: 'ВДНХ', rating: 4.3, features: ['Мебель', 'Детская комната', 'Балкон'], amenities: ['Детская площадка', 'Школа рядом', 'Парк'], vrTour: false },
  { id: 12, name: 'Роскошная вилла с бассейном', price: 1200000, image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Эксклюзивная вилла с собственным бассейном и садом', category: 'Продажа', type: 'Вилла', area: 350, rooms: 6, floor: 2, totalFloors: 2, address: 'КП Рублевские дачи', district: 'Рублёвка', metro: 'Молодёжная', rating: 5.0, features: ['Бассейн', 'Сауна', 'Винный погреб', 'Гараж на 3 машины'], amenities: ['Теннисный корт', 'Охрана 24/7', 'Ландшафтный дизайн'], vrTour: true },
  { id: 13, name: 'Квартира с видом на парк', price: 2500, image: 'https://images.unsplash.com/photo-1565182999561-18d7dc61c393?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Светлая квартира с великолепным видом на Сокольники', category: 'Аренда', type: '2-комнатная', area: 70, rooms: 2, floor: 9, totalFloors: 12, address: 'ул. Сокольнический Вал, 8', district: 'Сокольники', metro: 'Сокольники', rating: 4.6, features: ['Панорамные окна', 'Мебель', 'Кондиционер'], amenities: ['Парк', 'Спортивные площадки'], vrTour: true },
  { id: 14, name: 'Малосемейка для студентов', price: 800, image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Бюджетное жильё рядом с университетом', category: 'Аренда', type: 'Малосемейка', area: 18, rooms: 1, floor: 4, totalFloors: 5, address: 'ул. Стромынка, 25', district: 'Сокольники', metro: 'Преображенская площадь', rating: 4.0, features: ['Мебель', 'Интернет'], amenities: ['Университет рядом', 'Библиотека'], vrTour: false },
  { id: 15, name: 'Таунхаус в закрытом посёлке', price: 780000, image: 'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Современный таунхаус со всеми удобствами', category: 'Продажа', type: 'Таунхаус', area: 180, rooms: 4, floor: 3, totalFloors: 3, address: 'КП Английская деревня', district: 'Подмосковье', metro: 'Рассказовка', rating: 4.8, features: ['Гараж', 'Терраса', 'Камин', 'Гардеробная'], amenities: ['Охрана', 'Детская площадка', 'Спортплощадка'], vrTour: true },
  { id: 16, name: 'Мансарда с террасой', price: 3800, image: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Романтичная мансарда с открытой террасой', category: 'Аренда', type: 'Мансарда', area: 75, rooms: 2, floor: 5, totalFloors: 5, address: 'Остоженка, 12', district: 'Хамовники', metro: 'Кропоткинская', rating: 4.7, features: ['Терраса', 'Мансардные окна', 'Дизайнерский ремонт'], amenities: ['Исторический район', 'Галереи'], vrTour: true },
  { id: 17, name: 'Квартира в сталинском доме', price: 4200, image: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Просторная квартира с высокими потолками в историческом здании', category: 'Аренда', type: '3-комнатная', area: 110, rooms: 3, floor: 3, totalFloors: 7, address: 'Тверской бульвар, 25', district: 'Тверской', metro: 'Тверская', rating: 4.8, features: ['Высокие потолки', 'Лепнина', 'Паркет', 'Мебель'], amenities: ['Историческое здание', 'Театры рядом'], vrTour: true },
  { id: 18, name: 'Дуплекс в новостройке', price: 5500, image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Двухуровневая квартира с дизайнерским ремонтом', category: 'Аренда', type: 'Дуплекс', area: 120, rooms: 3, floor: 14, totalFloors: 25, address: 'ул. 1905 года, 7', district: 'Пресненский', metro: 'Улица 1905 года', rating: 4.9, features: ['Два уровня', 'Винтовая лестница', 'Панорамные окна'], amenities: ['Консьерж', 'Фитнес-зал', 'Подземная парковка'], vrTour: true },
  { id: 19, name: 'Квартира-студия с кухней-островом', price: 1500, image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Современная студия с функциональной планировкой', category: 'Аренда', type: 'Студия', area: 40, rooms: 1, floor: 6, totalFloors: 10, address: 'Садовое кольцо, 3', district: 'Красносельский', metro: 'Красносельская', rating: 4.4, features: ['Кухня-остров', 'Техника', 'Мебель'], amenities: ['Магазины', 'Кафе'], vrTour: false },
  { id: 20, name: 'Усадьба в историческом стиле', price: 2500000, image: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уникальная историческая усадьба с парком', category: 'Продажа', type: 'Усадьба', area: 500, rooms: 8, floor: 2, totalFloors: 2, address: 'Усадьба Архангельское', district: 'Подмосковье', metro: 'Тушинская', rating: 5.0, features: ['Парк 2 га', 'Конюшня', 'Оранжерея', 'Библиотека'], amenities: ['Музей рядом', 'Пруд', 'Историческая ценность'], vrTour: true }
];

const categories = ['Все', 'Аренда', 'Продажа'];
const types = ['Все', 'Студия', '1-комнатная', '2-комнатная', '3-комнатная', 'Дом', 'Коттедж', 'Пентхаус', 'Лофт'];
const districts = ['Все', 'Центр', 'Арбат', 'Сокольники', 'Хамовники', 'Пресненский', 'Подмосковье'];

const initialSavedProperties: SavedProperty[] = [
  { id: 3, name: 'Элитный пентхаус', price: 8500, image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60', type: 'Пентхаус' },
  { id: 5, name: 'Загородный дом с участком', price: 450000, image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60', type: 'Дом' },
];

export default function Realty({ activeTab }: RealtyProps) {
  const [selectedProperty, setSelectedProperty] = useState<typeof properties[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [savedProperties, setSavedProperties] = useState<SavedProperty[]>(initialSavedProperties);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [selectedType, setSelectedType] = useState('Все');
  const [selectedDistrict, setSelectedDistrict] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([3, 5, 8, 12]);

  const openPropertyModal = (property: typeof properties[0]) => {
    setSelectedProperty(property);
    setIsModalOpen(true);
  };

  const closePropertyModal = () => {
    setIsModalOpen(false);
    setSelectedProperty(null);
  };

  const toggleFavorite = (propertyId: number) => {
    setFavorites(prev => 
      prev.includes(propertyId) 
        ? prev.filter(id => id !== propertyId)
        : [...prev, propertyId]
    );
  };

  const filteredProperties = properties.filter(property => {
    const matchesCategory = selectedCategory === 'Все' || property.category === selectedCategory;
    const matchesType = selectedType === 'Все' || property.type === selectedType;
    const matchesDistrict = selectedDistrict === 'Все' || property.district === selectedDistrict;
    
    return matchesCategory && matchesType && matchesDistrict;
  });

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">НедвижимостьПро</h1>
        <p className="ios-subheadline text-secondary-label">Найдём дом вашей мечты 🏠</p>
      </div>

      {/* VR туры */}
      <div className="ios-card p-4 bg-gradient-to-r from-violet-500 to-purple-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="ios-headline font-semibold">VR туры</h3>
            <p className="ios-body">Осмотрите квартиры не выходя из дома</p>
          </div>
          <Play className="w-8 h-8" />
        </div>
      </div>

      {/* Быстрый поиск */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Быстрый поиск</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Аренда', count: '2,450 объектов', color: 'bg-blue-500' },
            { name: 'Продажа', count: '1,890 объектов', color: 'bg-green-500' },
            { name: 'Элитная недвижимость', count: '340 объектов', color: 'bg-purple-500' },
            { name: 'Новостройки', count: '680 объектов', color: 'bg-orange-500' }
          ].map((search) => (
            <div 
              key={search.name} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => setSelectedCategory(search.name === 'Аренда' || search.name === 'Продажа' ? search.name : 'Все')}
            >
              <div className={`w-full h-16 ${search.color} rounded-lg mb-2 flex items-center justify-center`}>
                <Home className="w-8 h-8 text-white" />
              </div>
              <h4 className="ios-footnote font-semibold">{search.name}</h4>
              <p className="ios-caption2 text-secondary-label">{search.count}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Рекомендации */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Рекомендуем</h2>
        <div className="space-y-3">
          {properties.slice(0, 3).map((property) => (
            <div 
              key={property.id} 
              className="ios-card p-3 cursor-pointer flex items-center space-x-3"
              onClick={() => openPropertyModal(property)}
            >
              <img src={property.image} alt={property.name} className="w-16 h-16 object-cover rounded-lg" />
              <div className="flex-1">
                <h4 className="ios-body font-semibold line-clamp-1">{property.name}</h4>
                <p className="ios-footnote text-secondary-label">{property.type} • {property.area} м²</p>
                <div className="flex items-center space-x-2">
                  <span className="ios-caption font-bold text-system-violet">
                    {property.category === 'Аренда' ? `$${property.price}/мес` : `$${property.price.toLocaleString()}`}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span className="ios-caption2">{property.rating}</span>
                  </div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-tertiary-label" />
            </div>
          ))}
        </div>
      </div>

      {/* Услуги */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Наши услуги</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-system-violet" />
            <span className="ios-body">Юридическое сопровождение сделок</span>
          </div>
          <div className="flex items-center space-x-2">
            <Play className="w-4 h-4 text-system-violet" />
            <span className="ios-body">VR туры по объектам</span>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-system-violet" />
            <span className="ios-body">Помощь с переездом</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Каталог недвижимости</h1>
      
      {/* Фильтры */}
      <div className="space-y-3">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
                selectedCategory === category
                  ? 'bg-system-violet text-white'
                  : 'bg-quaternary-system-fill text-label'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
        
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {types.map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1 rounded-full whitespace-nowrap ios-caption2 font-medium ${
                selectedType === type
                  ? 'bg-system-purple text-white'
                  : 'bg-fill text-secondary-label'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        <div className="flex space-x-2 overflow-x-auto pb-2">
          {districts.map((district) => (
            <button
              key={district}
              onClick={() => setSelectedDistrict(district)}
              className={`px-3 py-1 rounded-full whitespace-nowrap ios-caption2 font-medium ${
                selectedDistrict === district
                  ? 'bg-system-indigo text-white'
                  : 'bg-fill text-secondary-label'
              }`}
            >
              {district}
            </button>
          ))}
        </div>
      </div>

      {/* Список объектов */}
      <div className="space-y-3">
        {filteredProperties.map((property) => (
          <div 
            key={property.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openPropertyModal(property)}
          >
            <div className="flex items-center space-x-3">
              <div className="relative">
                <img src={property.image} alt={property.name} className="w-20 h-20 object-cover rounded-lg" />
                {property.vrTour && (
                  <div className="absolute top-1 right-1 w-6 h-6 bg-black/70 rounded-full flex items-center justify-center">
                    <Play className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold line-clamp-1">{property.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(property.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(property.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-1">{property.address}</p>
                <p className="ios-caption2 text-tertiary-label mb-2 line-clamp-1">{property.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Ruler className="w-3 h-3 text-secondary-label" />
                      <span className="ios-caption2">{property.area} м²</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Home className="w-3 h-3 text-secondary-label" />
                      <span className="ios-caption2">{property.rooms} комн.</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="ios-caption2">{property.rating}</span>
                    </div>
                  </div>
                  <span className="ios-body font-bold text-system-violet">
                    {property.category === 'Аренда' ? `$${property.price}/мес` : `$${property.price.toLocaleString()}`}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Избранное</h1>
      
      {savedProperties.length === 0 ? (
        <div className="text-center py-12">
          <Home className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Нет сохранённых объектов</p>
          <p className="ios-footnote text-tertiary-label">Добавьте понравившиеся квартиры</p>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {savedProperties.map((property) => {
              const fullProperty = properties.find(p => p.id === property.id);
              return (
                <div key={property.id} className="ios-card p-4">
                  <div className="flex items-center space-x-3">
                    <img src={property.image} alt={property.name} className="w-16 h-16 object-cover rounded-lg" />
                    <div className="flex-1">
                      <h4 className="ios-body font-semibold">{property.name}</h4>
                      <p className="ios-footnote text-secondary-label">{property.type}</p>
                      <p className="ios-body font-bold text-system-violet">
                        {fullProperty?.category === 'Аренда' ? `$${property.price}/мес` : `$${property.price.toLocaleString()}`}
                      </p>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <button 
                        className="ios-footnote bg-system-violet text-white px-3 py-1 rounded-lg"
                        onClick={() => fullProperty && openPropertyModal(fullProperty)}
                      >
                        Смотреть
                      </button>
                      <button 
                        className="ios-footnote bg-quaternary-system-fill text-label px-3 py-1 rounded-lg"
                        onClick={() => setSavedProperties(prev => prev.filter(p => p.id !== property.id))}
                      >
                        Удалить
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="ios-card p-4">
            <h3 className="ios-headline font-semibold mb-2">Статистика просмотров</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="ios-title font-bold text-system-violet">{savedProperties.length}</p>
                <p className="ios-footnote text-secondary-label">Избранных</p>
              </div>
              <div className="text-center">
                <p className="ios-title font-bold text-system-green">42</p>
                <p className="ios-footnote text-secondary-label">Просмотрено</p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль клиента</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-violet rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">НП</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Премиум клиент</h3>
            <p className="ios-body text-secondary-label">Активный покупатель</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-violet">18</p>
            <p className="ios-footnote text-secondary-label">Просмотрено</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">3</p>
            <p className="ios-footnote text-secondary-label">Сделок</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Избранные объекты</h2>
        {properties.filter(property => favorites.includes(property.id)).map((property) => (
          <div key={property.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={property.image} alt={property.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold line-clamp-1">{property.name}</h4>
              <p className="ios-footnote text-secondary-label">
                {property.type} • {property.category === 'Аренда' ? `$${property.price}/мес` : `$${property.price.toLocaleString()}`}
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Поисковые предпочтения</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Тип недвижимости:</span>
            <span className="ios-body font-medium">Квартиры</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Бюджет:</span>
            <span className="ios-body font-medium">$2,000 - $5,000</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Район:</span>
            <span className="ios-body font-medium">Центр, Арбат</span>
          </div>
        </div>
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Агент по недвижимости</h3>
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-system-green rounded-full flex items-center justify-center">
            <span className="ios-body font-bold text-white">ИП</span>
          </div>
          <div className="flex-1">
            <h4 className="ios-body font-semibold">Иван Петров</h4>
            <p className="ios-footnote text-secondary-label">Стаж 8 лет • 4.9 ⭐</p>
          </div>
          <ChevronRight className="w-5 h-5 text-tertiary-label" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedProperty && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold line-clamp-2">{selectedProperty.name}</h3>
              <button onClick={closePropertyModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <div className="relative">
              <img src={selectedProperty.image} alt={selectedProperty.name} className="w-full h-48 object-cover rounded-xl" />
              {selectedProperty.vrTour && (
                <button className="absolute inset-0 bg-black/50 rounded-xl flex items-center justify-center">
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                    <Play className="w-8 h-8 text-black ml-1" />
                  </div>
                </button>
              )}
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-secondary-label" />
                <span className="ios-body">{selectedProperty.address}</span>
              </div>
              
              <p className="ios-body text-secondary-label">{selectedProperty.description}</p>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="ios-card p-3 text-center">
                  <Ruler className="w-5 h-5 text-secondary-label mx-auto mb-1" />
                  <p className="ios-caption2 text-secondary-label">Площадь</p>
                  <p className="ios-body font-semibold">{selectedProperty.area} м²</p>
                </div>
                <div className="ios-card p-3 text-center">
                  <Home className="w-5 h-5 text-secondary-label mx-auto mb-1" />
                  <p className="ios-caption2 text-secondary-label">Комнат</p>
                  <p className="ios-body font-semibold">{selectedProperty.rooms}</p>
                </div>
                <div className="ios-card p-3 text-center">
                  <span className="ios-body font-semibold text-secondary-label mx-auto mb-1">{selectedProperty.floor}</span>
                  <p className="ios-caption2 text-secondary-label">Этаж</p>
                  <p className="ios-body font-semibold">из {selectedProperty.totalFloors}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Особенности:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProperty.features.map((feature, index) => (
                    <span key={index} className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-quaternary-system-fill text-label">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Инфраструктура:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProperty.amenities.map((amenity, index) => (
                    <span key={index} className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-system-violet/10 text-system-violet">
                      {amenity}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedProperty.rating}</span>
                </div>
                <span className="ios-title font-bold text-system-violet">
                  {selectedProperty.category === 'Аренда' ? `$${selectedProperty.price}/мес` : `$${selectedProperty.price.toLocaleString()}`}
                </span>
              </div>
              
              <div className="flex space-x-2">
                <button className="flex-1 bg-system-violet text-white ios-body font-semibold py-3 rounded-xl">
                  {selectedProperty.category === 'Аренда' ? 'Арендовать' : 'Купить'}
                </button>
                <button className="flex-1 bg-quaternary-system-fill text-label ios-body font-medium py-3 rounded-xl">
                  Связаться с агентом
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}