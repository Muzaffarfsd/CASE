import { useState } from "react";
import { 
  Coffee as CoffeeIcon, 
  Heart, 
  Star, 
  Clock, 
  Thermometer,
  Plus,
  Minus,
  X,
  ChevronRight,
  Award,
  CreditCard
} from "lucide-react";

interface CoffeeProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  size: string;
  quantity: number;
  image: string;
}

const beverages = [
  { id: 1, name: 'Эспрессо', price: 3.5, image: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический итальянский эспрессо из отборных зерен', category: 'Кофе', temperature: 'hot', prepTime: '2 мин', rating: 4.8, caffeine: 'высокий' },
  { id: 2, name: 'Американо', price: 4.0, image: 'https://images.unsplash.com/photo-1497935586351-b67a49e012bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Эспрессо с горячей водой для мягкого вкуса', category: 'Кофе', temperature: 'hot', prepTime: '3 мин', rating: 4.6, caffeine: 'средний' },
  { id: 3, name: 'Капучино', price: 4.8, image: 'https://images.unsplash.com/photo-1572286165765-ad4ac3cb9a65?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Эспрессо с взбитым молоком и пенкой', category: 'Кофе', temperature: 'hot', prepTime: '4 мин', rating: 4.9, caffeine: 'средний' },
  { id: 4, name: 'Латте', price: 5.2, image: 'https://images.unsplash.com/photo-1561047029-3000c68339ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Нежный кофе с большим количеством молочной пены', category: 'Кофе', temperature: 'hot', prepTime: '5 мин', rating: 4.7, caffeine: 'низкий' },
  { id: 5, name: 'Моккачино', price: 5.8, image: 'https://images.unsplash.com/photo-1534778101976-62847782c213?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Кофе с шоколадом и взбитыми сливками', category: 'Кофе', temperature: 'hot', prepTime: '6 мин', rating: 4.8, caffeine: 'средний' },
  { id: 6, name: 'Флет Уайт', price: 5.0, image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Двойной эспрессо с микропеной', category: 'Кофе', temperature: 'hot', prepTime: '4 мин', rating: 4.6, caffeine: 'высокий' },
  { id: 7, name: 'Айс Кофе', price: 4.5, image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Холодный кофе со льдом и молоком', category: 'Холодные напитки', temperature: 'cold', prepTime: '3 мин', rating: 4.5, caffeine: 'средний' },
  { id: 8, name: 'Фраппучино', price: 6.2, image: 'https://images.unsplash.com/photo-1553909489-cd47e0ef937f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Ледяной кофейный коктейль со взбитыми сливками', category: 'Холодные напитки', temperature: 'cold', prepTime: '5 мин', rating: 4.7, caffeine: 'средний' },
  { id: 9, name: 'Матча Латте', price: 5.5, image: 'https://images.unsplash.com/photo-1536013723576-0af8d5989b4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Японский зеленый чай матча с молоком', category: 'Чай', temperature: 'hot', prepTime: '4 мин', rating: 4.4, caffeine: 'низкий' },
  { id: 10, name: 'Чай Эрл Грей', price: 3.8, image: 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический английский чай с бергамотом', category: 'Чай', temperature: 'hot', prepTime: '5 мин', rating: 4.3, caffeine: 'низкий' },
  { id: 11, name: 'Круассан с миндалем', price: 3.2, image: 'https://images.unsplash.com/photo-1549903072-7e6e0bedb7fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Хрустящий круассан с миндальной начинкой', category: 'Выпечка', temperature: 'room', prepTime: '1 мин', rating: 4.6, caffeine: 'без кофеина' },
  { id: 12, name: 'Чизкейк Нью-Йорк', price: 4.5, image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический американский чизкейк с ягодным соусом', category: 'Десерты', temperature: 'cold', prepTime: '2 мин', rating: 4.8, caffeine: 'без кофеина' },
  { id: 13, name: 'Маффин с черникой', price: 2.8, image: 'https://images.unsplash.com/photo-1607958996333-41aef7caefaa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Воздушный маффин с натуральной черникой', category: 'Выпечка', temperature: 'room', prepTime: '1 мин', rating: 4.4, caffeine: 'без кофеина' },
  { id: 14, name: 'Смузи Манго', price: 5.0, image: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Освежающий смузи из спелого манго с йогуртом', category: 'Смузи', temperature: 'cold', prepTime: '3 мин', rating: 4.5, caffeine: 'без кофеина' },
  { id: 15, name: 'Горячий Шоколад', price: 4.2, image: 'https://images.unsplash.com/photo-1542990253-a781e04c0082?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Богатый горячий шоколад с маршмеллоу', category: 'Горячие напитки', temperature: 'hot', prepTime: '4 мин', rating: 4.7, caffeine: 'без кофеина' },
  { id: 16, name: 'Бейгл с лососем', price: 6.5, image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Свежий бейгл с кремчизом и слабосоленым лососем', category: 'Завтраки', temperature: 'room', prepTime: '3 мин', rating: 4.9, caffeine: 'без кофеина' },
  { id: 17, name: 'Сэндвич Клаб', price: 7.2, image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Трехслойный сэндвич с курицей, беконом и овощами', category: 'Сэндвичи', temperature: 'room', prepTime: '5 мин', rating: 4.6, caffeine: 'без кофеина' },
  { id: 18, name: 'Панини с ветчиной', price: 5.8, image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Запеченный панини с ветчиной и сыром моцарелла', category: 'Сэндвичи', temperature: 'hot', prepTime: '6 мин', rating: 4.5, caffeine: 'без кофеина' },
  { id: 19, name: 'Тирамису', price: 4.8, image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Классический итальянский десерт с кофе и маскарпоне', category: 'Десерты', temperature: 'cold', prepTime: '2 мин', rating: 4.9, caffeine: 'низкий' },
  { id: 20, name: 'Чай Бабл Ти', price: 4.5, image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Популярный тайваньский чай с жемчужинами тапиоки', category: 'Чай', temperature: 'cold', prepTime: '4 мин', rating: 4.6, caffeine: 'низкий' }
];

const categories = ['Все', 'Кофе', 'Чай', 'Холодные напитки', 'Выпечка', 'Десерты', 'Сэндвичи', 'Завтраки', 'Смузи', 'Горячие напитки'];

const initialCartItems: CartItem[] = [
  { id: 1, name: 'Капучино', price: 4.8, size: 'L', quantity: 1, image: 'https://images.unsplash.com/photo-1572286165765-ad4ac3cb9a65?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
  { id: 11, name: 'Круассан с миндалем', price: 3.2, size: 'Regular', quantity: 1, image: 'https://images.unsplash.com/photo-1549903072-7e6e0bedb7fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60' },
];

export default function Coffee({ activeTab }: CoffeeProps) {
  const [selectedItem, setSelectedItem] = useState<typeof beverages[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([1, 3, 12]);

  const openItemModal = (item: typeof beverages[0]) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const closeItemModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCartItems(prev => 
      prev.map(item => 
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeFromCart = (itemId: number) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const toggleFavorite = (itemId: number) => {
    setFavorites(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const filteredBeverages = selectedCategory === 'Все' 
    ? beverages 
    : beverages.filter(item => item.category === selectedCategory);

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">Кофе Рай</h1>
        <p className="ios-subheadline text-secondary-label">Лучший кофе в городе ☕</p>
      </div>

      {/* Карточка лояльности */}
      <div className="ios-card p-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="ios-headline font-semibold">Программа лояльности</h3>
            <p className="ios-body">7 из 10 покупок до бесплатного кофе</p>
          </div>
          <Award className="w-8 h-8" />
        </div>
        <div className="flex space-x-1 mt-3">
          {[...Array(10)].map((_, i) => (
            <div key={i} className={`w-4 h-4 rounded-full ${i < 7 ? 'bg-white' : 'bg-white/30'}`} />
          ))}
        </div>
      </div>

      {/* Рекомендуемые товары */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Рекомендуем попробовать</h2>
        <div className="grid grid-cols-2 gap-3">
          {beverages.slice(0, 4).map((item) => (
            <div 
              key={item.id} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => openItemModal(item)}
            >
              <img src={item.image} alt={item.name} className="w-full h-24 object-cover rounded-lg mb-2" />
              <h4 className="ios-footnote font-semibold">{item.name}</h4>
              <p className="ios-caption2 text-secondary-label mb-2">{item.prepTime}</p>
              <div className="flex items-center justify-between">
                <span className="ios-caption font-bold text-system-orange">${item.price}</span>
                <div className="flex items-center space-x-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="ios-caption2">{item.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Информация о кофейне */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">О нашей кофейне</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-system-orange" />
            <span className="ios-body">Ежедневно с 7:00 до 22:00</span>
          </div>
          <div className="flex items-center space-x-2">
            <CoffeeIcon className="w-4 h-4 text-system-orange" />
            <span className="ios-body">Свежеобжаренные зерна каждый день</span>
          </div>
          <div className="flex items-center space-x-2">
            <Award className="w-4 h-4 text-system-orange" />
            <span className="ios-body">Награды за качество кофе 2024</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Наше меню</h1>
      
      {/* Категории */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
              selectedCategory === category
                ? 'bg-system-orange text-white'
                : 'bg-quaternary-system-fill text-label'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Список товаров */}
      <div className="grid grid-cols-2 gap-3">
        {filteredBeverages.map((item) => (
          <div 
            key={item.id} 
            className="ios-card p-3 cursor-pointer relative"
            onClick={() => openItemModal(item)}
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleFavorite(item.id);
              }}
              className="absolute top-2 right-2 z-10 p-1"
            >
              <Heart 
                className={`w-4 h-4 ${
                  favorites.includes(item.id) 
                    ? 'fill-red-500 text-red-500' 
                    : 'text-secondary-label'
                }`} 
              />
            </button>
            
            <img src={item.image} alt={item.name} className="w-full h-24 object-cover rounded-lg mb-2" />
            <h4 className="ios-footnote font-semibold mb-1">{item.name}</h4>
            <p className="ios-caption2 text-secondary-label mb-2 line-clamp-2">{item.description}</p>
            
            <div className="flex items-center justify-between">
              <span className="ios-caption font-bold text-system-orange">${item.price}</span>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${
                  item.temperature === 'hot' ? 'bg-red-500' : 
                  item.temperature === 'cold' ? 'bg-blue-500' : 'bg-gray-500'
                }`} />
                <span className="ios-caption2">{item.prepTime}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Ваш заказ</h1>
      
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <CoffeeIcon className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Корзина пуста</p>
          <p className="ios-footnote text-tertiary-label">Добавьте что-нибудь из меню</p>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {cartItems.map((item) => (
              <div key={`${item.id}-${item.size}`} className="ios-card p-4">
                <div className="flex items-center space-x-3">
                  <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
                  <div className="flex-1">
                    <h4 className="ios-body font-semibold">{item.name}</h4>
                    <p className="ios-footnote text-secondary-label">{item.size}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-8 h-8 rounded-full bg-quaternary-system-fill flex items-center justify-center"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="ios-body font-semibold w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-8 h-8 rounded-full bg-system-orange text-white flex items-center justify-center"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="ios-body font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="ios-footnote text-system-red"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-card p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="ios-body">Подытог:</span>
              <span className="ios-body font-semibold">${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="ios-body">Доставка:</span>
              <span className="ios-body font-semibold">$2.50</span>
            </div>
            <hr className="border-separator" />
            <div className="flex justify-between items-center">
              <span className="ios-headline font-bold">Итого:</span>
              <span className="ios-headline font-bold text-system-orange">${(cartTotal + 2.5).toFixed(2)}</span>
            </div>
            
            <button className="w-full bg-system-orange text-white ios-body font-semibold py-3 rounded-xl flex items-center justify-center space-x-2">
              <CreditCard className="w-5 h-5" />
              <span>Оформить заказ</span>
            </button>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-orange rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">КР</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Кофе Рай VIP</h3>
            <p className="ios-body text-secondary-label">Постоянный клиент</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-orange">127</p>
            <p className="ios-footnote text-secondary-label">Заказов</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">$342</p>
            <p className="ios-footnote text-secondary-label">Сэкономлено</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Мои любимые</h2>
        {beverages.filter(item => favorites.includes(item.id)).map((item) => (
          <div key={item.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold">{item.name}</h4>
              <p className="ios-footnote text-secondary-label">${item.price}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedItem && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold">{selectedItem.name}</h3>
              <button onClick={closeItemModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedItem.image} alt={selectedItem.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <p className="ios-body text-secondary-label">{selectedItem.description}</p>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-secondary-label" />
                  <span className="ios-footnote">{selectedItem.prepTime}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Thermometer className="w-4 h-4 text-secondary-label" />
                  <span className="ios-footnote">{selectedItem.temperature === 'hot' ? 'Горячий' : selectedItem.temperature === 'cold' ? 'Холодный' : 'Комнатная'}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedItem.rating}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="ios-title font-bold text-system-orange">${selectedItem.price}</span>
                <span className={`px-2 py-1 rounded-full ios-caption2 font-semibold ${
                  selectedItem.caffeine === 'высокий' ? 'bg-red-100 text-red-700' :
                  selectedItem.caffeine === 'средний' ? 'bg-orange-100 text-orange-700' :
                  selectedItem.caffeine === 'низкий' ? 'bg-green-100 text-green-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {selectedItem.caffeine}
                </span>
              </div>
              
              <button className="w-full bg-system-orange text-white ios-body font-semibold py-3 rounded-xl">
                В корзину
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}