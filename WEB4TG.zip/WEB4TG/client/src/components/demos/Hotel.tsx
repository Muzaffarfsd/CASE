import { useState } from "react";
import { 
  Hotel as HotelIcon, 
  Heart, 
  Star, 
  MapPin, 
  Calendar,
  Plus,
  Minus,
  X,
  ChevronRight,
  Wifi,
  Car,
  Coffee,
  Dumbbell,
  Waves,
  Utensils,
  Users,
  Bed
} from "lucide-react";

interface HotelProps {
  activeTab: 'home' | 'catalog' | 'cart' | 'profile';
}

interface Booking {
  id: number;
  roomName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  price: number;
  status: 'Подтверждено' | 'Ожидает' | 'Завершено';
}

const rooms = [
  { id: 1, name: 'Стандартный номер', price: 89, image: 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уютный стандартный номер с видом на город', category: 'Стандарт', size: 25, guests: 2, beds: 1, floor: '3-8', view: 'Город', amenities: ['WiFi', 'Кондиционер', 'ТВ', 'Мини-бар'], rating: 4.5, available: 12, breakfast: true },
  { id: 2, name: 'Номер Делюкс', price: 145, image: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Просторный номер с улучшенным дизайном', category: 'Делюкс', size: 35, guests: 2, beds: 1, floor: '5-12', view: 'Парк', amenities: ['WiFi', 'Кондиционер', 'ТВ', 'Мини-бар', 'Сейф', 'Халаты'], rating: 4.7, available: 8, breakfast: true },
  { id: 3, name: 'Семейный номер', price: 189, image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Идеальный выбор для семьи с детьми', category: 'Семейный', size: 45, guests: 4, beds: 2, floor: '2-6', view: 'Город', amenities: ['WiFi', 'Кондиционер', 'ТВ', 'Мини-бар', 'Детская кроватка', 'Игровая зона'], rating: 4.6, available: 5, breakfast: true },
  { id: 4, name: 'Бизнес-номер', price: 165, image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Номер для деловых путешествий с рабочей зоной', category: 'Бизнес', size: 30, guests: 2, beds: 1, floor: '7-15', view: 'Город', amenities: ['WiFi', 'Рабочий стол', 'ТВ', 'Кофемашина', 'Сейф', 'Принтер'], rating: 4.8, available: 7, breakfast: true },
  { id: 5, name: 'Джуниор Сьют', price: 245, image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Элегантный сьют с отдельной гостиной', category: 'Сьют', size: 55, guests: 3, beds: 1, floor: '10-18', view: 'Парк', amenities: ['WiFi', 'Гостиная', 'ТВ', 'Мини-бар', 'Джакузи', 'Балкон'], rating: 4.9, available: 3, breakfast: true },
  { id: 6, name: 'Номер с видом на море', price: 199, image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Романтический номер с панорамным видом', category: 'Премиум', size: 32, guests: 2, beds: 1, floor: '8-20', view: 'Море', amenities: ['WiFi', 'Панорамные окна', 'ТВ', 'Мини-бар', 'Балкон'], rating: 4.8, available: 6, breakfast: true },
  { id: 7, name: 'Экономичный номер', price: 59, image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Бюджетный вариант с базовыми удобствами', category: 'Эконом', size: 18, guests: 2, beds: 1, floor: '1-3', view: 'Двор', amenities: ['WiFi', 'ТВ', 'Душ'], rating: 4.2, available: 15, breakfast: false },
  { id: 8, name: 'Пентхаус', price: 450, image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Роскошный пентхаус с террасой', category: 'Люкс', size: 120, guests: 6, beds: 3, floor: '25', view: 'Панорама', amenities: ['WiFi', 'Терраса', 'Джакузи', 'Мини-бар', 'Кухня', 'Батлер'], rating: 5.0, available: 1, breakfast: true },
  { id: 9, name: 'Одноместный номер', price: 69, image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Компактный номер для одного гостя', category: 'Стандарт', size: 20, guests: 1, beds: 1, floor: '2-10', view: 'Город', amenities: ['WiFi', 'ТВ', 'Мини-бар', 'Рабочая зона'], rating: 4.4, available: 9, breakfast: true },
  { id: 10, name: 'Номер для молодоженов', price: 289, image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Романтическая обстановка для особого случая', category: 'Романтик', size: 40, guests: 2, beds: 1, floor: '15-20', view: 'Море', amenities: ['WiFi', 'Джакузи', 'Шампанское', 'Лепестки роз', 'Свечи', 'Завтрак в номер'], rating: 4.9, available: 2, breakfast: true },
  { id: 11, name: 'Апартаменты с кухней', price: 220, image: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Просторные апартаменты с полноценной кухней', category: 'Апартаменты', size: 65, guests: 4, beds: 2, floor: '5-12', view: 'Парк', amenities: ['WiFi', 'Кухня', 'Стиральная машина', 'ТВ', 'Балкон'], rating: 4.7, available: 4, breakfast: false },
  { id: 12, name: 'VIP Сьют', price: 380, image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Эксклюзивный сьют с персональным сервисом', category: 'VIP', size: 85, guests: 4, beds: 2, floor: '20-25', view: 'Панорама', amenities: ['WiFi', 'Персональный батлер', 'Спа-ванна', 'Мини-бар', 'Кабинет'], rating: 5.0, available: 2, breakfast: true },
  { id: 13, name: 'Студия', price: 125, image: 'https://images.unsplash.com/photo-1560448075-bb485b067938?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Современная студия с мини-кухней', category: 'Студия', size: 28, guests: 2, beds: 1, floor: '3-8', view: 'Город', amenities: ['WiFi', 'Мини-кухня', 'ТВ', 'Кондиционер'], rating: 4.5, available: 11, breakfast: false },
  { id: 14, name: 'Номер с сауной', price: 199, image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Релаксирующий номер с личной сауной', category: 'Спа', size: 42, guests: 2, beds: 1, floor: '1-5', view: 'Сад', amenities: ['WiFi', 'Сауна', 'Джакузи', 'ТВ', 'Мини-бар'], rating: 4.8, available: 3, breakfast: true },
  { id: 15, name: 'Хостел-номер', price: 35, image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Бюджетное размещение в общем номере', category: 'Хостел', size: 12, guests: 1, beds: 1, floor: '1-2', view: 'Двор', amenities: ['WiFi', 'Общая кухня', 'Общий душ'], rating: 4.0, available: 20, breakfast: false },
  { id: 16, name: 'Номер для инвалидов', price: 95, image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Специально адаптированный номер', category: 'Доступный', size: 30, guests: 2, beds: 1, floor: '1-3', view: 'Сад', amenities: ['WiFi', 'Доступная ванная', 'ТВ', 'Экстренная кнопка'], rating: 4.6, available: 6, breakfast: true },
  { id: 17, name: 'Номер с террасой', price: 175, image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Номер с собственной террасой и мебелью', category: 'Терраса', size: 38, guests: 3, beds: 1, floor: '8-15', view: 'Парк', amenities: ['WiFi', 'Терраса', 'ТВ', 'Мини-бар', 'Садовая мебель'], rating: 4.7, available: 5, breakfast: true },
  { id: 18, name: 'Тематический номер "Сафари"', price: 155, image: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уникальный номер в африканском стиле', category: 'Тематический', size: 35, guests: 2, beds: 1, floor: '5-10', view: 'Город', amenities: ['WiFi', 'Тематический декор', 'ТВ', 'Мини-бар'], rating: 4.6, available: 3, breakfast: true },
  { id: 19, name: 'Люкс с камином', price: 265, image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Уютный люкс с действующим камином', category: 'Люкс', size: 50, guests: 3, beds: 1, floor: '12-18', view: 'Горы', amenities: ['WiFi', 'Камин', 'ТВ', 'Мини-бар', 'Гостиная'], rating: 4.9, available: 4, breakfast: true },
  { id: 20, name: 'Президентский сьют', price: 599, image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400', description: 'Самый роскошный номер отеля', category: 'Президентский', size: 150, guests: 8, beds: 4, floor: '26', view: 'Панорама 360°', amenities: ['WiFi', 'Персональный повар', 'Спа-зона', 'Кабинет', 'Гостиная', 'Терраса'], rating: 5.0, available: 1, breakfast: true }
];

const categories = ['Все', 'Стандарт', 'Делюкс', 'Сьют', 'Люкс', 'Семейный', 'Бизнес', 'Эконом', 'VIP', 'Президентский'];

const initialBookings: Booking[] = [
  { id: 1, roomName: 'Номер Делюкс', checkIn: '25 дек', checkOut: '28 дек', guests: 2, price: 435, status: 'Подтверждено' },
  { id: 2, roomName: 'Семейный номер', checkIn: '15 янв', checkOut: '18 янв', guests: 4, price: 567, status: 'Подтверждено' },
];

export default function Hotel({ activeTab }: HotelProps) {
  const [selectedRoom, setSelectedRoom] = useState<typeof rooms[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [favorites, setFavorites] = useState<number[]>([2, 5, 8, 12]);
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(2);

  const openRoomModal = (room: typeof rooms[0]) => {
    setSelectedRoom(room);
    setIsModalOpen(true);
  };

  const closeRoomModal = () => {
    setIsModalOpen(false);
    setSelectedRoom(null);
  };

  const toggleFavorite = (roomId: number) => {
    setFavorites(prev => 
      prev.includes(roomId) 
        ? prev.filter(id => id !== roomId)
        : [...prev, roomId]
    );
  };

  const filteredRooms = selectedCategory === 'Все' 
    ? rooms 
    : rooms.filter(room => room.category === selectedCategory);

  const renderHomeTab = () => (
    <div className="max-w-md mx-auto px-4 space-y-6">
      {/* Заголовок */}
      <div className="text-center">
        <h1 className="ios-title font-bold mb-2">ОтельБукинг</h1>
        <p className="ios-subheadline text-secondary-label">Комфортное размещение 🏨</p>
      </div>

      {/* Поиск номера */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-4">Найти номер</h3>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="ios-footnote text-secondary-label mb-1">Заезд</p>
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="w-full p-2 bg-quaternary-system-fill rounded-lg ios-body"
              />
            </div>
            <div>
              <p className="ios-footnote text-secondary-label mb-1">Выезд</p>
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="w-full p-2 bg-quaternary-system-fill rounded-lg ios-body"
              />
            </div>
          </div>
          
          <div>
            <p className="ios-footnote text-secondary-label mb-1">Гостей</p>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setGuests(Math.max(1, guests - 1))}
                className="w-8 h-8 rounded-full bg-quaternary-system-fill flex items-center justify-center"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="ios-body font-semibold w-8 text-center">{guests}</span>
              <button
                onClick={() => setGuests(guests + 1)}
                className="w-8 h-8 rounded-full bg-system-purple text-white flex items-center justify-center"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
        <button className="w-full bg-system-purple text-white ios-body font-semibold py-3 rounded-xl mt-4">
          Найти номера
        </button>
      </div>

      {/* Популярные категории */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Популярные категории</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: 'Стандарт', price: 'от $59', icon: Bed, color: 'bg-blue-500' },
            { name: 'Делюкс', price: 'от $145', icon: Star, color: 'bg-purple-500' },
            { name: 'Сьют', price: 'от $245', icon: HotelIcon, color: 'bg-yellow-500' },
            { name: 'Люкс', price: 'от $265', icon: Star, color: 'bg-red-500' }
          ].map((category) => (
            <div 
              key={category.name} 
              className="ios-card p-3 cursor-pointer"
              onClick={() => setSelectedCategory(category.name)}
            >
              <div className={`w-12 h-12 ${category.color} rounded-lg mb-2 flex items-center justify-center`}>
                <category.icon className="w-6 h-6 text-white" />
              </div>
              <h4 className="ios-footnote font-semibold">{category.name}</h4>
              <p className="ios-caption2 text-secondary-label">{category.price}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Рекомендуемые номера */}
      <div>
        <h2 className="ios-title font-semibold mb-4">Рекомендуем</h2>
        <div className="space-y-3">
          {rooms.slice(0, 3).map((room) => (
            <div 
              key={room.id} 
              className="ios-card p-3 cursor-pointer flex items-center space-x-3"
              onClick={() => openRoomModal(room)}
            >
              <img src={room.image} alt={room.name} className="w-16 h-16 object-cover rounded-lg" />
              <div className="flex-1">
                <h4 className="ios-body font-semibold">{room.name}</h4>
                <p className="ios-footnote text-secondary-label">{room.size}м² • до {room.guests} гостей</p>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span className="ios-caption2">{room.rating}</span>
                  </div>
                  <span className="ios-caption font-bold text-system-purple">${room.price}/ночь</span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-tertiary-label" />
            </div>
          ))}
        </div>
      </div>

      {/* Удобства отеля */}
      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Удобства отеля</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { icon: Wifi, label: 'WiFi' },
            { icon: Car, label: 'Парковка' },
            { icon: Waves, label: 'Бассейн' },
            { icon: Dumbbell, label: 'Фитнес' },
            { icon: Coffee, label: 'Ресторан' },
            { icon: Utensils, label: 'Завтрак' }
          ].map((amenity, index) => (
            <div key={index} className="text-center">
              <amenity.icon className="w-6 h-6 text-system-purple mx-auto mb-1" />
              <span className="ios-caption2 text-secondary-label">{amenity.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCatalogTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Доступные номера</h1>
      
      {/* Категории */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ios-footnote font-medium ${
              selectedCategory === category
                ? 'bg-system-purple text-white'
                : 'bg-quaternary-system-fill text-label'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Список номеров */}
      <div className="space-y-3">
        {filteredRooms.map((room) => (
          <div 
            key={room.id} 
            className="ios-card p-4 cursor-pointer"
            onClick={() => openRoomModal(room)}
          >
            <div className="flex items-center space-x-3">
              <img src={room.image} alt={room.name} className="w-20 h-20 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="ios-body font-semibold line-clamp-1">{room.name}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(room.id);
                    }}
                    className="p-1"
                  >
                    <Heart 
                      className={`w-4 h-4 ${
                        favorites.includes(room.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-secondary-label'
                      }`} 
                    />
                  </button>
                </div>
                <p className="ios-footnote text-secondary-label mb-1">{room.size}м² • до {room.guests} гостей • {room.view}</p>
                <p className="ios-caption2 text-tertiary-label mb-2 line-clamp-1">{room.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="ios-caption2 px-2 py-1 bg-quaternary-system-fill rounded">{room.category}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="ios-caption2">{room.rating}</span>
                    </div>
                    <span className="ios-caption2 text-secondary-label">Доступно: {room.available}</span>
                  </div>
                  <span className="ios-body font-bold text-system-purple">${room.price}/ночь</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCartTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Мои бронирования</h1>
      
      {bookings.length === 0 ? (
        <div className="text-center py-12">
          <HotelIcon className="w-16 h-16 text-quaternary-label mx-auto mb-4" />
          <p className="ios-body text-secondary-label">Нет бронирований</p>
          <p className="ios-footnote text-tertiary-label">Забронируйте номер из каталога</p>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {bookings.map((booking) => (
              <div key={booking.id} className="ios-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="ios-body font-semibold">{booking.roomName}</h4>
                  <span className={`px-2 py-1 rounded-full ios-caption2 font-semibold ${
                    booking.status === 'Подтверждено' ? 'bg-green-100 text-green-700' :
                    booking.status === 'Ожидает' ? 'bg-orange-100 text-orange-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {booking.status}
                  </span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-secondary-label" />
                    <span className="ios-footnote">{booking.checkIn} - {booking.checkOut}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-secondary-label" />
                    <span className="ios-footnote">{booking.guests} гостей</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="ios-body">Общая стоимость:</span>
                    <span className="ios-body font-bold text-system-purple">${booking.price}</span>
                  </div>
                </div>

                <div className="flex space-x-2 mt-3">
                  <button className="flex-1 bg-quaternary-system-fill text-label ios-footnote font-medium py-2 rounded-lg">
                    Изменить
                  </button>
                  <button className="flex-1 bg-system-red text-white ios-footnote font-medium py-2 rounded-lg">
                    Отменить
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-card p-4">
            <h3 className="ios-headline font-semibold mb-2">Статистика</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="ios-title font-bold text-system-purple">{bookings.length}</p>
                <p className="ios-footnote text-secondary-label">Бронирований</p>
              </div>
              <div className="text-center">
                <p className="ios-title font-bold text-system-green">
                  ${bookings.reduce((sum, booking) => sum + booking.price, 0)}
                </p>
                <p className="ios-footnote text-secondary-label">Общая сумма</p>
              </div>
            </div>
          </div>

          {/* Контакты отеля */}
          <div className="ios-card p-4 bg-system-purple/5 border border-system-purple/20">
            <div className="flex items-center space-x-2 mb-2">
              <MapPin className="w-4 h-4 text-system-purple" />
              <span className="ios-body font-semibold text-system-purple">Контакты отеля</span>
            </div>
            <p className="ios-footnote text-secondary-label">
              ул. Гостиничная, 25 (центр города)
            </p>
            <p className="ios-footnote text-secondary-label">
              Тел: +7 (800) 123-45-67
            </p>
          </div>
        </>
      )}
    </div>
  );

  const renderProfileTab = () => (
    <div className="space-y-4">
      <h1 className="ios-title font-bold">Профиль гостя</h1>
      
      <div className="ios-card p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-16 h-16 bg-system-purple rounded-full flex items-center justify-center">
            <span className="ios-title font-bold text-white">ОБ</span>
          </div>
          <div>
            <h3 className="ios-headline font-semibold">Золотой гость</h3>
            <p className="ios-body text-secondary-label">Постоянный клиент</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <p className="ios-title font-bold text-system-purple">24</p>
            <p className="ios-footnote text-secondary-label">Ночей</p>
          </div>
          <div className="text-center">
            <p className="ios-title font-bold text-system-green">15%</p>
            <p className="ios-footnote text-secondary-label">Скидка</p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="ios-headline font-semibold">Избранные номера</h2>
        {rooms.filter(room => favorites.includes(room.id)).map((room) => (
          <div key={room.id} className="ios-card p-3 flex items-center space-x-3">
            <img src={room.image} alt={room.name} className="w-12 h-12 object-cover rounded-lg" />
            <div className="flex-1">
              <h4 className="ios-body font-semibold line-clamp-1">{room.name}</h4>
              <p className="ios-footnote text-secondary-label">{room.category} • ${room.price}/ночь</p>
            </div>
            <ChevronRight className="w-5 h-5 text-tertiary-label" />
          </div>
        ))}
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">Предпочтения</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Любимая категория:</span>
            <span className="ios-body font-medium">Делюкс</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Тип размещения:</span>
            <span className="ios-body font-medium">2 гостя</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Средний чек:</span>
            <span className="ios-body font-medium">$185/ночь</span>
          </div>
        </div>
      </div>

      <div className="ios-card p-4">
        <h3 className="ios-headline font-semibold mb-3">История проживаний</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="ios-body">Последнее пребывание:</span>
            <span className="ios-body font-medium">Ноябрь 2024</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Всего ночей:</span>
            <span className="ios-body font-medium">24</span>
          </div>
          <div className="flex justify-between">
            <span className="ios-body">Потрачено всего:</span>
            <span className="ios-body font-medium text-system-purple">$4,440</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-system-background">
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'home' && renderHomeTab()}
        {activeTab === 'catalog' && renderCatalogTab()}
        {activeTab === 'cart' && renderCartTab()}
        {activeTab === 'profile' && renderProfileTab()}
      </div>

      {/* Модальное окно */}
      {isModalOpen && selectedRoom && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-system-background max-w-md mx-auto w-full rounded-t-3xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start">
              <h3 className="ios-title font-bold line-clamp-2">{selectedRoom.name}</h3>
              <button onClick={closeRoomModal}>
                <X className="w-6 h-6 text-secondary-label" />
              </button>
            </div>
            
            <img src={selectedRoom.image} alt={selectedRoom.name} className="w-full h-48 object-cover rounded-xl" />
            
            <div className="space-y-3">
              <p className="ios-body text-secondary-label">{selectedRoom.description}</p>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="ios-card p-3 text-center">
                  <span className="ios-body font-semibold text-secondary-label mx-auto mb-1">{selectedRoom.size}</span>
                  <p className="ios-caption2 text-secondary-label">Площадь</p>
                  <p className="ios-body font-semibold">м²</p>
                </div>
                <div className="ios-card p-3 text-center">
                  <Users className="w-5 h-5 text-secondary-label mx-auto mb-1" />
                  <p className="ios-caption2 text-secondary-label">Гостей</p>
                  <p className="ios-body font-semibold">{selectedRoom.guests}</p>
                </div>
                <div className="ios-card p-3 text-center">
                  <Bed className="w-5 h-5 text-secondary-label mx-auto mb-1" />
                  <p className="ios-caption2 text-secondary-label">Кроватей</p>
                  <p className="ios-body font-semibold">{selectedRoom.beds}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="ios-body font-semibold">Удобства:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedRoom.amenities.map((amenity, index) => (
                    <span key={index} className="px-3 py-1 rounded-full ios-caption2 font-semibold bg-quaternary-system-fill text-label">
                      {amenity}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="ios-footnote">{selectedRoom.rating}</span>
                </div>
                <span className="ios-footnote text-secondary-label">
                  Этаж: {selectedRoom.floor}
                </span>
                <span className="ios-footnote text-secondary-label">
                  Вид: {selectedRoom.view}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="ios-footnote text-secondary-label">За ночь</p>
                  <p className="ios-title font-bold text-system-purple">${selectedRoom.price}</p>
                </div>
                <div className="text-right">
                  <p className="ios-footnote text-secondary-label">Доступно номеров</p>
                  <p className="ios-body font-semibold">{selectedRoom.available}</p>
                </div>
              </div>
              
              {selectedRoom.breakfast && (
                <div className="ios-card p-3 bg-green-50 border border-green-200">
                  <div className="flex items-center space-x-2">
                    <Coffee className="w-4 h-4 text-green-600" />
                    <span className="ios-footnote text-green-600 font-semibold">Завтрак включен</span>
                  </div>
                </div>
              )}
              
              <button className="w-full bg-system-purple text-white ios-body font-semibold py-3 rounded-xl">
                Забронировать номер
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}