import { useState } from "react";
import { 
  Calculator, 
  Home, 
  Wrench, 
  User,
  Store,
  Coffee,
  Dumbbell,
  GraduationCap,
  Heart,
  Settings,
  Check,
  Shield,
  Clock,
  TrendingUp,
  ArrowRight,
  Info,
  Sparkles,
  Rocket,
  CreditCard,
  UserCircle2,
  Crown,
  Plus
} from "lucide-react";
import StickyGlassHeader from "./ui/StickyGlassHeader";

interface PricingPageProps {
  onNavigate: (section: string) => void;
}

const appTypes = [
  { id: 'store', name: 'Магазин', icon: Store, basePrice: 25000, timeframe: '5-7 дней' },
  { id: 'restaurant', name: 'Ресторан', icon: Coffee, basePrice: 30000, timeframe: '7-10 дней' },
  { id: 'fitness', name: 'Фитнес', icon: Dumbbell, basePrice: 35000, timeframe: '8-12 дней' },
  { id: 'education', name: 'Обучение', icon: GraduationCap, basePrice: 40000, timeframe: '10-14 дней' },
  { id: 'medical', name: 'Медицина', icon: Heart, basePrice: 45000, timeframe: '12-16 дней' },
  { id: 'services', name: 'Услуги', icon: Settings, basePrice: 28000, timeframe: '6-9 дней' }
];

const designLevels = [
  { id: 'minimal', name: 'Базовый', price: 0, description: 'Чистый функциональный дизайн' },
  { id: 'modern', name: 'Современный', price: 15000, description: 'Стильный дизайн с акцентами' },
  { id: 'premium', name: 'Премиум', price: 35000, description: 'Уникальный брендированный дизайн' }
];

const coreFeatures = [
  { id: 'catalog', name: 'Каталог', price: 8000, included: true },
  { id: 'cart', name: 'Корзина', price: 12000, included: true },
  { id: 'payments', name: 'Платежи', price: 15000, included: false },
  { id: 'delivery', name: 'Доставка', price: 12000, included: false },
  { id: 'loyalty', name: 'Бонусы', price: 20000, included: false },
  { id: 'analytics', name: 'Аналитика', price: 12000, included: false }
];

export default function PricingPage({ onNavigate }: PricingPageProps) {
  const [selectedAppType, setSelectedAppType] = useState(appTypes[0]);
  const [selectedDesign, setSelectedDesign] = useState(designLevels[0]);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>(['catalog', 'cart']);

  const calculateTotal = () => {
    const basePrice = selectedAppType.basePrice;
    const designPrice = selectedDesign.price;
    const featuresPrice = coreFeatures
      .filter(f => selectedFeatures.includes(f.id) && !f.included)
      .reduce((sum, f) => sum + f.price, 0);
    return basePrice + designPrice + featuresPrice;
  };

  const toggleFeature = (featureId: string) => {
    const feature = coreFeatures.find(f => f.id === featureId);
    if (feature?.included) return; // Can't deselect included features
    
    setSelectedFeatures(prev =>
      prev.includes(featureId)
        ? prev.filter(id => id !== featureId)
        : [...prev, featureId]
    );
  };

  return (
    <div className="min-h-screen bg-white text-label safe-area-top pb-32 relative">
      {/* Animated Background Effects */}
      <div className="wow-bg-animated"></div>
      <div className="wow-bg-mesh"></div>
      
      {/* Morphing Blobs */}
      <div className="wow-blob wow-blob-1"></div>
      <div className="wow-blob wow-blob-2"></div>
      <div className="wow-blob wow-blob-3"></div>

      <StickyGlassHeader />

      <div className="max-w-md mx-auto px-4 space-y-8">
        {/* Value Proposition */}
        <section className="ios-card p-6 bg-system-green/5 border-system-green/20">
          <div className="text-center space-y-3">
            <div className="inline-flex items-center space-x-2 bg-system-green/10 px-3 py-1 rounded-full">
              <Shield className="w-4 h-4 text-system-green" />
              <span className="ios-footnote text-system-green font-semibold">Фиксированная цена</span>
            </div>
            <h2 className="ios-title3">Никаких доплат</h2>
            <p className="ios-subheadline text-secondary-label">
              Оплата по этапам. Возврат 100% если не подойдет
            </p>
          </div>
        </section>

        {/* App Type Selection */}
        <section className="ios-slide-up">
          <div className="mb-4">
            <h3 className="ios-title3 mb-1">Тип приложения</h3>
            <p className="ios-footnote text-secondary-label">Выберите направление вашего бизнеса</p>
          </div>

          {/* Glass Icon Grid */}
          <div className="grid grid-cols-3 gap-3">
            {appTypes.slice(0, 3).map((type) => {
              const IconComponent = type.icon;
              return (
                <button
                  key={type.id}
                  className={`${
                    selectedAppType.id === type.id 
                      ? 'glass-card-strong glass-floating border-system-green/30' 
                      : 'glass-card'
                  } flex flex-col items-center py-4 transition-all duration-300`}
                  onClick={() => setSelectedAppType(type)}
                  data-testid={`app-type-${type.id}`}
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                    selectedAppType.id === type.id 
                      ? 'bg-system-green/20' 
                      : 'bg-system-blue/10'
                  }`}>
                    <IconComponent className={`w-6 h-6 ${
                      selectedAppType.id === type.id 
                        ? 'text-system-green' 
                        : 'text-system-blue'
                    }`} />
                  </div>
                  <span className="ios-caption1 font-semibold">{type.name}</span>
                </button>
              );
            })}
          </div>

          {/* Second Row */}
          <div className="grid grid-cols-3 gap-3 mt-3">
            {appTypes.slice(3).map((type) => {
              const IconComponent = type.icon;
              return (
                <button
                  key={type.id}
                  className={`${
                    selectedAppType.id === type.id 
                      ? 'glass-card-strong glass-floating border-system-green/30' 
                      : 'glass-card'
                  } flex flex-col items-center py-4 transition-all duration-300`}
                  onClick={() => setSelectedAppType(type)}
                  data-testid={`app-type-${type.id}`}
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                    selectedAppType.id === type.id 
                      ? 'bg-system-green/20' 
                      : 'bg-system-blue/10'
                  }`}>
                    <IconComponent className={`w-6 h-6 ${
                      selectedAppType.id === type.id 
                        ? 'text-system-green' 
                        : 'text-system-blue'
                    }`} />
                  </div>
                  <span className="ios-caption1 font-semibold">{type.name}</span>
                </button>
              );
            })}
          </div>

          {/* Selected App Info */}
          <div className="ios-card mt-4 p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="ios-headline font-semibold">{selectedAppType.name}</div>
                <div className="ios-footnote text-secondary-label flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>Готовность: {selectedAppType.timeframe}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="ios-title3 font-bold text-system-blue">
                  {selectedAppType.basePrice.toLocaleString()} ₽
                </div>
                <div className="ios-caption2 text-secondary-label">базовая цена</div>
              </div>
            </div>
          </div>
        </section>

        {/* Design Level */}
        <section className="ios-slide-up">
          <div className="mb-4">
            <h3 className="ios-title3 mb-1">Уровень дизайна</h3>
            <p className="ios-footnote text-secondary-label">Влияет на внешний вид и узнаваемость</p>
          </div>

          <div className="ios-list">
            {designLevels.map((design) => (
              <div
                key={design.id}
                className={`ios-list-item cursor-pointer ${
                  selectedDesign.id === design.id ? 'bg-system-blue/10' : ''
                }`}
                onClick={() => setSelectedDesign(design)}
                data-testid={`design-${design.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        selectedDesign.id === design.id 
                          ? 'bg-system-green border-system-green' 
                          : 'border-tertiary-label'
                      }`}>
                        {selectedDesign.id === design.id && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                      <div>
                        <div className="ios-body font-semibold">{design.name}</div>
                        <div className="ios-footnote text-secondary-label">{design.description}</div>
                      </div>
                    </div>
                  </div>
                  <div className="ios-body font-semibold text-system-blue">
                    {design.price > 0 ? `+${design.price.toLocaleString()} ₽` : 'Включено'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section className="ios-slide-up">
          <div className="mb-4">
            <h3 className="ios-title3 mb-1">Дополнительные функции</h3>
            <p className="ios-footnote text-secondary-label">Расширьте возможности приложения</p>
          </div>

          <div className="ios-list">
            <div className="ios-list-header">Базовые функции включены</div>
            {coreFeatures.filter(f => f.included).map((feature) => (
              <div key={feature.id} className="ios-list-item">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-system-green" />
                    <div className="ios-body font-semibold">{feature.name}</div>
                  </div>
                  <div className="ios-footnote text-system-green font-semibold">Включено</div>
                </div>
              </div>
            ))}
          </div>

          <div className="ios-list mt-4">
            <div className="ios-list-header">Дополнительные возможности</div>
            {coreFeatures.filter(f => !f.included).map((feature) => (
              <div
                key={feature.id}
                className="ios-list-item cursor-pointer"
                onClick={() => toggleFeature(feature.id)}
                data-testid={`feature-${feature.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                      selectedFeatures.includes(feature.id)
                        ? 'bg-system-green border-system-green'
                        : 'border-tertiary-label'
                    }`}>
                      {selectedFeatures.includes(feature.id) && (
                        <Check className="w-3 h-3 text-white m-auto" />
                      )}
                    </div>
                    <div className="ios-body font-semibold">{feature.name}</div>
                  </div>
                  <div className="ios-body font-semibold text-system-blue">
                    +{feature.price.toLocaleString()} ₽
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Benefits */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 space-y-4">
            <h3 className="ios-title3 text-center">Что получаете</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <TrendingUp className="w-5 h-5 text-system-blue mt-0.5" />
                <div>
                  <div className="ios-body font-semibold">Рост продаж на 40-180%</div>
                  <div className="ios-footnote text-secondary-label">Клиенты покупают чаще и больше</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Shield className="w-5 h-5 text-system-green mt-0.5" />
                <div>
                  <div className="ios-body font-semibold">6 месяцев гарантии</div>
                  <div className="ios-footnote text-secondary-label">Бесплатные исправления и доработки</div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="w-5 h-5 text-system-orange mt-0.5" />
                <div>
                  <div className="ios-body font-semibold">Быстрый запуск</div>
                  <div className="ios-footnote text-secondary-label">От идеи до продаж за {selectedAppType.timeframe}</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Risk Reversal */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 bg-system-orange/5 border-system-orange/20 text-center space-y-3">
            <h3 className="ios-title3">Работаем без рисков</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-center space-x-2">
                <Check className="w-4 h-4 text-system-green" />
                <span className="ios-footnote">Оплата по этапам готовности</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <Check className="w-4 h-4 text-system-green" />
                <span className="ios-footnote">Возврат денег если не понравится</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <Check className="w-4 h-4 text-system-green" />
                <span className="ios-footnote">Бесплатные правки в течение месяца</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Sticky Price Summary - iOS CTA Bar */}
      <div className="ios-cta-bar fixed bottom-20 left-0 right-0" data-testid="price-summary">
        <div className="max-w-md mx-auto px-4">
          <div className="ios-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="ios-footnote text-secondary-label">Итоговая стоимость</div>
                <div className="ios-title2 font-bold text-system-blue" data-testid="total-price">
                  {calculateTotal().toLocaleString()} ₽
                </div>
              </div>
              <div className="text-right">
                <div className="ios-footnote text-secondary-label">Готовность</div>
                <div className="ios-body font-semibold">{selectedAppType.timeframe}</div>
              </div>
            </div>
            <button
              className="ios-button-filled w-full"
              onClick={() => onNavigate('constructor')}
              data-testid="button-start-project"
            >
              Заказать за {calculateTotal().toLocaleString()} ₽
            </button>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="ios-footnote text-secondary-label">
                <div className="font-semibold">Старт</div>
                <div>Сегодня</div>
              </div>
              <div className="ios-footnote text-secondary-label">
                <div className="font-semibold">Первый этап</div>
                <div>30% предоплата</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}