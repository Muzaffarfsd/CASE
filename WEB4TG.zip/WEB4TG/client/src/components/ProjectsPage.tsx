import { 
  ArrowLeft, 
  ArrowRight,
  Search, 
  Filter, 
  Store,
  Coffee,
  Dumbbell,
  Heart,
  Smartphone,
  Book,
  Flower,
  Car,
  GraduationCap,
  Pill,
  Home,
  Plane,
  CreditCard,
  Building,
  Star,
  Zap,
  Trophy,
  Award,
  TrendingUp,
  Users,
  CheckCircle,
  Sparkles,
  Eye,
  Clock
} from "lucide-react";
import StickyGlassHeader from "./ui/StickyGlassHeader";
import { useState, useRef, useEffect, useMemo } from "react";
import { demoApps } from "@/data/demoApps";

// Category mapping for icons and colors
const categoryConfig = {
  'Электронная коммерция': { icon: Store, color: 'from-blue-500 to-cyan-500' },
  'Еда и Напитки': { icon: Coffee, color: 'from-orange-500 to-red-500' },
  'Здоровье и Фитнес': { icon: Dumbbell, color: 'from-green-500 to-emerald-500' },
  'Красота и Здоровье': { icon: Heart, color: 'from-purple-500 to-pink-500' },
  'Образование': { icon: GraduationCap, color: 'from-indigo-500 to-purple-500' },
  'Подарки и Цветы': { icon: Flower, color: 'from-pink-500 to-rose-500' },
  'Автоуслуги': { icon: Car, color: 'from-gray-500 to-slate-500' },
  'Здравоохранение': { icon: Pill, color: 'from-red-500 to-pink-500' },
  'Недвижимость': { icon: Home, color: 'from-amber-500 to-orange-500' },
  'Транспорт': { icon: Plane, color: 'from-teal-500 to-cyan-500' },
  'Финансы': { icon: CreditCard, color: 'from-emerald-500 to-teal-500' },
  'Туризм': { icon: Building, color: 'from-rose-500 to-pink-500' }
};

// Custom hook for count-up animation
const useCountUp = (endValue: number, duration: number = 2000) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
          
          if (prefersReducedMotion) {
            setCount(endValue);
            return;
          }
          
          let startTime: number;
          const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = Math.min((currentTime - startTime) / duration, 1);
            const easeOutQuart = 1 - Math.pow(1 - progress, 4);
            setCount(Math.floor(easeOutQuart * endValue));
            
            if (progress < 1) {
              requestAnimationFrame(animate);
            }
          };
          
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [endValue, duration, isVisible]);

  return { count, ref };
};

interface ProjectsPageProps {
  onNavigate: (section: string) => void;
  onOpenDemo: (demoId: string) => void;
}

export default function ProjectsPage({ onNavigate, onOpenDemo }: ProjectsPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Generate dynamic categories from demoApps
  const categories = useMemo(() => {
    const categoryMap = new Map<string, typeof demoApps>();
    
    demoApps.forEach(app => {
      if (!categoryMap.has(app.category)) {
        categoryMap.set(app.category, []);
      }
      categoryMap.get(app.category)!.push(app);
    });

    return Array.from(categoryMap.entries()).map(([categoryName, apps]) => ({
      id: categoryName.toLowerCase().replace(/\s+/g, '-'),
      name: categoryName,
      icon: categoryConfig[categoryName as keyof typeof categoryConfig]?.icon || Store,
      color: categoryConfig[categoryName as keyof typeof categoryConfig]?.color || 'from-gray-500 to-slate-500',
      apps: apps
    }));
  }, []);

  // Count-up hooks for stats (dynamic values)
  const totalAppsCount = useCountUp(demoApps.length);
  const categoriesCount = useCountUp(categories.length);
  const businessAppsCount = useCountUp(categories.length);

  // Filter apps by search and category
  const filteredApps = useMemo(() => {
    return demoApps.filter(app => {
      const matchesSearch = (app.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (app.description || '').toLowerCase().includes(searchQuery.toLowerCase());
      
      if (selectedCategory === 'all') return matchesSearch;
      
      const category = categories.find(cat => cat.id === selectedCategory);
      return matchesSearch && app.category === category?.name;
    });
  }, [searchQuery, selectedCategory, categories]);

  // Filter categories for display in "all" mode
  const filteredCategories = useMemo(() => {
    if (selectedCategory !== 'all') return categories;
    
    return categories.map(category => ({
      ...category,
      apps: category.apps.filter(app => 
        (app.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (app.description || '').toLowerCase().includes(searchQuery.toLowerCase())
      )
    })).filter(category => category.apps.length > 0);
  }, [categories, searchQuery, selectedCategory]);

  return (
    <div className="min-h-screen bg-white text-label safe-area-top pb-32 relative">
      {/* Animated Background Effects */}
      <div className="wow-bg-animated"></div>
      <div className="wow-bg-mesh"></div>
      
      {/* Morphing Blobs */}
      <div className="wow-blob wow-blob-1"></div>
      <div className="wow-blob wow-blob-2"></div>
      <div className="wow-blob wow-blob-3"></div>

      <StickyGlassHeader />

      {/* Hero Stats Section - Mobile Style */}
      <section className="relative z-10 py-6">
        <div className="max-w-md mx-auto px-4">
          <div className="text-center mb-6">
            <div className="wow-shimmer">
              <h2 className="text-3xl font-black mb-3 leading-tight">
                <span className="wow-gradient-text">{demoApps.length}</span> готовых решений
              </h2>
            </div>
            <p className="text-base text-secondary-label leading-relaxed">
              Выберите готовый шаблон для вашего бизнеса из {categories.length} категорий
            </p>
          </div>

          {/* Animated Stats Cards - Mobile */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            <div 
              ref={totalAppsCount.ref}
              className="glass-card text-center py-4 hover:scale-105 transition-transform duration-300"
            >
              <div className="text-2xl font-black wow-gradient-text mb-1">
                {totalAppsCount.count}
              </div>
              <div className="text-xs text-secondary-label">
                Проектов
              </div>
            </div>
            <div 
              ref={categoriesCount.ref}
              className="glass-card text-center py-4 hover:scale-105 transition-transform duration-300"
            >
              <div className="text-2xl font-black wow-gradient-text mb-1">
                {categoriesCount.count}
              </div>
              <div className="text-xs text-secondary-label">
                Категорий
              </div>
            </div>
            <div 
              ref={businessAppsCount.ref}
              className="glass-card text-center py-4 hover:scale-105 transition-transform duration-300"
            >
              <div className="text-2xl font-black wow-gradient-text mb-1">
                {businessAppsCount.count}
              </div>
              <div className="text-xs text-secondary-label">
                Типов
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter Section - Mobile Style */}
      <section className="relative z-10 py-4">
        <div className="max-w-md mx-auto px-4">
          {/* Search Bar */}
          <div className="glass-card p-3 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-label" />
              <input
                type="text"
                placeholder="Поиск проектов..."
                className="w-full pl-9 pr-3 py-2.5 bg-white/50 border border-white/20 rounded-lg focus:outline-none focus:border-system-blue/50 transition-colors text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Glass Category Table */}
          <div className="glass-card p-4 mb-6">
            <div className="text-center mb-4">
              <h3 className="text-lg font-bold wow-gradient-text mb-1">Категории бизнеса</h3>
              <p className="text-xs text-secondary-label">Выберите подходящую сферу для вашего проекта</p>
            </div>
            
            <div className="space-y-3">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`w-full px-4 py-3 rounded-2xl text-sm font-semibold transition-all duration-200 flex items-center justify-between ${
                  selectedCategory === 'all'
                    ? 'bg-system-blue text-white shadow-lg'
                    : 'bg-white/60 text-label hover:bg-white/80'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">Все проекты</div>
                    <div className="text-xs opacity-80">Полный каталог готовых решений</div>
                  </div>
                </div>
                <div className="text-sm font-bold bg-white/20 px-2 py-1 rounded-full">
                  {demoApps.length}
                </div>
              </button>
              
              <div className="grid grid-cols-1 gap-2">
                {categories.map((category) => {
                  const IconComponent = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`px-3 py-3 rounded-2xl text-sm font-medium transition-all duration-200 flex items-center justify-between backdrop-blur-sm ${
                        selectedCategory === category.id
                          ? `bg-gradient-to-r ${category.color} text-white shadow-xl scale-105 border border-white/20`
                          : 'bg-white/60 text-label hover:bg-white/80 hover:scale-102 border border-white/10'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${category.color} flex items-center justify-center shadow-sm`}>
                          <IconComponent className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-left">
                          <div className="font-semibold truncate">{category.name}</div>
                          <div className="text-xs opacity-80">
                            {category.name === 'Электронная коммерция' && 'Интернет-магазины, маркетплейсы'}
                            {category.name === 'Еда и Напитки' && 'Рестораны, доставка, кафе'}
                            {category.name === 'Здоровье и Фитнес' && 'Спортзалы, фитнес, тренировки'}
                            {category.name === 'Красота и Здоровье' && 'Салоны красоты, СПА, массаж'}
                            {category.name === 'Образование' && 'Курсы, школы, обучение'}
                            {category.name === 'Подарки и Цветы' && 'Цветочные магазины, подарки'}
                            {category.name === 'Автоуслуги' && 'Автомойки, сервисы, парковки'}
                            {category.name === 'Здравоохранение' && 'Аптеки, медицина, диагностика'}
                            {category.name === 'Недвижимость' && 'Продажа, аренда, риэлторы'}
                            {category.name === 'Транспорт' && 'Такси, грузоперевозки, логистика'}
                            {category.name === 'Финансы' && 'Банки, кредиты, инвестиции'}
                            {category.name === 'Туризм' && 'Отели, туры, бронирование'}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm font-bold bg-white/20 px-2 py-1 rounded-full">
                        {category.apps.length}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Categories Table - Mobile Style */}
      <main className="relative z-10 pb-16">
        <div className="max-w-md mx-auto px-4">
          {selectedCategory === 'all' ? (
            // Table view for all categories
            <div className="space-y-6">
              {filteredCategories.length > 0 ? filteredCategories.map((category, index) => {
                const IconComponent = category.icon;
                
                return (
                  <div 
                    key={category.id}
                    className="glass-card-strong p-4 animate-in slide-in-from-bottom duration-500"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    {/* Category Header */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${category.color} flex items-center justify-center shadow-lg`}>
                          <IconComponent className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold">{category.name}</h3>
                          <p className="text-xs text-secondary-label">{category.apps.length} приложений</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setSelectedCategory(category.id)}
                        className="text-system-blue font-medium flex items-center space-x-1 hover:text-system-blue/80 transition-colors text-sm"
                      >
                        <span>Все</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Apps Table */}
                    <div className="space-y-2">
                      {category.apps.slice(0, 3).map((app) => (
                        <div
                          key={app.id}
                          className="flex items-center justify-between p-3 bg-white/50 rounded-lg hover:bg-white/70 transition-all duration-200 cursor-pointer group"
                          onClick={() => onOpenDemo(app.id)}
                        >
                          <div className="flex items-center space-x-3">
                            <img
                              src={app.image}
                              alt={app.title}
                              className="w-10 h-10 rounded-lg object-cover shadow-sm"
                              onError={(e) => {
                                e.currentTarget.src = `https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400`;
                              }}
                            />
                            <div className="min-w-0 flex-1">
                              <h4 className="font-medium text-sm group-hover:text-system-blue transition-colors truncate">
                                {app.title}
                              </h4>
                              <p className="text-xs text-secondary-label truncate">{app.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 flex-shrink-0">
                            <div className="flex items-center space-x-1 text-xs text-secondary-label">
                              <Star className="w-3 h-3 text-system-yellow fill-current" />
                              <span>4.8</span>
                            </div>
                            <ArrowRight className="w-4 h-4 text-tertiary-label group-hover:text-system-blue transition-colors" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }) : (
                // Empty search state
                <div className="glass-card-strong p-12 text-center">
                  <Search className="w-16 h-16 text-secondary-label mx-auto mb-4 opacity-50" />
                  <h3 className="text-xl font-bold mb-2">Ничего не найдено</h3>
                  <p className="text-secondary-label mb-4">
                    Попробуйте изменить поисковый запрос или выбрать другую категорию
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                    }}
                    className="ios-button-tinted px-6 py-2"
                  >
                    Сбросить фильтры
                  </button>
                </div>
              )}
            </div>
          ) : (
            // Detailed view for selected category
            <div className="space-y-4">
              {/* Selected Category Header */}
              {(() => {
                const category = categories.find(cat => cat.id === selectedCategory);
                if (!category) return null;
                const IconComponent = category.icon;
                
                return (
                  <div className="glass-card-strong p-4 text-center mb-6">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${category.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h2 className="text-xl font-bold mb-2">{category.name}</h2>
                    <p className="text-secondary-label text-sm">
                      {category.apps.length} готовых решений для вашего бизнеса
                    </p>
                  </div>
                );
              })()}

              {/* Apps List */}
              <div className="space-y-3">
                {filteredApps.map((app, index) => (
                  <div
                    key={app.id}
                    className="glass-card p-4 cursor-pointer hover:scale-105 transition-all duration-300 group animate-in slide-in-from-bottom"
                    style={{ animationDelay: `${index * 50}ms` }}
                    onClick={() => onOpenDemo(app.id)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="relative overflow-hidden rounded-lg">
                        <img
                          src={app.image}
                          alt={app.title}
                          className="w-16 h-16 object-cover group-hover:scale-110 transition-transform duration-500"
                          onError={(e) => {
                            e.currentTarget.src = `https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400`;
                          }}
                        />
                        <div className="absolute top-1 right-1 bg-white/90 backdrop-blur-sm rounded-full px-1.5 py-0.5">
                          <div className="flex items-center space-x-1 text-xs">
                            <Star className="w-2.5 h-2.5 text-system-yellow fill-current" />
                            <span className="font-medium text-xs">4.8</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-sm mb-1 group-hover:text-system-blue transition-colors truncate">
                          {app.title}
                        </h3>
                        <p className="text-xs text-secondary-label mb-2 line-clamp-2">
                          {app.description}
                        </p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 text-xs text-secondary-label">
                            <span className="flex items-center space-x-1">
                              <Eye className="w-3 h-3" />
                              <span>1.2к</span>
                            </span>
                            <span className="flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>5-7д</span>
                            </span>
                          </div>
                          <ArrowRight className="w-4 h-4 text-tertiary-label group-hover:text-system-blue transition-colors" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {filteredApps.length === 0 && (
                  <div className="glass-card-strong p-8 text-center">
                    <Search className="w-12 h-12 text-secondary-label mx-auto mb-3 opacity-50" />
                    <h3 className="text-lg font-bold mb-2">Ничего не найдено</h3>
                    <p className="text-secondary-label text-sm mb-4">
                      Попробуйте изменить поисковый запрос
                    </p>
                    <button
                      onClick={() => setSearchQuery('')}
                      className="ios-button-tinted px-4 py-2 text-sm"
                    >
                      Очистить поиск
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Bottom CTA Section - Mobile Style */}
      <section className="relative z-10 py-8">
        <div className="max-w-md mx-auto px-4">
          <div className="glass-card-strong p-6 text-center">
            <Sparkles className="w-10 h-10 text-system-blue mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-3">
              Не нашли подходящий проект?
            </h3>
            <p className="text-secondary-label mb-6 text-sm">
              Создадим уникальное решение специально для вашего бизнеса
            </p>
            <div className="space-y-3">
              <button
                onClick={() => onNavigate('constructor')}
                className="ios-button-filled w-full px-6 py-3 flex items-center justify-center space-x-2"
              >
                <Zap className="w-4 h-4" />
                <span>Заказать разработку</span>
              </button>
              <button
                onClick={() => onNavigate('pricing')}
                className="ios-button-tinted w-full px-6 py-3 flex items-center justify-center space-x-2"
              >
                <TrendingUp className="w-4 h-4" />
                <span>Узнать цену</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}