import { useState, useEffect } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { ArrowLeft, CreditCard, Lock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useTelegram } from "@/hooks/useTelegram";

const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : null;

interface CheckoutPageProps {
  selectedFeatures: any[];
  projectName: string;
  totalAmount: number;
  onBack: () => void;
  onSuccess: () => void;
}

const CheckoutForm = ({ totalAmount, projectName, selectedFeatures, onSuccess }: { 
  totalAmount: number; 
  projectName: string; 
  selectedFeatures: any[];
  onSuccess: () => void 
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { user } = useTelegram();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/success`,
        },
        redirect: 'if_required'
      });

      if (error) {
        toast({
          title: "Ошибка оплаты",
          description: error.message,
          variant: "destructive",
        });
      } else {
        // Create project after successful payment
        try {
          const createProjectResponse = await fetch('/api/create-project', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              telegramId: user?.id?.toString(),
              projectName: projectName,
              projectType: 'custom',
              features: selectedFeatures.map(f => f.id),
              paymentIntentId: 'stripe_payment_' + Date.now()
            })
          });
          
          if (createProjectResponse.ok) {
            console.log('Project created successfully');
            toast({
              title: "Оплата успешна!",
              description: "Проект создан! Мы начнем разработку в течение 24 часов.",
            });
          } else {
            throw new Error('Failed to create project');
          }
        } catch (error) {
          console.error('Error creating project:', error);
          toast({
            title: "Оплата успешна!",
            description: "Спасибо за заказ! Мы свяжемся с вами в течение 24 часов.",
          });
        }
        
        onSuccess();
      }
    } catch (err) {
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при обработке платежа",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="glass p-6 rounded-3xl">
        <div className="flex items-center space-x-2 mb-4">
          <Lock className="w-4 h-4 text-green-500" />
          <span className="text-sm text-green-500 font-medium">Безопасная оплата</span>
        </div>
        <PaymentElement />
      </div>
      
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full bg-accent hover:bg-accent/90 text-white font-bold h-12"
        data-testid="button-pay"
      >
        <CreditCard className="w-4 h-4 mr-2" />
        {isProcessing ? "Обработка..." : `Оплатить ${totalAmount.toLocaleString()} ₽`}
      </Button>
    </form>
  );
};

export default function CheckoutPage({ selectedFeatures, projectName, totalAmount, onBack, onSuccess }: CheckoutPageProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Create PaymentIntent when component mounts
    if (totalAmount > 0) {
      fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: totalAmount,
          project_name: projectName,
          features: selectedFeatures.map(f => f.id)
        }),
      })
      .then(res => res.json())
      .then(data => {
        if (data.clientSecret) {
          setClientSecret(data.clientSecret);
        } else {
          toast({
            title: "Ошибка",
            description: "Не удалось инициализировать платеж",
            variant: "destructive",
          });
        }
        setIsLoading(false);
      })
      .catch(() => {
        toast({
          title: "Ошибка",
          description: "Проблема с подключением к серверу",
          variant: "destructive",
        });
        setIsLoading(false);
      });
    }
  }, [totalAmount, projectName, selectedFeatures, toast]);

  if (!stripePromise) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <Card className="glass max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-red-500/20 rounded-full flex items-center justify-center">
              <CreditCard className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-xl font-bold mb-2">Платежи недоступны</h2>
            <p className="text-muted-foreground">
              Платежная система временно недоступна. Пожалуйста, попробуйте позже или свяжитесь с нами напрямую.
            </p>
            <Button className="w-full mt-4" onClick={onBack} data-testid="button-back-error">
              Вернуться назад
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <Card className="glass max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-accent border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-muted-foreground">Подготовка к оплате...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const appearance = {
    theme: 'night' as const,
    variables: {
      colorPrimary: '#6366f1',
      colorBackground: 'rgba(15, 15, 15, 0.8)',
      colorText: '#ffffff',
      borderRadius: '12px',
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="glass-strong"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Оплата заказа</h1>
        </div>

        {/* Order Summary */}
        <Card className="glass mb-6" data-testid="order-summary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>Ваш заказ</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-bold">{projectName}</h3>
              <p className="text-sm text-muted-foreground">
                {selectedFeatures.length} {selectedFeatures.length === 1 ? 'функция' : 'функций'}
              </p>
            </div>
            
            <div className="space-y-2">
              {selectedFeatures.map((feature) => (
                <div key={feature.id} className="flex justify-between text-sm">
                  <span>{feature.name}</span>
                  <span className="text-accent">{feature.price.toLocaleString()} ₽</span>
                </div>
              ))}
            </div>
            
            <div className="border-t border-white/10 pt-2">
              <div className="flex justify-between font-bold">
                <span>Итого:</span>
                <span className="text-accent">{totalAmount.toLocaleString()} ₽</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Срок разработки: 3-7 рабочих дней
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Payment Form */}
        {clientSecret && (
          <Elements 
            stripe={stripePromise} 
            options={{ 
              clientSecret,
              appearance 
            }}
          >
            <CheckoutForm 
              totalAmount={totalAmount}
              projectName={projectName}
              selectedFeatures={selectedFeatures}
              onSuccess={onSuccess}
            />
          </Elements>
        )}
      </div>
    </div>
  );
}