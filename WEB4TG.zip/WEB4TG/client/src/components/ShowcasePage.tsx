import { useState, useEffect, useRef } from "react";
import { demoApps } from "@/data/demoApps";
import { 
  Star,
  ArrowRight,
  Zap,
  TrendingUp,
  Users,
  CheckCircle,
  Smartphone,
  Sparkles,
  Trophy,
  Heart,
  Award,
  Rocket,
  Target,
  DollarSign,
  Home,
  Calculator,
  Wrench,
  User,
  ShoppingCart,
  Coffee,
  Dumbbell,
  GraduationCap,
  CreditCard,
  UserCircle2,
  Zap as Lightning,
  Crown,
  Plus
} from "lucide-react";
import StickyGlassHeader from "./ui/StickyGlassHeader";

interface ShowcasePageProps {
  onNavigate: (section: string) => void;
  onOpenDemo: (demoId: string) => void;
}

// Custom hook for count-up animation with reduced-motion support
const useCountUp = (endValue: number, duration: number = 2000) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
          
          if (prefersReducedMotion) {
            // Set value instantly for users who prefer reduced motion
            setCount(endValue);
            return;
          }
          
          let startTime: number;
          const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = Math.min((currentTime - startTime) / duration, 1);
            const easeOutQuart = 1 - Math.pow(1 - progress, 4);
            setCount(Math.floor(easeOutQuart * endValue));
            
            if (progress < 1) {
              requestAnimationFrame(animate);
            }
          };
          
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [endValue, duration, isVisible]);

  return { count, ref, isVisible };
};

export default function ShowcasePage({ onNavigate, onOpenDemo }: ShowcasePageProps) {
  // Removed gallery state as we now use a simple grid layout
  const allApps = demoApps;

  // Count-up hooks for stats
  const projectsCount = useCountUp(150);
  const clientsCount = useCountUp(89);
  const successCount = useCountUp(98);

  // Removed gallery scroll synchronization as we now use a simple grid layout

  return (
    <div className="min-h-screen bg-white text-label safe-area-top pb-32 relative">
      {/* Animated Background Effects */}
      <div className="wow-bg-animated"></div>
      <div className="wow-bg-mesh"></div>
      
      {/* Morphing Blobs */}
      <div className="wow-blob wow-blob-1"></div>
      <div className="wow-blob wow-blob-2"></div>
      <div className="wow-blob wow-blob-3"></div>

      <StickyGlassHeader />

      {/* Revolutionary Hero Section */}
      <div className="wow-hero-container pt-8">
        <div className="max-w-md mx-auto px-4 text-center relative z-10">

          {/* Hero Brand Mark */}
          <div className="wow-shimmer mb-8 mt-4">
            <div className="wow-gradient-text text-5xl font-black mb-4 leading-tight">
              Получайте<br />заказы 24/7
            </div>
          </div>
          
          <div className="wow-shimmer mb-6">
            <h2 className="text-2xl font-bold mb-4 text-label leading-relaxed">
              Автоматизируйте продажи с<br />
              <span className="text-system-blue font-black">Telegram Mini Apps</span>
            </h2>
          </div>
          
          <p className="text-lg text-secondary-label mb-10 leading-relaxed font-medium">
            Ваши клиенты покупают, не выходя из Telegram.<br />
            <span className="text-system-green font-bold">Увеличьте продажи в 3 раза за первый месяц!</span>
          </p>

          {/* CTA Buttons with Effects */}
          <div className="space-y-4 mb-12">
            <button 
              className="ios-button-filled w-full wow-shimmer relative overflow-hidden group"
              onClick={() => onNavigate('constructor')}
              data-testid="button-start-project"
            >
              <div className="flex items-center justify-center space-x-3">
                <Zap className="w-5 h-5" />
                <span className="font-bold">Заказать приложение</span>
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </button>
            
            <div className="flex space-x-3">
              <button 
                className="ios-button-tinted flex-1"
                onClick={() => onNavigate('pricing')}
              >
                <span className="flex items-center justify-center space-x-2">
                  <TrendingUp className="w-4 h-4" />
                  <span>Тарифы</span>
                </span>
              </button>
              <button 
                className="ios-button-tinted flex-1"
                onClick={() => onOpenDemo('clothing-store')}
              >
                <span className="flex items-center justify-center space-x-2">
                  <ArrowRight className="w-4 h-4" />
                  <span>Демо</span>
                </span>
              </button>
            </div>
          </div>

          {/* iOS 17 Minimalist Results Block */}
          <div className="mb-8">
            <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-6 border border-gray-200/50 shadow-sm">
              <div className="text-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Результаты наших клиентов</h3>
                <p className="text-sm text-gray-500">Средний результат за первый месяц</p>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-green-50 rounded-2xl p-4">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-green-600 mb-1">+300%</div>
                  <div className="text-xs text-gray-600 font-medium">Продажи</div>
                </div>
                
                <div className="bg-blue-50 rounded-2xl p-4">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Target className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-blue-600 mb-1">95%</div>
                  <div className="text-xs text-gray-600 font-medium">Конверсия</div>
                </div>
                
                <div className="bg-purple-50 rounded-2xl p-4">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <DollarSign className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-purple-600 mb-1">24/7</div>
                  <div className="text-xs text-gray-600 font-medium">Автопилот</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Revolutionary Stats Section */}
      <section className="max-w-md mx-auto px-4 mb-12">
        <div className="glass-card p-6">
          <h3 className="ios-title3 text-center mb-6 font-bold">Достижения в цифрах</h3>
          
          <div className="grid grid-cols-3 gap-4">
            <div 
              ref={projectsCount.ref}
              className={`wow-stat text-center ${projectsCount.isVisible ? 'visible' : ''}`}
            >
              <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Smartphone className="w-6 h-6 text-system-blue" />
              </div>
              <div className="wow-count ios-title2 font-black text-system-blue">
                {projectsCount.count}+
              </div>
              <div className="ios-caption1 text-secondary-label">Проектов</div>
              <div className="mt-1">
                <span className="inline-flex items-center space-x-1 bg-system-blue/10 px-2 py-1 rounded-full">
                  <Trophy className="w-3 h-3 text-system-blue" />
                  <span className="ios-caption2 text-system-blue font-semibold">Top-rated</span>
                </span>
              </div>
            </div>
            
            <div 
              ref={clientsCount.ref}
              className={`wow-stat text-center ${clientsCount.isVisible ? 'visible' : ''}`}
              style={{ animationDelay: '0.2s' }}
            >
              <div className="w-12 h-12 bg-system-green/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-system-green" />
              </div>
              <div className="wow-count ios-title2 font-black text-system-green">
                {clientsCount.count}
              </div>
              <div className="ios-caption1 text-secondary-label">Клиентов</div>
              <div className="mt-1">
                <span className="inline-flex items-center space-x-1 bg-system-green/10 px-2 py-1 rounded-full">
                  <CheckCircle className="w-3 h-3 text-system-green" />
                  <span className="ios-caption2 text-system-green font-semibold">24/7</span>
                </span>
              </div>
            </div>
            
            <div 
              ref={successCount.ref}
              className={`wow-stat text-center ${successCount.isVisible ? 'visible' : ''}`}
              style={{ animationDelay: '0.4s' }}
            >
              <div className="w-12 h-12 bg-system-orange/10 rounded-full flex items-center justify-center mx-auto mb-2">
                <Award className="w-6 h-6 text-system-orange" />
              </div>
              <div className="wow-count ios-title2 font-black text-system-orange">
                {successCount.count}%
              </div>
              <div className="ios-caption1 text-secondary-label">Успех</div>
              <div className="mt-1">
                <span className="inline-flex items-center space-x-1 bg-system-orange/10 px-2 py-1 rounded-full">
                  <Star className="w-3 h-3 text-system-orange fill-current" />
                  <span className="ios-caption2 text-system-orange font-semibold">NPS 95</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Modern Project Grid */}
      <section className="mb-12">
        <div className="max-w-md mx-auto px-4 mb-6">
          <div className="text-center">
            <h3 className="ios-title2 font-bold mb-2 flex items-center justify-center space-x-2">
              <Sparkles className="w-6 h-6 text-system-blue" />
              <span>Наши проекты</span>
            </h3>
            <p className="ios-footnote text-secondary-label mb-4">
              Изучите реальные работы и вдохновитесь
            </p>
          </div>
        </div>

        <div className="max-w-md mx-auto px-4">
          <div className="grid grid-cols-1 gap-4">
            {allApps.slice(0, 4).map((app, index) => (
              <button
                key={app.id}
                className="group relative overflow-hidden rounded-2xl bg-white border border-separator hover:border-system-blue/30 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-system-blue/20 shadow-sm hover:shadow-lg"
                onClick={() => { window.location.hash = `/demos/${app.id}/app`; }}
                data-testid={`card-demo-${app.id}`}
                aria-label={`Open ${app.title} demo - ${app.description}`}
              >
                <div className="flex items-center p-4 space-x-4">
                  {/* Project Image */}
                  <div className="relative flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-gradient-to-br from-system-blue/10 to-system-purple/10">
                      <img 
                        src={app.image} 
                        alt={app.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        loading="lazy"
                      />
                    </div>
                    {app.badge && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-system-blue rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-bold">!</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Project Info */}
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="ios-body font-semibold text-label truncate" data-testid={`text-demo-title-${app.id}`}>
                        {app.title}
                      </h4>
                      <div className="flex items-center space-x-1 ml-2">
                        <Star className="w-3 h-3 text-system-yellow fill-current" />
                        <span className="ios-caption2 font-medium text-label">4.9</span>
                      </div>
                    </div>
                    
                    <p className="ios-caption1 text-system-blue font-medium mb-2">
                      {app.category}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-1">
                          <Heart className="w-3 h-3 text-system-red fill-current" />
                          <span className="ios-caption2 font-medium text-secondary-label" data-testid={`text-likes-${app.id}`}>
                            {app.likes}
                          </span>
                        </div>
                        <span className="ios-caption2 text-secondary-label">•</span>
                        <span className="ios-caption2 text-secondary-label">Демо доступно</span>
                      </div>
                      
                      <div className="flex items-center text-system-blue group-hover:translate-x-1 transition-transform">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Hover Effect Gradient */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-system-blue/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              </button>
            ))}
          </div>
        </div>

        {/* View All Projects Button */}
        <div className="max-w-md mx-auto px-4 mt-6 text-center">
          <button 
            className="ios-button-tinted px-6 py-3"
            onClick={() => window.location.hash = '/projects'}
          >
            <span className="flex items-center space-x-2">
              <span>Все проекты</span>
              <ArrowRight className="w-4 h-4" />
            </span>
          </button>
        </div>
      </section>

      {/* Testimonials Marquee */}
      <section className="mb-12">
        <div className="glass-card mx-4 p-4 overflow-hidden">
          <div className="wow-marquee">
            <div className="wow-marquee-inner flex items-center space-x-8">
              {[
                "«Потрясающее качество!» - Дмитрий К.",
                "«Быстро и профессионально» - Анна С.", 
                "«Превзошли ожидания» - Михаил Л.",
                "«Рекомендую всем!» - Елена П.",
                "«Отличная поддержка» - Сергей В."
              ].map((testimonial, index) => (
                <span key={index} className="ios-footnote text-secondary-label whitespace-nowrap">
                  <Star className="w-3 h-3 text-system-yellow fill-current inline mr-2" />
                  {testimonial}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="max-w-md mx-auto px-4">
        <div className="glass-card p-6 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-system-blue/20 to-transparent rounded-bl-3xl"></div>
          
          <h3 className="ios-title3 font-bold mb-3">
            Готовы создать что-то удивительное?
          </h3>
          <p className="ios-footnote text-secondary-label mb-6">
            Присоединяйтесь к сотням довольных клиентов уже сегодня
          </p>
          
          <button 
            className="ios-button-filled w-full wow-shimmer relative overflow-hidden"
            onClick={() => onNavigate('constructor')}
          >
            <span className="flex items-center justify-center space-x-2">
              <Sparkles className="w-5 h-5" />
              <span className="font-bold">Начать проект</span>
            </span>
          </button>
        </div>
      </section>

    </div>
  );
}