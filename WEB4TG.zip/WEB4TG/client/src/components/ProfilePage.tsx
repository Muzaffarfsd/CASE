import { useState, useEffect } from "react";
import { 
  User, 
  Settings, 
  MessageCircle, 
  FileText, 
  CreditCard, 
  LogOut, 
  Home, 
  Calculator, 
  Wrench, 
  Edit, 
  Crown, 
  Star, 
  Smartphone, 
  CheckCircle,
  ChevronRight,
  Phone,
  Mail,
  Building,
  Bell,
  Shield,
  HelpCircle,
  ExternalLink,
  Package,
  Clock,
  TrendingUp,
  Send,
  Instagram,
  Music,
  Sparkles,
  Rocket,
  UserCircle2,
  Plus
} from "lucide-react";
import { useTelegram } from "../hooks/useTelegram";
import StickyGlassHeader from "./ui/StickyGlassHeader";

interface ProfilePageProps {
  onNavigate: (section: string) => void;
}

export default function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, webApp, isAvailable } = useTelegram();

  // Полностью автоматическая информация из Telegram
  const profileData = {
    name: user ? `${user.first_name}${user.last_name ? ` ${user.last_name}` : ''}` : 'Пользователь',
    username: user?.username ? `@${user.username}` : null,
    telegramId: user?.id || null,
    language: user?.language_code || 'ru',
    joinedAt: user ? 'Активен в Telegram' : 'Не подключен'
  };

  // Получение реальных проектов пользователя
  const [userProjects, setUserProjects] = useState<any[]>([]);
  const [isLoadingProjects, setIsLoadingProjects] = useState(true);

  useEffect(() => {
    const fetchUserProjects = async () => {
      if (!profileData.telegramId) {
        setIsLoadingProjects(false);
        return;
      }

      try {
        const response = await fetch(`/api/user-projects/${profileData.telegramId}`);
        if (response.ok) {
          const projects = await response.json();
          setUserProjects(projects);
        } else {
          setUserProjects([]);
        }
      } catch (error) {
        console.log('Проекты не найдены, пользователь новый');
        setUserProjects([]);
      } finally {
        setIsLoadingProjects(false);
      }
    };

    fetchUserProjects();
  }, [profileData.telegramId]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Готово':
        return <CheckCircle className="w-4 h-4 text-system-green" />;
      case 'В разработке':
        return <Clock className="w-4 h-4 text-system-orange" />;
      case 'Планирование':
        return <Package className="w-4 h-4 text-system-blue" />;
      default:
        return <Clock className="w-4 h-4 text-secondary-label" />;
    }
  };

  return (
    <div className="min-h-screen bg-white text-label safe-area-top pb-32 relative">
      {/* Animated Background Effects */}
      <div className="wow-bg-animated"></div>
      <div className="wow-bg-mesh"></div>
      
      {/* Morphing Blobs */}
      <div className="wow-blob wow-blob-1"></div>
      <div className="wow-blob wow-blob-2"></div>
      <div className="wow-blob wow-blob-3"></div>

      <StickyGlassHeader />

      <div className="max-w-md mx-auto px-4 space-y-6">
        {/* User Profile Section */}
        <section className="ios-slide-up">
          <div className="ios-card p-6 text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-system-blue/10 rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-system-blue" />
            </div>
            
            <h2 className="ios-title2 mb-2" data-testid="text-user-name">{profileData.name}</h2>
            
            {profileData.username && (
              <div className="ios-footnote text-system-blue mb-3">
                {profileData.username}
              </div>
            )}
            
            <div className="flex items-center justify-center space-x-2 mb-4">
              {isAvailable ? (
                <>
                  <CheckCircle className="w-4 h-4 text-system-green" />
                  <span className="ios-footnote text-system-green">Подключен к Telegram</span>
                </>
              ) : (
                <>
                  <Smartphone className="w-4 h-4 text-system-blue" />
                  <span className="ios-footnote text-system-blue">WEB4TG Client</span>
                </>
              )}
            </div>

            {profileData.telegramId && (
              <div className="glass-card p-3 bg-system-blue/5 border-system-blue/20">
                <div className="ios-caption1 text-secondary-label mb-1">ID пользователя</div>
                <div className="ios-footnote font-mono text-system-blue">#{profileData.telegramId}</div>
              </div>
            )}
          </div>
        </section>

        {/* User Statistics */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-header">Статистика активности</div>
            
            {isLoadingProjects ? (
              <div className="glass-card p-6 text-center">
                <div className="w-8 h-8 border-2 border-system-blue/30 border-t-system-blue rounded-full animate-spin mx-auto mb-3"></div>
                <div className="ios-footnote text-secondary-label">Загружаем ваши проекты...</div>
              </div>
            ) : userProjects.length > 0 ? (
              <div className="glass-card p-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Package className="w-6 h-6 text-system-blue" />
                    </div>
                    <div className="ios-title3 font-bold text-system-blue">{userProjects.length}</div>
                    <div className="ios-caption2 text-secondary-label">Проектов</div>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-system-green/10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <CheckCircle className="w-6 h-6 text-system-green" />
                    </div>
                    <div className="ios-title3 font-bold text-system-green">
                      {userProjects.filter(p => p.status === 'Готово' || p.status === 'Завершен' || p.progress === 100).length}
                    </div>
                    <div className="ios-caption2 text-secondary-label">Завершено</div>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-system-orange/10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Clock className="w-6 h-6 text-system-orange" />
                    </div>
                    <div className="ios-title3 font-bold text-system-orange">
                      {userProjects.filter(p => p.status !== 'Готово' && p.status !== 'Завершен' && p.progress !== 100).length}
                    </div>
                    <div className="ios-caption2 text-secondary-label">В работе</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="glass-card p-6 text-center">
                <div className="w-16 h-16 bg-system-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Package className="w-8 h-8 text-system-blue" />
                </div>
                <h3 className="ios-body font-semibold mb-2">Пора создать первое приложение!</h3>
                <p className="ios-footnote text-secondary-label mb-4 leading-relaxed">
                  У вас пока нет проектов. Создайте свое первое Telegram приложение и начните зарабатывать уже сегодня!
                </p>
                <button 
                  className="ios-button-filled w-full mb-3"
                  onClick={() => onNavigate('constructor')}
                >
                  Создать приложение
                </button>
                <button 
                  className="ios-button-text w-full"
                  onClick={() => onNavigate('pricing')}
                >
                  Посмотреть тарифы
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Telegram Integration */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-header">Интеграция с Telegram</div>
            
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-blue/10 rounded-medium flex items-center justify-center">
                  <Send className="w-4 h-4 text-system-blue" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Язык интерфейса</div>
                  <div className="ios-footnote text-secondary-label">
                    {profileData.language === 'ru' ? 'Русский' : 
                     profileData.language === 'en' ? 'English' : 
                     profileData.language?.toUpperCase() || 'Русский'}
                  </div>
                </div>
              </div>
            </div>

            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-green/10 rounded-medium flex items-center justify-center">
                  <Smartphone className="w-4 h-4 text-system-green" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Статус подключения</div>
                  <div className="ios-footnote text-secondary-label">
                    {profileData.joinedAt}
                  </div>
                </div>
                {isAvailable && <CheckCircle className="w-4 h-4 text-system-green" />}
              </div>
            </div>
          </div>
        </section>

        {/* My Projects */}
        {!isLoadingProjects && userProjects.length > 0 && (
          <section className="ios-slide-up">
            <div className="ios-list">
              <div className="ios-list-header">Мои проекты</div>
              
              {userProjects.map((project) => (
                <div key={project.id} className="ios-list-item" data-testid={`project-${project.id}`}>
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(project.status)}
                    <div className="flex-1">
                      <div className="ios-body font-semibold">{project.name}</div>
                      <div className="flex items-center space-x-2">
                        <span className={`ios-caption2 font-semibold ${
                          project.status === 'Готово' || project.status === 'Завершен' ? 'text-system-green' :
                          project.status === 'В разработке' || project.status === 'Разработка' ? 'text-system-orange' :
                          project.status === 'Планирование' || project.status === 'Оплачено' ? 'text-system-blue' :
                          'text-secondary-label'
                        }`}>
                          {project.status}
                        </span>
                        <span className="ios-caption2 text-tertiary-label">•</span>
                        <span className="ios-caption2 text-tertiary-label">
                          {project.progress || 0}%
                        </span>
                      </div>
                      <div className="w-full bg-quaternary-system-fill rounded-full h-1.5 mt-2">
                        <div 
                          className={`h-1.5 rounded-full transition-all duration-300 ${
                            project.status === 'Готово' || project.status === 'Завершен' ? 'bg-system-green' : 
                            project.status === 'В разработке' || project.status === 'Разработка' ? 'bg-system-orange' : 
                            'bg-system-blue'
                          }`}
                          style={{ width: `${project.progress || 0}%` }}
                        />
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-tertiary-label" />
                  </div>
                </div>
              ))}
              
              <div className="ios-list-item cursor-pointer" onClick={() => onNavigate('constructor')}>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-system-blue/10 rounded-medium flex items-center justify-center">
                    <Wrench className="w-4 h-4 text-system-blue" />
                  </div>
                  <div className="flex-1">
                    <div className="ios-body font-semibold text-system-blue">Создать новый проект</div>
                    <div className="ios-footnote text-secondary-label">
                      Запустите еще одно приложение
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-tertiary-label" />
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Smart Features */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-header">Умные функции</div>
            
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-green/10 rounded-medium flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-system-green" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Автосохранение</div>
                  <div className="ios-footnote text-secondary-label">
                    Проекты сохраняются каждые 30 секунд
                  </div>
                </div>
                <div className="ios-switch ios-switch-active">
                  <div className="ios-switch-thumb"></div>
                </div>
              </div>
            </div>
            
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-blue/10 rounded-medium flex items-center justify-center">
                  <Shield className="w-4 h-4 text-system-blue" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Резервные копии</div>
                  <div className="ios-footnote text-secondary-label">
                    Автоматическое резервирование в облако
                  </div>
                </div>
                <div className="ios-switch ios-switch-active">
                  <div className="ios-switch-thumb"></div>
                </div>
              </div>
            </div>
            
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-purple/10 rounded-medium flex items-center justify-center">
                  <Bell className="w-4 h-4 text-system-purple" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Уведомления о статусе</div>
                  <div className="ios-footnote text-secondary-label">
                    Получать обновления о ходе разработки
                  </div>
                </div>
                <div className="ios-switch ios-switch-active">
                  <div className="ios-switch-thumb"></div>
                </div>
              </div>
            </div>

            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-orange/10 rounded-medium flex items-center justify-center">
                  <Settings className="w-4 h-4 text-system-orange" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Тема оформления</div>
                  <div className="ios-footnote text-secondary-label">
                    Темная тема (автоматически)
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
          </div>
        </section>

        {/* Support */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-header">Поддержка</div>
            
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-blue/10 rounded-medium flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-system-blue" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Связаться с нами</div>
                  <div className="ios-footnote text-secondary-label">
                    Техподдержка 24/7
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            
            <div className="ios-list-item cursor-pointer" 
                 onClick={() => window.open('https://t.me/web4tgs', '_blank')}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-blue/10 rounded-medium flex items-center justify-center">
                  <Send className="w-4 h-4 text-system-blue" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Telegram</div>
                  <div className="ios-footnote text-secondary-label">
                    @web4tgs
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-tertiary-label" />
              </div>
            </div>
            
            <div className="ios-list-item cursor-pointer" 
                 onClick={() => window.open('https://instagram.com/web4tg', '_blank')}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-medium flex items-center justify-center">
                  <Instagram className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Instagram</div>
                  <div className="ios-footnote text-secondary-label">
                    @web4tg
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-tertiary-label" />
              </div>
            </div>
            
            <div className="ios-list-item cursor-pointer" 
                 onClick={() => window.open('https://tiktok.com/@web4tg', '_blank')}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-black rounded-medium flex items-center justify-center">
                  <Music className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">TikTok</div>
                  <div className="ios-footnote text-secondary-label">
                    @web4tg
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-tertiary-label" />
              </div>
            </div>
            
            <div className="ios-list-item cursor-pointer" onClick={() => onNavigate('help')}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-green/10 rounded-medium flex items-center justify-center">
                  <HelpCircle className="w-4 h-4 text-system-green" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Справка</div>
                  <div className="ios-footnote text-secondary-label">
                    FAQ и инструкции
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
            
            <div className="ios-list-item cursor-pointer" onClick={() => onNavigate('review')}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-orange/10 rounded-medium flex items-center justify-center">
                  <Star className="w-4 h-4 text-system-orange" />
                </div>
                <div className="flex-1">
                  <div className="ios-body">Оставить отзыв</div>
                  <div className="ios-footnote text-secondary-label">
                    Оцените наш сервис
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-tertiary-label" />
              </div>
            </div>
          </div>
        </section>

        {/* Account Actions */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-item cursor-pointer">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-system-red/10 rounded-medium flex items-center justify-center">
                  <LogOut className="w-4 h-4 text-system-red" />
                </div>
                <div className="flex-1">
                  <div className="ios-body text-system-red font-semibold">Выйти</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* App Info */}
        <section className="ios-slide-up">
          <div className="text-center space-y-2">
            <div className="ios-footnote text-tertiary-label">
              WEB4TG Platform
            </div>
            <div className="ios-footnote text-tertiary-label">
              Версия 1.0.0
            </div>
          </div>
        </section>
      </div>

    </div>
  );
}