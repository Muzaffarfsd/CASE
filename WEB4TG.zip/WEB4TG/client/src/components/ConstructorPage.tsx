import { useState } from "react";
import { 
  Wrench,
  Eye,
  ShoppingCart,
  Home,
  Calculator,
  User,
  ArrowRight,
  Check,
  Package,
  Coffee,
  Dumbbell,
  GraduationCap,
  Heart,
  Settings,
  CreditCard,
  Truck,
  Bell,
  Crown,
  BarChart,
  Calendar,
  Users,
  Zap,
  Star,
  MessageSquare,
  Globe,
  Smartphone,
  Clock,
  Info,
  ChevronRight,
  Plus,
  Sparkles,
  Rocket,
  UserCircle2
} from "lucide-react";
import StickyGlassHeader from "./ui/StickyGlassHeader";

interface ConstructorPageProps {
  onNavigate: (section: string, data?: any) => void;
}

interface SelectedFeature {
  id: string;
  name: string;
  price: number;
  category: string;
}

const appTemplates = [
  {
    id: 'ecommerce-basic',
    name: 'Интернет-магазин',
    icon: ShoppingCart,
    description: 'Продажа товаров онлайн',
    features: ['catalog', 'cart', 'auth', 'payments'],
    estimatedPrice: 45000,
    developmentTime: '7-10 дней',
    popular: true
  },
  {
    id: 'restaurant',
    name: 'Ресторан',
    icon: Coffee,
    description: 'Меню и заказы еды',
    features: ['catalog', 'cart', 'auth', 'booking-system'],
    estimatedPrice: 55000,
    developmentTime: '10-12 дней',
    popular: false
  },
  {
    id: 'fitness-center',
    name: 'Фитнес-клуб',
    icon: Dumbbell,
    description: 'Тренировки и абонементы',
    features: ['booking-system', 'auth', 'subscriptions', 'progress-tracking'],
    estimatedPrice: 65000,
    developmentTime: '12-15 дней',
    popular: false
  },
  {
    id: 'services',
    name: 'Услуги',
    icon: Settings,
    description: 'Бронирование услуг',
    features: ['catalog', 'booking-system', 'auth', 'payments'],
    estimatedPrice: 50000,
    developmentTime: '8-12 дней',
    popular: false
  }
];

const availableFeatures = [
  // Основные
  { id: 'catalog', name: 'Каталог', price: 8000, category: 'Основные', icon: Package, included: true },
  { id: 'cart', name: 'Корзина', price: 6000, category: 'Основные', icon: ShoppingCart, included: true },
  { id: 'auth', name: 'Авторизация', price: 4000, category: 'Основные', icon: User, included: true },
  { id: 'search', name: 'Поиск', price: 7000, category: 'Основные', icon: Zap, included: false },
  { id: 'favorites', name: 'Избранное', price: 4000, category: 'Основные', icon: Star, included: false },
  { id: 'reviews', name: 'Отзывы', price: 8000, category: 'Основные', icon: Star, included: false },
  
  // Платежи
  { id: 'payments', name: 'Платежи', price: 15000, category: 'Платежи', icon: CreditCard, included: false },
  { id: 'subscriptions', name: 'Подписки', price: 18000, category: 'Платежи', icon: CreditCard, included: false },
  { id: 'installments', name: 'Рассрочка', price: 12000, category: 'Платежи', icon: CreditCard, included: false },
  
  // Доставка
  { id: 'delivery-basic', name: 'Доставка', price: 10000, category: 'Доставка', icon: Truck, included: false },
  { id: 'pickup-points', name: 'Самовывоз', price: 12000, category: 'Доставка', icon: Package, included: false },
  { id: 'express-delivery', name: 'Экспресс', price: 8000, category: 'Доставка', icon: Truck, included: false },
  
  // Коммуникации
  { id: 'push-notifications', name: 'Уведомления', price: 8000, category: 'Коммуникации', icon: Bell, included: false },
  { id: 'chat-support', name: 'Чат поддержки', price: 15000, category: 'Коммуникации', icon: MessageSquare, included: false },
  { id: 'video-calls', name: 'Видеозвонки', price: 20000, category: 'Коммуникации', icon: Smartphone, included: false },
  
  // Маркетинг
  { id: 'loyalty-program', name: 'Бонусы', price: 22000, category: 'Маркетинг', icon: Crown, included: false },
  { id: 'promo-codes', name: 'Промокоды', price: 10000, category: 'Маркетинг', icon: Crown, included: false },
  { id: 'referral-system', name: 'Рефералы', price: 18000, category: 'Маркетинг', icon: Users, included: false },
  
  // Управление
  { id: 'basic-analytics', name: 'Аналитика', price: 15000, category: 'Управление', icon: BarChart, included: false },
  { id: 'admin-panel', name: 'Админ панель', price: 25000, category: 'Управление', icon: Settings, included: false },
  { id: 'crm-system', name: 'CRM', price: 40000, category: 'Управление', icon: Users, included: false },
  
  // Бронирование
  { id: 'booking-system', name: 'Бронирование', price: 18000, category: 'Бронирование', icon: Calendar, included: false },
  { id: 'queue-management', name: 'Очереди', price: 15000, category: 'Бронирование', icon: Clock, included: false },
  { id: 'calendar-sync', name: 'Календарь', price: 10000, category: 'Бронирование', icon: Calendar, included: false },
  
  // Дополнительные для шаблонов
  { id: 'progress-tracking', name: 'Прогресс', price: 15000, category: 'Управление', icon: BarChart, included: false }
];

const categories = ['Основные', 'Платежи', 'Доставка', 'Коммуникации', 'Маркетинг', 'Управление', 'Бронирование'];

export default function ConstructorPage({ onNavigate }: ConstructorPageProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<typeof appTemplates[0] | null>(null);
  const [selectedFeatures, setSelectedFeatures] = useState<SelectedFeature[]>([]);
  const [activeCategory, setActiveCategory] = useState('Основные');
  const [projectName, setProjectName] = useState('');
  const [currentStep, setCurrentStep] = useState(1); // 1: template, 2: features, 3: review

  const selectTemplate = (template: typeof appTemplates[0]) => {
    setSelectedTemplate(template);
    setProjectName(`Мой ${template.name}`);
    
    // Add template features
    const templateFeatures = template.features.map(featureId => {
      const feature = availableFeatures.find(f => f.id === featureId);
      if (feature) {
        return {
          id: feature.id,
          name: feature.name,
          price: feature.price,
          category: feature.category
        };
      }
      return null;
    }).filter(Boolean) as SelectedFeature[];
    
    setSelectedFeatures(templateFeatures);
    setCurrentStep(2);
  };

  const toggleFeature = (feature: typeof availableFeatures[0]) => {
    if (feature.included) return; // Can't toggle included features
    if (selectedTemplate?.features.includes(feature.id)) return; // Can't toggle template features
    
    const isSelected = selectedFeatures.find(f => f.id === feature.id);
    if (isSelected) {
      setSelectedFeatures(prev => prev.filter(f => f.id !== feature.id));
    } else {
      setSelectedFeatures(prev => [...prev, {
        id: feature.id,
        name: feature.name,
        price: feature.price,
        category: feature.category
      }]);
    }
  };

  const calculateTotal = () => {
    const basePrice = selectedTemplate?.estimatedPrice || 0;
    
    // Get template included features
    const templateIncludedFeatures = selectedTemplate?.features || [];
    
    // Only charge for features that are:
    // 1. Not marked as included in availableFeatures
    // 2. Not part of the selected template's base features
    const featuresPrice = selectedFeatures
      .filter(f => {
        const feature = availableFeatures.find(af => af.id === f.id);
        const isIncluded = feature?.included;
        const isInTemplate = templateIncludedFeatures.includes(f.id);
        return !isIncluded && !isInTemplate;
      })
      .reduce((sum, feature) => sum + feature.price, 0);
    
    return basePrice + featuresPrice;
  };

  const handleOrderClick = () => {
    if (!selectedTemplate || !projectName.trim()) return;
    
    const orderData = {
      projectName: projectName.trim(),
      selectedFeatures,
      selectedTemplate: selectedTemplate.name,
      totalAmount: calculateTotal(),
      estimatedDevelopmentTime: selectedTemplate.developmentTime
    };
    
    onNavigate('checkout', orderData);
  };

  const goToStep = (step: number) => {
    setCurrentStep(step);
  };

  const filteredFeatures = availableFeatures.filter(f => f.category === activeCategory);

  return (
    <div className="min-h-screen bg-white text-label safe-area-top pb-32 relative">
      {/* Animated Background Effects */}
      <div className="wow-bg-animated"></div>
      <div className="wow-bg-mesh"></div>
      
      {/* Morphing Blobs */}
      <div className="wow-blob wow-blob-1"></div>
      <div className="wow-blob wow-blob-2"></div>
      <div className="wow-blob wow-blob-3"></div>

      <StickyGlassHeader />

      <div className="max-w-md mx-auto px-4 space-y-6">
        {/* Progress Steps */}
        <section className="ios-slide-up">
          <div className="ios-list">
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  currentStep >= 1 ? 'bg-system-blue' : 'bg-secondary-system-fill'
                }`}>
                  {currentStep > 1 ? (
                    <Check className="w-3 h-3 text-white" />
                  ) : (
                    <span className="ios-caption2 text-white font-bold">1</span>
                  )}
                </div>
                <div className="flex-1">
                  <div className="ios-body font-semibold">Выберите тип приложения</div>
                  <div className="ios-footnote text-secondary-label">Готовый шаблон под ваш бизнес</div>
                </div>
                {currentStep === 1 && <div className="w-2 h-2 bg-system-blue rounded-full" />}
              </div>
            </div>
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  currentStep >= 2 ? 'bg-system-blue' : 'bg-secondary-system-fill'
                }`}>
                  {currentStep > 2 ? (
                    <Check className="w-3 h-3 text-white" />
                  ) : (
                    <span className="ios-caption2 text-white font-bold">2</span>
                  )}
                </div>
                <div className="flex-1">
                  <div className="ios-body font-semibold">Добавьте функции</div>
                  <div className="ios-footnote text-secondary-label">Расширьте возможности</div>
                </div>
                {currentStep === 2 && <div className="w-2 h-2 bg-system-blue rounded-full" />}
              </div>
            </div>
            <div className="ios-list-item">
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  currentStep >= 3 ? 'bg-system-blue' : 'bg-secondary-system-fill'
                }`}>
                  <span className="ios-caption2 text-white font-bold">3</span>
                </div>
                <div className="flex-1">
                  <div className="ios-body font-semibold">Оформите заказ</div>
                  <div className="ios-footnote text-secondary-label">Запустите разработку</div>
                </div>
                {currentStep === 3 && <div className="w-2 h-2 bg-system-blue rounded-full" />}
              </div>
            </div>
          </div>
        </section>

        {/* Step 1: Template Selection */}
        {currentStep === 1 && (
          <section className="ios-slide-up space-y-6">
            <div className="text-center">
              <h2 className="ios-title3 mb-2">Шаг 1: Выберите тип</h2>
              <p className="ios-subheadline text-secondary-label">
                Готовые решения для разных сфер бизнеса
              </p>
            </div>

            <div className="ios-list">
              {appTemplates.map((template) => {
                const IconComponent = template.icon;
                return (
                  <div
                    key={template.id}
                    className="ios-list-item cursor-pointer"
                    onClick={() => selectTemplate(template)}
                    data-testid={`template-${template.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-system-blue/10 rounded-medium flex items-center justify-center">
                        <IconComponent className="w-5 h-5 text-system-blue" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="ios-headline font-semibold">{template.name}</span>
                          {template.popular && (
                            <span className="px-2 py-0.5 bg-system-orange/10 rounded-full">
                              <span className="ios-caption2 text-system-orange font-semibold">Популярно</span>
                            </span>
                          )}
                        </div>
                        <div className="ios-footnote text-secondary-label">{template.description}</div>
                        <div className="ios-footnote text-secondary-label flex items-center space-x-1 mt-1">
                          <Clock className="w-3 h-3" />
                          <span>{template.developmentTime}</span>
                          <span>•</span>
                          <span>от {template.estimatedPrice.toLocaleString()} ₽</span>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-tertiary-label" />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="ios-card p-4 bg-system-blue/5 border-system-blue/20">
              <div className="flex items-start space-x-3">
                <Info className="w-5 h-5 text-system-blue mt-0.5" />
                <div>
                  <div className="ios-body font-semibold text-system-blue">Подсказка</div>
                  <div className="ios-footnote text-secondary-label">
                    Выберите тип, наиболее близкий к вашему бизнесу. 
                    Позже можно будет добавить дополнительные функции.
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Step 2: Features Selection */}
        {currentStep === 2 && selectedTemplate && (
          <section className="ios-slide-up space-y-6">
            <div className="text-center">
              <h2 className="ios-title3 mb-2">Шаг 2: Настройте функции</h2>
              <p className="ios-subheadline text-secondary-label">
                Добавьте нужные возможности для вашего приложения
              </p>
            </div>

            {/* Project Name */}
            <div className="ios-card p-4">
              <div className="ios-field-label">Название проекта</div>
              <input
                type="text"
                className="ios-field w-full mt-1"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="Введите название"
                data-testid="project-name-input"
              />
            </div>

            {/* Category Selector */}
            <div className="ios-segmented overflow-x-auto">
              <div className="flex space-x-1 min-w-max">
                {categories.map((category) => (
                  <button
                    key={category}
                    className={`${
                      activeCategory === category ? 'ios-segmented-item-active' : 'ios-segmented-item'
                    } whitespace-nowrap`}
                    onClick={() => setActiveCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Features List */}
            <div className="ios-list">
              <div className="ios-list-header">{activeCategory}</div>
              {filteredFeatures.map((feature) => {
                const IconComponent = feature.icon;
                const isSelected = selectedFeatures.find(f => f.id === feature.id);
                const isIncluded = feature.included;
                const isInTemplate = selectedTemplate?.features.includes(feature.id);
                const isIncludedInAny = isIncluded || isInTemplate;
                
                return (
                  <div
                    key={feature.id}
                    className={`ios-list-item ${!isIncludedInAny ? 'cursor-pointer' : ''}`}
                    onClick={() => !isIncludedInAny && toggleFeature(feature)}
                    data-testid={`feature-${feature.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                        isSelected || isIncludedInAny
                          ? 'bg-system-blue border-system-blue'
                          : 'border-tertiary-label'
                      }`}>
                        {(isSelected || isIncludedInAny) && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                      <IconComponent className="w-5 h-5 text-secondary-label" />
                      <div className="flex-1">
                        <div className="ios-body font-semibold">{feature.name}</div>
                        {isIncludedInAny && (
                          <div className="ios-footnote text-system-green">Включено в шаблон</div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="ios-body font-semibold text-system-blue">
                          {isIncludedInAny ? 'Включено' : `+${feature.price.toLocaleString()} ₽`}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Navigation Buttons */}
            <div className="flex space-x-3">
              <button
                className="ios-button-tinted flex-1"
                onClick={() => goToStep(1)}
              >
                Назад
              </button>
              <button
                className="ios-button-filled flex-1"
                onClick={() => goToStep(3)}
                disabled={!projectName.trim()}
              >
                Далее
              </button>
            </div>
          </section>
        )}

        {/* Step 3: Review and Order */}
        {currentStep === 3 && selectedTemplate && (
          <section className="ios-slide-up space-y-6">
            <div className="text-center">
              <h2 className="ios-title3 mb-2">Шаг 3: Подтвердите заказ</h2>
              <p className="ios-subheadline text-secondary-label">
                Проверьте конфигурацию и запустите разработку
              </p>
            </div>

            {/* Project Summary */}
            <div className="ios-card p-6 space-y-4">
              <div className="text-center">
                <h3 className="ios-title3 mb-1">{projectName}</h3>
                <p className="ios-footnote text-secondary-label">
                  На основе шаблона "{selectedTemplate.name}"
                </p>
              </div>
              
              <div className="border-t border-separator pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="ios-body">Базовая стоимость</span>
                  <span className="ios-body font-semibold">{selectedTemplate.estimatedPrice.toLocaleString()} ₽</span>
                </div>
                
                {selectedFeatures.filter(f => {
                  const feature = availableFeatures.find(af => af.id === f.id);
                  const isIncluded = feature?.included;
                  const isInTemplate = selectedTemplate?.features.includes(f.id);
                  return !isIncluded && !isInTemplate;
                }).length > 0 && (
                  <div className="flex justify-between items-center mb-2">
                    <span className="ios-body">Дополнительные функции</span>
                    <span className="ios-body font-semibold">
                      +{selectedFeatures
                        .filter(f => {
                          const feature = availableFeatures.find(af => af.id === f.id);
                          const isIncluded = feature?.included;
                          const isInTemplate = selectedTemplate?.features.includes(f.id);
                          return !isIncluded && !isInTemplate;
                        })
                        .reduce((sum, f) => sum + f.price, 0)
                        .toLocaleString()} ₽
                    </span>
                  </div>
                )}
                
                <div className="border-t border-separator pt-2">
                  <div className="flex justify-between items-center">
                    <span className="ios-headline font-bold">Итого</span>
                    <span className="ios-title3 font-bold text-system-blue">{calculateTotal().toLocaleString()} ₽</span>
                  </div>
                </div>
              </div>
              
              <div className="ios-card bg-system-green/5 border-system-green/20 p-4">
                <div className="flex items-center space-x-2 justify-center">
                  <Clock className="w-4 h-4 text-system-green" />
                  <span className="ios-footnote text-system-green font-semibold">
                    Готовность: {selectedTemplate.developmentTime}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                className="ios-button-filled w-full"
                onClick={handleOrderClick}
                data-testid="button-order"
              >
                Заказать за {calculateTotal().toLocaleString()} ₽
              </button>
              
              <button
                className="ios-button-tinted w-full"
                onClick={() => goToStep(2)}
              >
                Изменить функции
              </button>
              
              <div className="text-center">
                <p className="ios-footnote text-secondary-label">
                  Предоплата 30% • Остальное по готовности этапов
                </p>
              </div>
            </div>
          </section>
        )}
      </div>

      {/* Sticky Summary Bar */}
      {selectedTemplate && currentStep > 1 && (
        <div className="ios-cta-bar fixed bottom-20 left-0 right-0" data-testid="summary-bar">
          <div className="max-w-md mx-auto px-4">
            <div className="ios-card p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="ios-footnote text-secondary-label">Текущая стоимость</div>
                  <div className="ios-headline font-bold text-system-blue">
                    {calculateTotal().toLocaleString()} ₽
                  </div>
                </div>
                <div className="text-right">
                  <div className="ios-footnote text-secondary-label">Функций</div>
                  <div className="ios-headline font-bold">
                    {selectedFeatures.length}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}