import { useState, useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import ShowcasePage from "./components/ShowcasePage";
import ProjectsPage from "./components/ProjectsPage";
import DemoAppLanding from "./components/DemoAppLanding";
import PricingPage from "./components/PricingPage";
import ConstructorPage from "./components/ConstructorPage";
import ProfilePage from "./components/ProfilePage";
import CheckoutPage from "./components/CheckoutPage";
import DemoAppShell from "./components/DemoAppShell";
import HelpPage from "./components/HelpPage";
import ReviewPage from "./components/ReviewPage";
import { useTelegram } from "./hooks/useTelegram";

// Simple hash router types
interface Route {
  path: string;
  component: string;
  params?: Record<string, string>;
}

// Router utilities
const parseHash = (): Route => {
  const hash = window.location.hash.slice(1) || '/';
  const [path, ...rest] = hash.split('?');
  
  // Parse demo routes
  const demoMatch = path.match(/^\/demos\/([^\/]+)(?:\/app)?$/);
  if (demoMatch) {
    const demoId = demoMatch[1];
    const isApp = path.includes('/app');
    return {
      path: isApp ? '/demos/:id/app' : '/demos/:id',
      component: isApp ? 'demoApp' : 'demoLanding',
      params: { id: demoId }
    };
  }
  
  // Regular routes
  const routeMap: Record<string, string> = {
    '/': 'showcase',
    '/projects': 'projects',
    '/pricing': 'pricing',
    '/constructor': 'constructor',
    '/profile': 'profile',
    '/help': 'help',
    '/review': 'review',
    '/checkout': 'checkout'
  };
  
  return {
    path,
    component: routeMap[path] || 'notFound',
    params: {}
  };
};

const navigate = (path: string) => {
  window.location.hash = path;
};

const goBack = () => {
  window.history.back();
};

function App() {
  const [route, setRoute] = useState<Route>(parseHash());
  const [orderData, setOrderData] = useState<any>(null);
  const { hapticFeedback } = useTelegram();

  // Listen for hash changes
  useEffect(() => {
    const handleHashChange = () => {
      setRoute(parseHash());
    };
    
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Navigation handlers
  const handleNavigate = (section: string, data?: any) => {
    if (data) {
      setOrderData(data);
    } else if (section !== 'checkout') {
      setOrderData(null);
    }
    
    navigate(`/${section}`);
    hapticFeedback.light();
  };

  const handleOpenDemo = (demoId: string) => {
    navigate(`/demos/${demoId}`);
    hapticFeedback.medium();
  };

  const handleOpenDemoApp = (demoId: string) => {
    navigate(`/demos/${demoId}/app`);
    hapticFeedback.medium();
  };

  const handleCloseDemo = () => {
    // Navigate back to the demo landing page
    const demoId = route.params?.id;
    if (demoId) {
      navigate(`/demos/${demoId}`);
    } else {
      navigate('/projects');
    }
    hapticFeedback.light();
  };

  const handleCheckoutBack = () => {
    setOrderData(null);
    navigate('/constructor');
    hapticFeedback.light();
  };

  const handlePaymentSuccess = () => {
    setOrderData(null);
    navigate('/profile');
    hapticFeedback.medium();
  };

  // Route component rendering
  const renderRoute = () => {
    switch (route.component) {
      case 'showcase':
        return <ShowcasePage onOpenDemo={handleOpenDemo} onNavigate={handleNavigate} />;
      
      case 'projects':
        return <ProjectsPage onNavigate={handleNavigate} onOpenDemo={handleOpenDemo} />;
      
      case 'demoLanding':
        const demoId = route.params?.id;
        if (!demoId) {
          return (
            <div className="max-w-md mx-auto px-4 py-6">
              <h1 className="ios-title font-bold mb-4">Ошибка</h1>
              <p className="ios-body text-secondary-label">ID демо не указан</p>
              <button 
                onClick={() => navigate('/')} 
                className="mt-4 ios-button-filled"
              >
                Назад к главной
              </button>
            </div>
          );
        }
        return <DemoAppLanding demoId={demoId} />;
      
      case 'demoApp':
        return <DemoAppShell demoId={route.params?.id!} onClose={handleCloseDemo} />;
      
      case 'pricing':
        return <PricingPage onNavigate={handleNavigate} />;
      
      case 'constructor':
        return <ConstructorPage onNavigate={handleNavigate} />;
      
      case 'profile':
        return <ProfilePage onNavigate={handleNavigate} />;
      
      case 'help':
        return <HelpPage onBack={() => navigate('/profile')} />;
      
      case 'review':
        return <ReviewPage onBack={() => navigate('/profile')} />;
      
      case 'checkout':
        if (!orderData) {
          navigate('/constructor');
          return null;
        }
        return (
          <CheckoutPage 
            selectedFeatures={orderData.selectedFeatures || []}
            projectName={orderData.projectName || ''}
            totalAmount={orderData.totalAmount || 0}
            onBack={handleCheckoutBack}
            onSuccess={handlePaymentSuccess}
          />
        );
      
      default:
        return (
          <div className="max-w-md mx-auto px-4 py-6 text-center">
            <h1 className="ios-title font-bold mb-4">Страница не найдена</h1>
            <button 
              onClick={() => navigate('/')} 
              className="ios-button-filled"
            >
              На главную
            </button>
          </div>
        );
    }
  };

  // Check if we should show bottom navigation
  const shouldShowBottomNav = !route.component.includes('demo') && route.component !== 'notFound';

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="relative min-h-screen">
          <div className="floating-elements"></div>
          
          {renderRoute()}
          
          {/* Bottom Navigation */}
          {shouldShowBottomNav && (
            <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-2xl border-t border-gray-200/30 safe-area-bottom">
              <div className="max-w-md mx-auto px-6 py-4">
                <nav className="grid grid-cols-4 gap-2">
                  
                  {/* Главная */}
                  <button
                    onClick={() => {navigate('/'); hapticFeedback.light();}}
                    className={`flex flex-col items-center space-y-1 group transition-all duration-200 ${
                      route.component === 'showcase' ? 'active-nav-item' : ''
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-3xl flex items-center justify-center transition-all duration-200 active:scale-95 ${
                      route.component === 'showcase' 
                        ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg' 
                        : 'bg-gray-100 group-active:bg-gradient-to-br group-active:from-blue-500 group-active:to-indigo-600'
                    }`}>
                      <svg className={`w-6 h-6 transition-all duration-200 ${
                        route.component === 'showcase' ? 'text-white' : 'text-gray-500 group-active:text-white'
                      }`} fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/>
                      </svg>
                    </div>
                    <span className={`text-xs font-medium transition-all duration-200 ${
                      route.component === 'showcase' ? 'text-blue-600 font-bold' : 'text-gray-600 group-active:text-blue-600'
                    }`}>Главная</span>
                  </button>
                  
                  {/* Тарифы */}
                  <button
                    onClick={() => {navigate('/pricing'); hapticFeedback.light();}}
                    className={`flex flex-col items-center space-y-1 group transition-all duration-200 ${
                      route.component === 'pricing' ? 'active-nav-item' : ''
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-3xl flex items-center justify-center transition-all duration-200 active:scale-95 ${
                      route.component === 'pricing' 
                        ? 'bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg' 
                        : 'bg-gray-100 group-active:bg-gradient-to-br group-active:from-green-500 group-active:to-emerald-600'
                    }`}>
                      <svg className={`w-6 h-6 transition-all duration-200 ${
                        route.component === 'pricing' ? 'text-white' : 'text-gray-500 group-active:text-white'
                      }`} fill="currentColor" viewBox="0 0 20 20">
                        <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"/>
                      </svg>
                    </div>
                    <span className={`text-xs font-medium transition-all duration-200 ${
                      route.component === 'pricing' ? 'text-green-600 font-bold' : 'text-gray-600 group-active:text-green-600'
                    }`}>Тарифы</span>
                  </button>
                  
                  {/* Создать */}
                  <button
                    onClick={() => {navigate('/constructor'); hapticFeedback.light();}}
                    className={`flex flex-col items-center space-y-1 group transition-all duration-200 ${
                      route.component === 'constructor' ? 'active-nav-item' : ''
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-3xl flex items-center justify-center transition-all duration-200 active:scale-95 ${
                      route.component === 'constructor' 
                        ? 'bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg' 
                        : 'bg-gray-100 group-active:bg-gradient-to-br group-active:from-purple-500 group-active:to-pink-600'
                    }`}>
                      <svg className={`w-6 h-6 transition-all duration-200 ${
                        route.component === 'constructor' ? 'text-white' : 'text-gray-500 group-active:text-white'
                      }`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd"/>
                      </svg>
                    </div>
                    <span className={`text-xs font-medium transition-all duration-200 ${
                      route.component === 'constructor' ? 'text-purple-600 font-bold' : 'text-gray-600 group-active:text-purple-600'
                    }`}>Создать</span>
                  </button>
                  
                  {/* Профиль */}
                  <button
                    onClick={() => {navigate('/profile'); hapticFeedback.light();}}
                    className={`flex flex-col items-center space-y-1 group transition-all duration-200 ${
                      route.component === 'profile' ? 'active-nav-item' : ''
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-3xl flex items-center justify-center transition-all duration-200 active:scale-95 ${
                      route.component === 'profile' 
                        ? 'bg-gradient-to-br from-orange-500 to-red-600 shadow-lg' 
                        : 'bg-gray-100 group-active:bg-gradient-to-br group-active:from-orange-500 group-active:to-red-600'
                    }`}>
                      <svg className={`w-6 h-6 transition-all duration-200 ${
                        route.component === 'profile' ? 'text-white' : 'text-gray-500 group-active:text-white'
                      }`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"/>
                      </svg>
                    </div>
                    <span className={`text-xs font-medium transition-all duration-200 ${
                      route.component === 'profile' ? 'text-orange-600 font-bold' : 'text-gray-600 group-active:text-orange-600'
                    }`}>Профиль</span>
                  </button>
                  
                </nav>
              </div>
            </div>
          )}
          
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;