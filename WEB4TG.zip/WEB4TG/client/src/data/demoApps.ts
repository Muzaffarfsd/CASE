export interface Banner {
  title: string;
  subtitle?: string;
  image?: string;
  bgClass?: string;
}

export interface Service {
  id: string;
  title: string;
  priceText?: string;
  iconName?: string;
  image?: string;
}

export interface DemoAppHome {
  hero: {
    title?: string;
    subtitle?: string;
    image?: string;
    bgClass?: string;
  };
  banners?: Banner[];
  services?: Service[];
}

export interface DemoApp {
  id: string;
  title: string;
  description: string;
  category: string;
  image: string;
  creator: string;
  likes: string;
  badge?: string;
  badgeColor?: string;
  home?: DemoAppHome;
}

export const demoApps: DemoApp[] = [
  {
    id: 'clothing-store',
    title: 'Модный Бутик',
    description: 'Премиум магазин одежды с каталогом и корзиной',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '2.5k',
    badge: 'Живое Демо',
    badgeColor: 'bg-red-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Модный Бутик',
        subtitle: 'Откройте мир премиальной моды и стиля',
        image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-pink-500 to-purple-600'
      },
      banners: [
        {
          title: 'Новая коллекция',
          subtitle: 'Осень-Зима 2024',
          image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400',
          bgClass: 'bg-gradient-to-r from-purple-500 to-pink-500'
        },
        {
          title: 'Скидки до 50%',
          subtitle: 'На избранные товары',
          bgClass: 'bg-gradient-to-r from-red-500 to-orange-500'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Просмотр товаров', iconName: 'grid' },
        { id: 'favorites', title: 'Избранное', priceText: 'Ваши предпочтения', iconName: 'heart' },
        { id: 'cart', title: 'Корзина', priceText: 'Оформить заказ', iconName: 'shopping-cart' },
        { id: 'profile', title: 'Профиль', priceText: 'Настройки аккаунта', iconName: 'user' }
      ]
    }
  },
  {
    id: 'restaurant',
    title: 'Bella Cucina',
    description: 'Ресторан с онлайн меню и доставкой',
    category: 'Еда и Доставка',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '1.8k',
    badge: 'Открыто',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Bella Cucina',
        subtitle: 'Аутентичная итальянская кухня и доставка на дом',
        image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
      },
      banners: [
        {
          title: 'Меню дня',
          subtitle: 'Специальные предложения',
          image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        },
        {
          title: 'Бесплатная доставка',
          subtitle: 'При заказе от 1000₽',
          bgClass: 'bg-gradient-to-r from-blue-500 to-teal-500'
        }
      ],
      services: [
        { id: 'menu', title: 'Меню', priceText: 'Выбрать блюда', iconName: 'book-open' },
        { id: 'delivery', title: 'Доставка', priceText: 'Быстрая доставка', iconName: 'truck' },
        { id: 'orders', title: 'Заказы', priceText: 'История заказов', iconName: 'clock' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваш аккаунт', iconName: 'user' }
      ]
    }
  },
  {
    id: 'fitness',
    title: 'PowerFit Зал',
    description: 'Фитнес-клуб с занятиями и абонементами',
    category: 'Здоровье и Фитнес',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '3.1k',
    badge: '24/7 Доступ',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'Добро пожаловать в PowerFit Зал',
        subtitle: 'Достигни своих целей с лучшими тренерами и оборудованием',
        image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
      },
      banners: [
        {
          title: 'Первая тренировка',
          subtitle: 'Бесплатно для новых участников',
          image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        },
        {
          title: 'Групповые занятия',
          subtitle: 'Йога, пилатес, кроссфит',
          bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'schedule', title: 'Расписание', priceText: 'Записаться на занятия', iconName: 'calendar' },
        { id: 'trainers', title: 'Тренеры', priceText: 'Персональные тренировки', iconName: 'users' },
        { id: 'membership', title: 'Абонементы', priceText: 'Выбрать план', iconName: 'credit-card' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши достижения', iconName: 'user' }
      ]
    }
  },
  {
    id: 'coffee',
    title: 'Кофе Рай',
    description: 'Кофейня с заказами и программой лояльности',
    category: 'Еда и Доставка',
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '1.4k',
    badge: 'Свежий Помол',
    badgeColor: 'bg-amber-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Кофе Рай',
        subtitle: 'Лучший кофе города и уютная атмосфера',
        image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-amber-500 to-orange-600'
      },
      banners: [
        {
          title: 'Кофе дня',
          subtitle: 'Специальное предложение',
          image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400',
          bgClass: 'bg-gradient-to-r from-brown-500 to-amber-600'
        },
        {
          title: 'Программа лояльности',
          subtitle: 'Накапливайте баллы и получайте подарки',
          bgClass: 'bg-gradient-to-r from-yellow-500 to-orange-500'
        }
      ],
      services: [
        { id: 'menu', title: 'Меню', priceText: 'Выбрать напитки', iconName: 'coffee' },
        { id: 'loyalty', title: 'Бонусы', priceText: 'Программа лояльности', iconName: 'gift' },
        { id: 'orders', title: 'Заказы', priceText: 'История покупок', iconName: 'clock' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваш аккаунт', iconName: 'user' }
      ]
    }
  },
  {
    id: 'beauty',
    title: 'Glow Студия',
    description: 'Салон красоты с бронированием и услугами',
    category: 'Здравоохранение',
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '900',
    badge: 'Записаться',
    badgeColor: 'bg-pink-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Glow Студию',
        subtitle: 'Профессиональные услуги красоты и релакса',
        image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-pink-500 to-rose-600'
      },
      banners: [
        {
          title: 'Акция недели',
          subtitle: 'Скидка 20% на spa-процедуры',
          image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400',
          bgClass: 'bg-gradient-to-r from-purple-500 to-pink-600'
        },
        {
          title: 'Новые мастера',
          subtitle: 'Профессионалы в области красоты',
          bgClass: 'bg-gradient-to-r from-rose-500 to-pink-500'
        }
      ],
      services: [
        { id: 'services', title: 'Услуги', priceText: 'Каталог процедур', iconName: 'scissors' },
        { id: 'booking', title: 'Запись', priceText: 'Выбрать время', iconName: 'calendar' },
        { id: 'masters', title: 'Мастера', priceText: 'Выбрать специалиста', iconName: 'users' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши записи', iconName: 'user' }
      ]
    }
  },
  {
    id: 'electronics',
    title: 'ТехХаб Магазин',
    description: 'Магазин электроники с обзорами товаров',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '2.7k',
    badge: 'Новинки Техники',
    badgeColor: 'bg-cyan-500',
    home: {
      hero: {
        title: 'Добро пожаловать в ТехХаб',
        subtitle: 'Лучшие технологии по доступным ценам',
        image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=400',
        bgClass: 'bg-gradient-to-r from-cyan-500 to-blue-600'
      },
      banners: [
        {
          title: 'Новинки 2024',
          subtitle: 'Последние модели смартфонов и лэптопов',
          image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
        },
        {
          title: 'Трейд-ин',
          subtitle: 'Обменяй старую технику на новую',
          bgClass: 'bg-gradient-to-r from-green-500 to-teal-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Просмотр товаров', iconName: 'smartphone' },
        { id: 'reviews', title: 'Обзоры', priceText: 'Отзывы покупателей', iconName: 'star' },
        { id: 'compare', title: 'Сравнение', priceText: 'Сравнить товары', iconName: 'bar-chart' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши покупки', iconName: 'user' }
      ]
    }
  },
  {
    id: 'bookstore',
    title: 'Книжный Уголок',
    description: 'Онлайн книжный с рекомендациями',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '1.2k',
    badge: 'Новые Поступления',
    badgeColor: 'bg-purple-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Книжный Уголок',
        subtitle: 'Откройте мир знаний с лучшими книгами',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
      },
      banners: [
        {
          title: 'Новинки месяца',
          subtitle: 'Лучшие новые книги и бестселлеры',
          image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400',
          bgClass: 'bg-gradient-to-r from-amber-500 to-orange-600'
        },
        {
          title: 'Клуб читателей',
          subtitle: 'Присоединяйтесь к обсуждениям',
          bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Поиск книг', iconName: 'book' },
        { id: 'recommendations', title: 'Рекомендации', priceText: 'Подбор по вкусу', iconName: 'heart' },
        { id: 'wishlist', title: 'Желаемое', priceText: 'Список к покупке', iconName: 'bookmark' },
        { id: 'profile', title: 'Профиль', priceText: 'Моя библиотека', iconName: 'user' }
      ]
    }
  },
  {
    id: 'florist',
    title: 'Цветочный Рай',
    description: 'Цветочный магазин с доставкой',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '800',
    badge: 'Свежие Ежедневно',
    badgeColor: 'bg-emerald-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Цветочный Рай',
        subtitle: 'Свежие цветы и красивые букеты на любой повод',
        image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-emerald-500 to-green-600'
      },
      banners: [
        {
          title: 'Свадебные букеты',
          subtitle: 'Незабываемые композиции',
          image: 'https://images.unsplash.com/photo-1606923829579-0cb981a83e2e?w=400',
          bgClass: 'bg-gradient-to-r from-pink-500 to-rose-600'
        },
        {
          title: 'Доставка 24/7',
          subtitle: 'Порадуем в любое время',
          bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Выбрать букет', iconName: 'flower' },
        { id: 'occasions', title: 'Поводы', priceText: 'По случаю', iconName: 'calendar' },
        { id: 'delivery', title: 'Доставка', priceText: 'Адрес и время', iconName: 'truck' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши заказы', iconName: 'user' }
      ]
    }
  },
  {
    id: 'carwash',
    title: 'Авто Блеск',
    description: 'Бронирование автомойки и отслеживание услуг',
    category: 'Транспорт',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '650',
    badge: 'Быстрый Сервис',
    badgeColor: 'bg-orange-500',
    home: {
      hero: {
        title: 'Добро пожаловать в Авто Блеск',
        subtitle: 'Профессиональная мойка и уход за вашим авто',
        image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
      },
      banners: [
        {
          title: 'Полная мойка',
          subtitle: 'Комплексное обслуживание',
          image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        },
        {
          title: 'Лояльность',
          subtitle: 'Каждая 10-я мойка бесплатно',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        }
      ],
      services: [
        { id: 'services', title: 'Услуги', priceText: 'Выбрать пакет', iconName: 'car' },
        { id: 'booking', title: 'Запись', priceText: 'Выбрать время', iconName: 'calendar' },
        { id: 'loyalty', title: 'Лояльность', priceText: 'Накопительная система', iconName: 'gift' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши визиты', iconName: 'user' }
      ]
    }
  },
  {
    id: 'courses',
    title: 'УчиХаб',
    description: 'Платформа онлайн обучения с сертификатами',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '4.2k',
    badge: 'Сертифицировано',
    badgeColor: 'bg-indigo-500',
    home: {
      hero: {
        title: 'Добро пожаловать в УчиХаб',
        subtitle: 'Образовательная платформа для вашего развития',
        image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
      },
      banners: [
        {
          title: 'Новые курсы',
          subtitle: 'Современные навыки и технологии',
          image: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400',
          bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
        },
        {
          title: 'Сертификаты',
          subtitle: 'Подтвердите свои навыки',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Все курсы', iconName: 'book-open' },
        { id: 'progress', title: 'Прогресс', priceText: 'Мое обучение', iconName: 'bar-chart' },
        { id: 'certificates', title: 'Сертификаты', priceText: 'Мои достижения', iconName: 'award' },
        { id: 'profile', title: 'Профиль', priceText: 'Личный кабинет', iconName: 'user' }
      ]
    }
  },
  {
    id: 'pharmacy',
    title: 'АптекаПлюс',
    description: 'Онлайн аптека с доставкой лекарств на дом',
    category: 'Здравоохранение',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '1.9k',
    badge: 'Круглосуточно',
    badgeColor: 'bg-teal-500',
    home: {
      hero: {
        title: 'Добро пожаловать в АптекаПлюс',
        subtitle: 'Лекарства и здоровье в одном клике',
        image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
      },
      banners: [
        {
          title: 'Льготные лекарства',
          subtitle: 'По рецепту со скидкой',
          image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        },
        {
          title: 'Доставка 24/7',
          subtitle: 'Круглосуточно по городу',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Поиск лекарств', iconName: 'search' },
        { id: 'prescription', title: 'Рецепты', priceText: 'По назначению врача', iconName: 'file-text' },
        { id: 'delivery', title: 'Доставка', priceText: 'Отследить заказ', iconName: 'truck' },
        { id: 'profile', title: 'Профиль', priceText: 'Моя аптечка', iconName: 'user' }
      ]
    }
  },
  {
    id: 'realty',
    title: 'НедвижимостьПро',
    description: 'Каталог недвижимости с виртуальными турами',
    category: 'Недвижимость',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '3.4k',
    badge: 'VR Туры',
    badgeColor: 'bg-violet-500',
    home: {
      hero: {
        title: 'Добро пожаловать в НедвижимостьПро',
        subtitle: 'Найдите свой дом мечты с виртуальными турами',
        image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-violet-500 to-purple-600'
      },
      banners: [
        {
          title: 'VR Туры',
          subtitle: 'Осмотрите объекты онлайн',
          image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
          bgClass: 'bg-gradient-to-r from-cyan-500 to-blue-600'
        },
        {
          title: 'Новостройки',
          subtitle: 'Первичный рынок от застройщика',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        }
      ],
      services: [
        { id: 'search', title: 'Поиск', priceText: 'Найти объект', iconName: 'search' },
        { id: 'favorites', title: 'Избранное', priceText: 'Сохранённые объекты', iconName: 'heart' },
        { id: 'tours', title: 'VR Туры', priceText: 'Виртуальные осмотры', iconName: 'eye' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои объекты', iconName: 'user' }
      ]
    }
  },
  {
    id: 'taxi',
    title: 'СуперТакси',
    description: 'Вызов такси с отслеживанием в реальном времени',
    category: 'Транспорт',
    image: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '2.8k',
    badge: 'Быстрая подача',
    badgeColor: 'bg-yellow-500',
    home: {
      hero: {
        title: 'Добро пожаловать в СуперТакси',
        subtitle: 'Надёжные поездки по городу в любое время',
        image: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-yellow-500 to-orange-600'
      },
      banners: [
        {
          title: 'Подача за 2 минуты',
          subtitle: 'Быстрая доставка к месту назначения',
          image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        },
        {
          title: 'Трекинг',
          subtitle: 'Отслеживайте поездку в реальном времени',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'ride', title: 'Вызов', priceText: 'Заказать такси', iconName: 'car' },
        { id: 'tracking', title: 'Отследить', priceText: 'Посмотреть маршрут', iconName: 'map' },
        { id: 'history', title: 'История', priceText: 'Мои поездки', iconName: 'clock' },
        { id: 'profile', title: 'Профиль', priceText: 'Настройки аккаунта', iconName: 'user' }
      ]
    }
  },
  {
    id: 'banking',
    title: 'БанкОнлайн',
    description: 'Мобильный банкинг с переводами и платежами',
    category: 'Финансы',
    image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '4.7k',
    badge: 'Безопасно',
    badgeColor: 'bg-slate-500',
    home: {
      hero: {
        title: 'Добро пожаловать в БанкОнлайн',
        subtitle: 'Удобные финансовые услуги в вашем смартфоне',
        image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-slate-500 to-gray-600'
      },
      banners: [
        {
          title: 'Новые карты',
          subtitle: 'Оформите карту за 5 минут',
          image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400',
          bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
        },
        {
          title: 'Кредиты',
          subtitle: 'Получите кредит онлайн',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        }
      ],
      services: [
        { id: 'accounts', title: 'Счета', priceText: 'Мои счета и карты', iconName: 'credit-card' },
        { id: 'transfers', title: 'Переводы', priceText: 'Отправить деньги', iconName: 'send' },
        { id: 'payments', title: 'Платежи', priceText: 'Оплатить услуги', iconName: 'dollar-sign' },
        { id: 'profile', title: 'Профиль', priceText: 'Настройки банка', iconName: 'user' }
      ]
    }
  },
  {
    id: 'hotel',
    title: 'ОтельБукинг',
    description: 'Бронирование отелей с отзывами гостей',
    category: 'Туризм',
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
    creator: 'WEB4TG',
    likes: '2.1k',
    badge: 'Лучшие цены',
    badgeColor: 'bg-rose-500',
    home: {
      hero: {
        title: 'Добро пожаловать в ОтельБукинг',
        subtitle: 'Найдите идеальный отель для своего путешествия',
        image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300',
        bgClass: 'bg-gradient-to-r from-rose-500 to-pink-600'
      },
      banners: [
        {
          title: 'Лучшие предложения',
          subtitle: 'Скидки до 30% на отели',
          image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400',
          bgClass: 'bg-gradient-to-r from-amber-500 to-orange-600'
        },
        {
          title: 'Отмена без платы',
          subtitle: 'Бесплатная отмена брони',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        }
      ],
      services: [
        { id: 'search', title: 'Поиск', priceText: 'Найти отель', iconName: 'search' },
        { id: 'bookings', title: 'Брони', priceText: 'Мои бронирования', iconName: 'calendar' },
        { id: 'reviews', title: 'Отзывы', priceText: 'Оценки гостей', iconName: 'star' },
        { id: 'profile', title: 'Профиль', priceText: 'Мой аккаунт', iconName: 'user' }
      ]
    }
  },

  // === CLOTHING STORE VARIANTS ===
  {
    id: 'clothing-store-2',
    title: 'СтильЛаб',
    description: 'Минималистичный бутик с кураторской подборкой',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400',
    creator: 'WEB4TG',
    likes: '1.8k',
    badge: 'Премиум',
    badgeColor: 'bg-slate-500',
    home: {
      hero: {
        title: 'СтильЛаб',
        subtitle: 'Кураторская подборка для современного стиля',
        image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400',
        bgClass: 'bg-gradient-to-r from-slate-500 to-gray-600'
      },
      banners: [
        {
          title: 'Новая коллекция',
          subtitle: 'Минималистичная элегантность',
          image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400',
          bgClass: 'bg-gradient-to-r from-gray-500 to-zinc-600'
        },
        {
          title: 'Персональный стилист',
          subtitle: 'Индивидуальный подбор образов',
          bgClass: 'bg-gradient-to-r from-neutral-500 to-stone-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Коллекция', priceText: 'Избранные вещи', iconName: 'grid' },
        { id: 'styling', title: 'Стилист', priceText: 'Консультация', iconName: 'user' },
        { id: 'orders', title: 'Заказы', priceText: 'Статус доставки', iconName: 'package' },
        { id: 'profile', title: 'Профиль', priceText: 'Личный кабинет', iconName: 'settings' }
      ]
    }
  },
  {
    id: 'clothing-store-3',
    title: 'FashionSpace',
    description: 'Трендовая одежда для молодого поколения',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400',
    creator: 'WEB4TG',
    likes: '3.1k',
    badge: 'Тренды',
    badgeColor: 'bg-violet-500',
    home: {
      hero: {
        title: 'FashionSpace',
        subtitle: 'Где рождаются модные тренды',
        image: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400',
        bgClass: 'bg-gradient-to-r from-violet-500 to-purple-600'
      },
      banners: [
        {
          title: 'Street Style',
          subtitle: 'Уличная мода от дизайнеров',
          image: 'https://images.unsplash.com/photo-1506629905607-ced7d6cc7fd9?w=400',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
        },
        {
          title: 'Limited Drop',
          subtitle: 'Ограниченная коллекция',
          bgClass: 'bg-gradient-to-r from-pink-500 to-rose-600'
        }
      ],
      services: [
        { id: 'trends', title: 'Тренды', priceText: 'Новинки сезона', iconName: 'trending-up' },
        { id: 'lookbook', title: 'Лукбук', priceText: 'Готовые образы', iconName: 'image' },
        { id: 'community', title: 'Сообщество', priceText: 'Делись стилем', iconName: 'users' },
        { id: 'profile', title: 'Профиль', priceText: 'Мой стиль', iconName: 'user' }
      ]
    }
  },

  // === RESTAURANT VARIANTS ===
  {
    id: 'restaurant-2',
    title: 'Гастрономия',
    description: 'Изысканная кухня от шеф-повара мишлен',
    category: 'Еда и Напитки',
    image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400',
    creator: 'WEB4TG',
    likes: '2.3k',
    badge: 'Мишлен',
    badgeColor: 'bg-amber-500',
    home: {
      hero: {
        title: 'Гастрономия',
        subtitle: 'Высокая кухня в современной интерпретации',
        image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400',
        bgClass: 'bg-gradient-to-r from-amber-500 to-orange-600'
      },
      banners: [
        {
          title: 'Дегустационное меню',
          subtitle: '7 блюд от шеф-повара',
          image: 'https://images.unsplash.com/photo-1578474846511-04ba529f0b88?w=400',
          bgClass: 'bg-gradient-to-r from-yellow-500 to-amber-600'
        },
        {
          title: 'Винная карта',
          subtitle: 'Эксклюзивная коллекция вин',
          bgClass: 'bg-gradient-to-r from-red-500 to-rose-600'
        }
      ],
      services: [
        { id: 'menu', title: 'Меню', priceText: 'Авторские блюда', iconName: 'book-open' },
        { id: 'reservation', title: 'Бронь', priceText: 'Столик на вечер', iconName: 'calendar' },
        { id: 'sommelier', title: 'Сомелье', priceText: 'Подбор вин', iconName: 'wine' },
        { id: 'profile', title: 'Профиль', priceText: 'Личные предпочтения', iconName: 'user' }
      ]
    }
  },
  {
    id: 'restaurant-3',
    title: 'LocalEats',
    description: 'Локальная кухня и фермерские продукты',
    category: 'Еда и Напитки',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400',
    creator: 'WEB4TG',
    likes: '1.9k',
    badge: 'Эко',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'LocalEats',
        subtitle: 'Свежие продукты от местных фермеров',
        image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
      },
      banners: [
        {
          title: 'Сезонное меню',
          subtitle: 'Блюда из свежих ингредиентов',
          image: 'https://images.unsplash.com/photo-1490818387583-1baba5e638af?w=400',
          bgClass: 'bg-gradient-to-r from-lime-500 to-green-600'
        },
        {
          title: 'Zero Waste',
          subtitle: 'Ответственное потребление',
          bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
        }
      ],
      services: [
        { id: 'menu', title: 'Меню', priceText: 'Сезонные блюда', iconName: 'leaf' },
        { id: 'farm', title: 'Ферма', priceText: 'Местные поставщики', iconName: 'map-pin' },
        { id: 'delivery', title: 'Доставка', priceText: 'Эко-упаковка', iconName: 'truck' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши заказы', iconName: 'user' }
      ]
    }
  },

  // === FITNESS VARIANTS ===
  {
    id: 'fitness-2',
    title: 'ZenFit',
    description: 'Йога и медитация для гармонии души и тела',
    category: 'Здоровье и Фитнес',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400',
    creator: 'WEB4TG',
    likes: '1.7k',
    badge: 'Mindfulness',
    badgeColor: 'bg-teal-500',
    home: {
      hero: {
        title: 'ZenFit',
        subtitle: 'Путь к внутренней гармонии через движение',
        image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400',
        bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
      },
      banners: [
        {
          title: 'Утренняя йога',
          subtitle: 'Начни день с правильной энергии',
          image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400',
          bgClass: 'bg-gradient-to-r from-sky-500 to-blue-600'
        },
        {
          title: 'Медитация',
          subtitle: 'Практики осознанности',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
        }
      ],
      services: [
        { id: 'classes', title: 'Классы', priceText: 'Йога и медитация', iconName: 'lotus' },
        { id: 'mindfulness', title: 'Практики', priceText: 'Осознанность', iconName: 'brain' },
        { id: 'progress', title: 'Прогресс', priceText: 'Ваш путь', iconName: 'trending-up' },
        { id: 'profile', title: 'Профиль', priceText: 'Личный дневник', iconName: 'user' }
      ]
    }
  },
  {
    id: 'fitness-3',
    title: 'PowerGym',
    description: 'Интенсивные тренировки для максимальных результатов',
    category: 'Здоровье и Фитнес',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400',
    creator: 'WEB4TG',
    likes: '2.6k',
    badge: 'Pro Training',
    badgeColor: 'bg-red-500',
    home: {
      hero: {
        title: 'PowerGym',
        subtitle: 'Раскрой свой максимальный потенциал',
        image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400',
        bgClass: 'bg-gradient-to-r from-red-500 to-orange-600'
      },
      banners: [
        {
          title: 'HIIT тренировки',
          subtitle: 'Высокоинтенсивные интервалы',
          image: 'https://images.unsplash.com/photo-1549476464-37392f717541?w=400',
          bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
        },
        {
          title: 'Персональный тренер',
          subtitle: 'Индивидуальная программа',
          bgClass: 'bg-gradient-to-r from-yellow-500 to-orange-600'
        }
      ],
      services: [
        { id: 'workouts', title: 'Тренировки', priceText: 'Интенсивные программы', iconName: 'zap' },
        { id: 'nutrition', title: 'Питание', priceText: 'План питания', iconName: 'apple' },
        { id: 'coach', title: 'Тренер', priceText: 'Персональный коач', iconName: 'user-check' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши достижения', iconName: 'trophy' }
      ]
    }
  },

  // === COFFEE VARIANTS ===
  {
    id: 'coffee-2',
    title: 'Roastery Lab',
    description: 'Авторские кофейные смеси от мастера обжарки',
    category: 'Еда и Напитки',
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400',
    creator: 'WEB4TG',
    likes: '1.4k',
    badge: 'Specialty',
    badgeColor: 'bg-amber-600',
    home: {
      hero: {
        title: 'Roastery Lab',
        subtitle: 'Искусство обжарки в каждой чашке',
        image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400',
        bgClass: 'bg-gradient-to-r from-amber-600 to-orange-700'
      },
      banners: [
        {
          title: 'Single Origin',
          subtitle: 'Моносорта со всего мира',
          image: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=400',
          bgClass: 'bg-gradient-to-r from-yellow-600 to-amber-700'
        },
        {
          title: 'Мастер-классы',
          subtitle: 'Обучение искусству кофе',
          bgClass: 'bg-gradient-to-r from-orange-600 to-red-700'
        }
      ],
      services: [
        { id: 'beans', title: 'Зерно', priceText: 'Авторские смеси', iconName: 'coffee' },
        { id: 'brewing', title: 'Заваривание', priceText: 'Методы приготовления', iconName: 'flask' },
        { id: 'education', title: 'Обучение', priceText: 'Мастер-классы', iconName: 'graduation-cap' },
        { id: 'profile', title: 'Профиль', priceText: 'Ваши предпочтения', iconName: 'user' }
      ]
    }
  },
  {
    id: 'coffee-3',
    title: 'CafeHub',
    description: 'Сеть городских кофеен с доставкой',
    category: 'Еда и Напитки',
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=400',
    creator: 'WEB4TG',
    likes: '2.1k',
    badge: 'Network',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'CafeHub',
        subtitle: 'Твоя кофейня всегда рядом',
        image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=400',
        bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
      },
      banners: [
        {
          title: 'Доставка за 15 минут',
          subtitle: 'Быстро и всегда горячий',
          image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=400',
          bgClass: 'bg-gradient-to-r from-cyan-500 to-blue-600'
        },
        {
          title: 'Подписка на кофе',
          subtitle: 'Свежий кофе каждый день',
          bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'menu', title: 'Меню', priceText: 'Напитки и десерты', iconName: 'menu' },
        { id: 'delivery', title: 'Доставка', priceText: 'За 15 минут', iconName: 'truck' },
        { id: 'subscription', title: 'Подписка', priceText: 'Кофе каждый день', iconName: 'repeat' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои заказы', iconName: 'user' }
      ]
    }
  },

  // === BEAUTY VARIANTS ===
  {
    id: 'beauty-2',
    title: 'LuxBeauty',
    description: 'Эксклюзивные beauty-процедуры премиум класса',
    category: 'Красота и Здоровье',
    image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=400',
    creator: 'WEB4TG',
    likes: '1.9k',
    badge: 'Luxury',
    badgeColor: 'bg-gold-500',
    home: {
      hero: {
        title: 'LuxBeauty',
        subtitle: 'Роскошь и красота в каждой детали',
        image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=400',
        bgClass: 'bg-gradient-to-r from-yellow-500 to-amber-600'
      },
      banners: [
        {
          title: 'Spa-ритуалы',
          subtitle: 'Эксклюзивные программы',
          image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=400',
          bgClass: 'bg-gradient-to-r from-pink-400 to-rose-500'
        },
        {
          title: 'Антивозрастные процедуры',
          subtitle: 'Современные технологии',
          bgClass: 'bg-gradient-to-r from-purple-400 to-pink-500'
        }
      ],
      services: [
        { id: 'procedures', title: 'Процедуры', priceText: 'Премиум уход', iconName: 'sparkles' },
        { id: 'consultation', title: 'Консультация', priceText: 'Персональный план', iconName: 'user-check' },
        { id: 'packages', title: 'Программы', priceText: 'Комплексный уход', iconName: 'package' },
        { id: 'profile', title: 'Профиль', priceText: 'История процедур', iconName: 'user' }
      ]
    }
  },
  {
    id: 'beauty-3',
    title: 'BeautyPoint',
    description: 'Доступная красота для каждой женщины',
    category: 'Красота и Здоровье',
    image: 'https://images.unsplash.com/photo-1457972385581-8bec0c7b0fbf?w=400',
    creator: 'WEB4TG',
    likes: '2.4k',
    badge: 'Доступно',
    badgeColor: 'bg-pink-500',
    home: {
      hero: {
        title: 'BeautyPoint',
        subtitle: 'Красота должна быть доступной',
        image: 'https://images.unsplash.com/photo-1457972385581-8bec0c7b0fbf?w=400',
        bgClass: 'bg-gradient-to-r from-pink-500 to-rose-600'
      },
      banners: [
        {
          title: 'Экспресс-услуги',
          subtitle: 'Быстро и качественно',
          image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400',
          bgClass: 'bg-gradient-to-r from-red-400 to-pink-500'
        },
        {
          title: 'Групповые скидки',
          subtitle: 'Приходи с подругами',
          bgClass: 'bg-gradient-to-r from-purple-400 to-pink-500'
        }
      ],
      services: [
        { id: 'express', title: 'Экспресс', priceText: 'Быстрые услуги', iconName: 'zap' },
        { id: 'packages', title: 'Пакеты', priceText: 'Выгодные предложения', iconName: 'gift' },
        { id: 'loyalty', title: 'Бонусы', priceText: 'Программа лояльности', iconName: 'star' },
        { id: 'profile', title: 'Профиль', priceText: 'Мой аккаунт', iconName: 'user' }
      ]
    }
  },

  // === ELECTRONICS VARIANTS ===
  {
    id: 'electronics-2',
    title: 'GadgetSpace',
    description: 'Инновационные гаджеты и умная техника',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400',
    creator: 'WEB4TG',
    likes: '3.2k',
    badge: 'Инновации',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'GadgetSpace',
        subtitle: 'Будущее в ваших руках',
        image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400',
        bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
      },
      banners: [
        {
          title: 'Smart Home',
          subtitle: 'Умный дом за один день',
          image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
        },
        {
          title: 'Pre-order',
          subtitle: 'Первым получи новинки',
          bgClass: 'bg-gradient-to-r from-purple-500 to-pink-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Умные устройства', iconName: 'smartphone' },
        { id: 'smart-home', title: 'Умный дом', priceText: 'Готовые решения', iconName: 'home' },
        { id: 'support', title: 'Поддержка', priceText: '24/7 помощь', iconName: 'headphones' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои устройства', iconName: 'user' }
      ]
    }
  },
  {
    id: 'electronics-3',
    title: 'TechMart',
    description: 'Проверенная техника с гарантией качества',
    category: 'Электронная коммерция',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400',
    creator: 'WEB4TG',
    likes: '2.1k',
    badge: 'Гарантия',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'TechMart',
        subtitle: 'Надежная техника для дома и офиса',
        image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
      },
      banners: [
        {
          title: 'Расширенная гарантия',
          subtitle: 'До 3 лет защиты',
          image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        },
        {
          title: 'Сервисный центр',
          subtitle: 'Быстрый и качественный ремонт',
          bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
        }
      ],
      services: [
        { id: 'catalog', title: 'Каталог', priceText: 'Проверенная техника', iconName: 'check-circle' },
        { id: 'warranty', title: 'Гарантия', priceText: 'Защита покупок', iconName: 'shield' },
        { id: 'service', title: 'Сервис', priceText: 'Ремонт техники', iconName: 'wrench' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои покупки', iconName: 'user' }
      ]
    }
  },

  // === BOOKSTORE VARIANTS ===
  {
    id: 'bookstore-2',
    title: 'Библиотека+',
    description: 'Академические и профессиональные издания',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400',
    creator: 'WEB4TG',
    likes: '1.6k',
    badge: 'Академия',
    badgeColor: 'bg-indigo-500',
    home: {
      hero: {
        title: 'Библиотека+',
        subtitle: 'Знания для профессионального роста',
        image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400',
        bgClass: 'bg-gradient-to-r from-indigo-500 to-blue-600'
      },
      banners: [
        {
          title: 'Научные издания',
          subtitle: 'Последние исследования',
          image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400',
          bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
        },
        {
          title: 'E-книги',
          subtitle: 'Цифровая библиотека',
          bgClass: 'bg-gradient-to-r from-cyan-500 to-teal-600'
        }
      ],
      services: [
        { id: 'academic', title: 'Академия', priceText: 'Научные книги', iconName: 'graduation-cap' },
        { id: 'digital', title: 'Цифровые', priceText: 'E-книги и аудио', iconName: 'headphones' },
        { id: 'research', title: 'Исследования', priceText: 'Базы данных', iconName: 'search' },
        { id: 'profile', title: 'Профиль', priceText: 'Моя библиотека', iconName: 'user' }
      ]
    }
  },
  {
    id: 'bookstore-3',
    title: 'ReadMore',
    description: 'Современная литература и бестселлеры',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400',
    creator: 'WEB4TG',
    likes: '2.8k',
    badge: 'Бестселлеры',
    badgeColor: 'bg-orange-500',
    home: {
      hero: {
        title: 'ReadMore',
        subtitle: 'Откройте новые миры через чтение',
        image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400',
        bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
      },
      banners: [
        {
          title: 'Книжный клуб',
          subtitle: 'Обсуждения и встречи',
          image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
          bgClass: 'bg-gradient-to-r from-red-500 to-pink-600'
        },
        {
          title: 'Подписка на новинки',
          subtitle: 'Первыми читайте хиты',
          bgClass: 'bg-gradient-to-r from-pink-500 to-purple-600'
        }
      ],
      services: [
        { id: 'bestsellers', title: 'Хиты', priceText: 'Популярные книги', iconName: 'trending-up' },
        { id: 'club', title: 'Клуб', priceText: 'Читательский клуб', iconName: 'users' },
        { id: 'subscription', title: 'Подписка', priceText: 'Новинки месяца', iconName: 'calendar' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои книги', iconName: 'user' }
      ]
    }
  },

  // === FLORIST VARIANTS ===
  {
    id: 'florist-2',
    title: 'BloomStudio',
    description: 'Дизайнерские композиции для особых моментов',
    category: 'Подарки и Цветы',
    image: 'https://images.unsplash.com/photo-1606923829579-0cb981a83e2e?w=400',
    creator: 'WEB4TG',
    likes: '1.3k',
    badge: 'Дизайн',
    badgeColor: 'bg-rose-500',
    home: {
      hero: {
        title: 'BloomStudio',
        subtitle: 'Искусство создавать красоту из цветов',
        image: 'https://images.unsplash.com/photo-1606923829579-0cb981a83e2e?w=400',
        bgClass: 'bg-gradient-to-r from-rose-500 to-pink-600'
      },
      banners: [
        {
          title: 'Эксклюзивные композиции',
          subtitle: 'Авторские работы флористов',
          image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=400',
          bgClass: 'bg-gradient-to-r from-pink-500 to-purple-600'
        },
        {
          title: 'Мастер-классы',
          subtitle: 'Научитесь создавать красоту',
          bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'custom', title: 'На заказ', priceText: 'Эксклюзивные букеты', iconName: 'palette' },
        { id: 'events', title: 'События', priceText: 'Оформление мероприятий', iconName: 'calendar' },
        { id: 'workshops', title: 'Мастер-классы', priceText: 'Обучение флористике', iconName: 'graduation-cap' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои заказы', iconName: 'user' }
      ]
    }
  },
  {
    id: 'florist-3',
    title: 'FlowerBox',
    description: 'Подписка на свежие цветы каждую неделю',
    category: 'Подарки и Цветы',
    image: 'https://images.unsplash.com/photo-1588584148491-eaa2c0a7b7d2?w=400',
    creator: 'WEB4TG',
    likes: '1.9k',
    badge: 'Подписка',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'FlowerBox',
        subtitle: 'Свежие цветы к вам домой каждую неделю',
        image: 'https://images.unsplash.com/photo-1588584148491-eaa2c0a7b7d2?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
      },
      banners: [
        {
          title: 'Еженедельная подписка',
          subtitle: 'Сюрприз каждую неделю',
          image: 'https://images.unsplash.com/photo-1463743153884-f2de3e8ecfef?w=400',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        },
        {
          title: 'Сезонные коллекции',
          subtitle: 'Цветы по временам года',
          bgClass: 'bg-gradient-to-r from-teal-500 to-cyan-600'
        }
      ],
      services: [
        { id: 'subscription', title: 'Подписка', priceText: 'Регулярная доставка', iconName: 'repeat' },
        { id: 'seasons', title: 'Сезоны', priceText: 'Тематические букеты', iconName: 'calendar' },
        { id: 'gifts', title: 'Подарки', priceText: 'Подарочные коробки', iconName: 'gift' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои подписки', iconName: 'user' }
      ]
    }
  },

  // === CARWASH VARIANTS ===
  {
    id: 'carwash-2',
    title: 'DetailPro',
    description: 'Профессиональная детейлинг студия',
    category: 'Автоуслуги',
    image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400',
    creator: 'WEB4TG',
    likes: '1.1k',
    badge: 'Детейлинг',
    badgeColor: 'bg-slate-500',
    home: {
      hero: {
        title: 'DetailPro',
        subtitle: 'Ваш автомобиль достоин идеального ухода',
        image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400',
        bgClass: 'bg-gradient-to-r from-slate-500 to-gray-600'
      },
      banners: [
        {
          title: 'Керамическое покрытие',
          subtitle: 'Защита на годы',
          image: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=400',
          bgClass: 'bg-gradient-to-r from-gray-500 to-zinc-600'
        },
        {
          title: 'Полировка кузова',
          subtitle: 'Идеальный блеск',
          bgClass: 'bg-gradient-to-r from-zinc-500 to-neutral-600'
        }
      ],
      services: [
        { id: 'detailing', title: 'Детейлинг', priceText: 'Полный уход', iconName: 'sparkles' },
        { id: 'coating', title: 'Покрытие', priceText: 'Керамическая защита', iconName: 'shield' },
        { id: 'interior', title: 'Салон', priceText: 'Химчистка салона', iconName: 'refresh-cw' },
        { id: 'profile', title: 'Профиль', priceText: 'История услуг', iconName: 'user' }
      ]
    }
  },
  {
    id: 'carwash-3',
    title: 'QuickWash',
    description: 'Экспресс мойка без очередей',
    category: 'Автоуслуги',
    image: 'https://images.unsplash.com/photo-1520340356756-2f14732f32d7?w=400',
    creator: 'WEB4TG',
    likes: '1.8k',
    badge: 'Экспресс',
    badgeColor: 'bg-yellow-500',
    home: {
      hero: {
        title: 'QuickWash',
        subtitle: 'Быстро, качественно, без очередей',
        image: 'https://images.unsplash.com/photo-1520340356756-2f14732f32d7?w=400',
        bgClass: 'bg-gradient-to-r from-yellow-500 to-orange-600'
      },
      banners: [
        {
          title: 'Мойка за 10 минут',
          subtitle: 'Самая быстрая в городе',
          image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
          bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
        },
        {
          title: 'Мобильное приложение',
          subtitle: 'Бронируй онлайн',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'express', title: 'Экспресс', priceText: 'Мойка за 10 минут', iconName: 'zap' },
        { id: 'booking', title: 'Бронь', priceText: 'Без очередей', iconName: 'clock' },
        { id: 'packages', title: 'Пакеты', priceText: 'Выгодные тарифы', iconName: 'package' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои визиты', iconName: 'user' }
      ]
    }
  },

  // === COURSES VARIANTS ===
  {
    id: 'courses-2',
    title: 'SkillForge',
    description: 'Практические навыки для IT карьеры',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400',
    creator: 'WEB4TG',
    likes: '3.8k',
    badge: 'IT Skills',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'SkillForge',
        subtitle: 'Освойте востребованные IT навыки',
        image: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400',
        bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
      },
      banners: [
        {
          title: 'Bootcamp программирования',
          subtitle: 'От новичка до middle за 6 месяцев',
          image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-purple-600'
        },
        {
          title: 'Гарантия трудоустройства',
          subtitle: 'Или вернем деньги',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        }
      ],
      services: [
        { id: 'bootcamp', title: 'Bootcamp', priceText: 'Интенсивное обучение', iconName: 'code' },
        { id: 'mentorship', title: 'Менторство', priceText: 'Персональный наставник', iconName: 'user-check' },
        { id: 'career', title: 'Карьера', priceText: 'Помощь в трудоустройстве', iconName: 'briefcase' },
        { id: 'profile', title: 'Профиль', priceText: 'Мое обучение', iconName: 'user' }
      ]
    }
  },
  {
    id: 'courses-3',
    title: 'CreativeHub',
    description: 'Творческие курсы и мастерские',
    category: 'Образование',
    image: 'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?w=400',
    creator: 'WEB4TG',
    likes: '2.4k',
    badge: 'Творчество',
    badgeColor: 'bg-pink-500',
    home: {
      hero: {
        title: 'CreativeHub',
        subtitle: 'Раскройте свой творческий потенциал',
        image: 'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?w=400',
        bgClass: 'bg-gradient-to-r from-pink-500 to-purple-600'
      },
      banners: [
        {
          title: 'Дизайн и искусство',
          subtitle: 'От скетча до профессии',
          image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=400',
          bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
        },
        {
          title: 'Творческие мастерские',
          subtitle: 'Живые уроки с мастерами',
          bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
        }
      ],
      services: [
        { id: 'design', title: 'Дизайн', priceText: 'Графика и UX/UI', iconName: 'palette' },
        { id: 'art', title: 'Искусство', priceText: 'Живопись и скульптура', iconName: 'brush' },
        { id: 'workshops', title: 'Мастерские', priceText: 'Практические занятия', iconName: 'users' },
        { id: 'profile', title: 'Профиль', priceText: 'Мое портфолио', iconName: 'user' }
      ]
    }
  },

  // === PHARMACY VARIANTS ===
  {
    id: 'pharmacy-2',
    title: 'HealthCare+',
    description: 'Телемедицина и консультации врачей',
    category: 'Здравоохранение',
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400',
    creator: 'WEB4TG',
    likes: '1.5k',
    badge: 'Телемед',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'HealthCare+',
        subtitle: 'Врач в смартфоне - здоровье под контролем',
        image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400',
        bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
      },
      banners: [
        {
          title: 'Онлайн консультации',
          subtitle: 'Врачи высшей категории',
          image: 'https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=400',
          bgClass: 'bg-gradient-to-r from-cyan-500 to-teal-600'
        },
        {
          title: 'Цифровые рецепты',
          subtitle: 'Без очередей в поликлинике',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        }
      ],
      services: [
        { id: 'consultation', title: 'Консультации', priceText: 'Врачи онлайн', iconName: 'video' },
        { id: 'prescription', title: 'Рецепты', priceText: 'Цифровые назначения', iconName: 'file-text' },
        { id: 'monitoring', title: 'Мониторинг', priceText: 'Контроль здоровья', iconName: 'activity' },
        { id: 'profile', title: 'Профиль', priceText: 'Медкарта', iconName: 'user' }
      ]
    }
  },
  {
    id: 'pharmacy-3',
    title: 'VitaExpress',
    description: 'Витамины и БАДы с персональным подбором',
    category: 'Здравоохранение',
    image: 'https://images.unsplash.com/photo-1550753619-ac5c58945bbf?w=400',
    creator: 'WEB4TG',
    likes: '1.2k',
    badge: 'Wellness',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'VitaExpress',
        subtitle: 'Персональные программы здоровья',
        image: 'https://images.unsplash.com/photo-1550753619-ac5c58945bbf?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-lime-600'
      },
      banners: [
        {
          title: 'Персональный подбор',
          subtitle: 'Анализ и рекомендации',
          image: 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=400',
          bgClass: 'bg-gradient-to-r from-lime-500 to-emerald-600'
        },
        {
          title: 'Подписка на витамины',
          subtitle: 'Регулярная доставка',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        }
      ],
      services: [
        { id: 'analysis', title: 'Анализ', priceText: 'Тест здоровья', iconName: 'clipboard' },
        { id: 'vitamins', title: 'Витамины', priceText: 'Персональный набор', iconName: 'pill' },
        { id: 'subscription', title: 'Подписка', priceText: 'Регулярная доставка', iconName: 'repeat' },
        { id: 'profile', title: 'Профиль', priceText: 'Мой план здоровья', iconName: 'user' }
      ]
    }
  },

  // === REALTY VARIANTS ===
  {
    id: 'realty-2',
    title: 'LuxEstate',
    description: 'Элитная недвижимость и инвестиции',
    category: 'Недвижимость',
    image: 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=400',
    creator: 'WEB4TG',
    likes: '2.7k',
    badge: 'Премиум',
    badgeColor: 'bg-yellow-500',
    home: {
      hero: {
        title: 'LuxEstate',
        subtitle: 'Инвестиции в элитную недвижимость',
        image: 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=400',
        bgClass: 'bg-gradient-to-r from-yellow-500 to-amber-600'
      },
      banners: [
        {
          title: 'Инвестиционные объекты',
          subtitle: 'Доходность от 15% годовых',
          image: 'https://images.unsplash.com/photo-1554469384-e58fac16e23a?w=400',
          bgClass: 'bg-gradient-to-r from-amber-500 to-orange-600'
        },
        {
          title: 'Консьерж-сервис',
          subtitle: 'Полное сопровождение сделки',
          bgClass: 'bg-gradient-to-r from-orange-500 to-red-600'
        }
      ],
      services: [
        { id: 'premium', title: 'Премиум', priceText: 'Элитные объекты', iconName: 'crown' },
        { id: 'investment', title: 'Инвестиции', priceText: 'Доходная недвижимость', iconName: 'trending-up' },
        { id: 'concierge', title: 'Консьерж', priceText: 'Полное сопровождение', iconName: 'user-check' },
        { id: 'profile', title: 'Профиль', priceText: 'Мой портфель', iconName: 'user' }
      ]
    }
  },
  {
    id: 'realty-3',
    title: 'MyHome',
    description: 'Доступное жилье для молодых семей',
    category: 'Недвижимость',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400',
    creator: 'WEB4TG',
    likes: '3.1k',
    badge: 'Доступно',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'MyHome',
        subtitle: 'Доступное жилье для каждой семьи',
        image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
      },
      banners: [
        {
          title: 'Ипотека от 1%',
          subtitle: 'Государственные программы',
          image: 'https://images.unsplash.com/photo-1520637836862-4d197d17c383?w=400',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        },
        {
          title: 'Первый взнос 0%',
          subtitle: 'Специальные условия',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'affordable', title: 'Доступное', priceText: 'Жилье по цене', iconName: 'home' },
        { id: 'mortgage', title: 'Ипотека', priceText: 'Льготные программы', iconName: 'percent' },
        { id: 'calculator', title: 'Калькулятор', priceText: 'Расчет платежей', iconName: 'calculator' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои заявки', iconName: 'user' }
      ]
    }
  },

  // === TAXI VARIANTS ===
  {
    id: 'taxi-2',
    title: 'PremiumRide',
    description: 'Премиум такси и трансферы',
    category: 'Транспорт',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400',
    creator: 'WEB4TG',
    likes: '1.8k',
    badge: 'Премиум',
    badgeColor: 'bg-slate-500',
    home: {
      hero: {
        title: 'PremiumRide',
        subtitle: 'Комфорт и престиж в каждой поездке',
        image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400',
        bgClass: 'bg-gradient-to-r from-slate-500 to-gray-600'
      },
      banners: [
        {
          title: 'Бизнес-класс',
          subtitle: 'Mercedes и BMW',
          image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400',
          bgClass: 'bg-gradient-to-r from-gray-500 to-zinc-600'
        },
        {
          title: 'Аэропорт трансферы',
          subtitle: 'Meet & Greet сервис',
          bgClass: 'bg-gradient-to-r from-zinc-500 to-neutral-600'
        }
      ],
      services: [
        { id: 'premium', title: 'Премиум', priceText: 'Автомобили класса люкс', iconName: 'star' },
        { id: 'airport', title: 'Аэропорт', priceText: 'Трансферы и встречи', iconName: 'plane' },
        { id: 'chauffeur', title: 'Водитель', priceText: 'Персональный шофер', iconName: 'user-check' },
        { id: 'profile', title: 'Профиль', priceText: 'VIP аккаунт', iconName: 'crown' }
      ]
    }
  },
  {
    id: 'taxi-3',
    title: 'CityMove',
    description: 'Городской каршеринг и микромобильность',
    category: 'Транспорт',
    image: 'https://images.unsplash.com/photo-1485291571150-772bcfc10da5?w=400',
    creator: 'WEB4TG',
    likes: '2.2k',
    badge: 'Эко',
    badgeColor: 'bg-green-500',
    home: {
      hero: {
        title: 'CityMove',
        subtitle: 'Умная мобильность для современного города',
        image: 'https://images.unsplash.com/photo-1485291571150-772bcfc10da5?w=400',
        bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
      },
      banners: [
        {
          title: 'Электро-самокаты',
          subtitle: 'Быстро и экологично',
          image: 'https://images.unsplash.com/photo-1544191696-15693072bde4?w=400',
          bgClass: 'bg-gradient-to-r from-emerald-500 to-teal-600'
        },
        {
          title: 'Каршеринг',
          subtitle: 'Авто на минуты',
          bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
        }
      ],
      services: [
        { id: 'scooters', title: 'Самокаты', priceText: 'Электро-транспорт', iconName: 'zap' },
        { id: 'carsharing', title: 'Каршеринг', priceText: 'Аренда авто', iconName: 'car' },
        { id: 'routes', title: 'Маршруты', priceText: 'Умная навигация', iconName: 'map' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои поездки', iconName: 'user' }
      ]
    }
  },

  // === BANKING VARIANTS ===
  {
    id: 'banking-2',
    title: 'CryptoBank',
    description: 'Банк для криптовалютных операций',
    category: 'Финансы',
    image: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=400',
    creator: 'WEB4TG',
    likes: '3.5k',
    badge: 'Crypto',
    badgeColor: 'bg-orange-500',
    home: {
      hero: {
        title: 'CryptoBank',
        subtitle: 'Мост между традиционными и цифровыми финансами',
        image: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=400',
        bgClass: 'bg-gradient-to-r from-orange-500 to-yellow-600'
      },
      banners: [
        {
          title: 'DeFi протоколы',
          subtitle: 'Доходность до 20% годовых',
          image: 'https://images.unsplash.com/photo-1640340434855-6084b1f4901c?w=400',
          bgClass: 'bg-gradient-to-r from-yellow-500 to-amber-600'
        },
        {
          title: 'NFT маркетплейс',
          subtitle: 'Торгуйте цифровыми активами',
          bgClass: 'bg-gradient-to-r from-purple-500 to-pink-600'
        }
      ],
      services: [
        { id: 'crypto', title: 'Криптовалюты', priceText: 'Торговля и хранение', iconName: 'bitcoin' },
        { id: 'defi', title: 'DeFi', priceText: 'Децентрализованные финансы', iconName: 'trending-up' },
        { id: 'nft', title: 'NFT', priceText: 'Цифровые коллекции', iconName: 'image' },
        { id: 'profile', title: 'Профиль', priceText: 'Криpto-портфель', iconName: 'user' }
      ]
    }
  },
  {
    id: 'banking-3',
    title: 'FamilyBank',
    description: 'Семейный банк с детскими картами',
    category: 'Финансы',
    image: 'https://images.unsplash.com/photo-1531973576160-7125cd663d86?w=400',
    creator: 'WEB4TG',
    likes: '2.9k',
    badge: 'Семейный',
    badgeColor: 'bg-pink-500',
    home: {
      hero: {
        title: 'FamilyBank',
        subtitle: 'Финансы всей семьи под контролем',
        image: 'https://images.unsplash.com/photo-1531973576160-7125cd663d86?w=400',
        bgClass: 'bg-gradient-to-r from-pink-500 to-rose-600'
      },
      banners: [
        {
          title: 'Детские карты',
          subtitle: 'Учим детей финансовой грамотности',
          image: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400',
          bgClass: 'bg-gradient-to-r from-rose-500 to-pink-600'
        },
        {
          title: 'Семейный бюджет',
          subtitle: 'Планирование и контроль трат',
          bgClass: 'bg-gradient-to-r from-blue-500 to-indigo-600'
        }
      ],
      services: [
        { id: 'family', title: 'Семья', priceText: 'Общий семейный счет', iconName: 'users' },
        { id: 'kids', title: 'Детям', priceText: 'Детские карты и копилки', iconName: 'baby' },
        { id: 'education', title: 'Обучение', priceText: 'Финансовая грамотность', iconName: 'graduation-cap' },
        { id: 'profile', title: 'Профиль', priceText: 'Семейный кабинет', iconName: 'home' }
      ]
    }
  },

  // === HOTEL VARIANTS ===
  {
    id: 'hotel-2',
    title: 'BoutiqueStays',
    description: 'Уникальные отели и дизайнерские апартаменты',
    category: 'Туризм',
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400',
    creator: 'WEB4TG',
    likes: '1.7k',
    badge: 'Дизайн',
    badgeColor: 'bg-purple-500',
    home: {
      hero: {
        title: 'BoutiqueStays',
        subtitle: 'Незабываемые впечатления в уникальных местах',
        image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400',
        bgClass: 'bg-gradient-to-r from-purple-500 to-indigo-600'
      },
      banners: [
        {
          title: 'Дизайнерские отели',
          subtitle: 'Авторские интерьеры',
          image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=400',
          bgClass: 'bg-gradient-to-r from-indigo-500 to-blue-600'
        },
        {
          title: 'Локальные впечатления',
          subtitle: 'Почувствуй дух места',
          bgClass: 'bg-gradient-to-r from-rose-500 to-pink-600'
        }
      ],
      services: [
        { id: 'boutique', title: 'Бутик-отели', priceText: 'Уникальные места', iconName: 'star' },
        { id: 'experiences', title: 'Впечатления', priceText: 'Локальные туры', iconName: 'map-pin' },
        { id: 'concierge', title: 'Консьерж', priceText: 'Персональный сервис', iconName: 'user-check' },
        { id: 'profile', title: 'Профиль', priceText: 'Мои путешествия', iconName: 'suitcase' }
      ]
    }
  },
  {
    id: 'hotel-3',
    title: 'WorkStay',
    description: 'Отели для деловых путешествий и удаленной работы',
    category: 'Туризм',
    image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=400',
    creator: 'WEB4TG',
    likes: '2.3k',
    badge: 'Бизнес',
    badgeColor: 'bg-blue-500',
    home: {
      hero: {
        title: 'WorkStay',
        subtitle: 'Идеальные условия для работы в путешествии',
        image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=400',
        bgClass: 'bg-gradient-to-r from-blue-500 to-cyan-600'
      },
      banners: [
        {
          title: 'Коворкинг в отеле',
          subtitle: 'Рабочие пространства',
          image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=400',
          bgClass: 'bg-gradient-to-r from-cyan-500 to-teal-600'
        },
        {
          title: 'Корпоративные тарифы',
          subtitle: 'Специальные условия для бизнеса',
          bgClass: 'bg-gradient-to-r from-green-500 to-emerald-600'
        }
      ],
      services: [
        { id: 'business', title: 'Бизнес', priceText: 'Отели для работы', iconName: 'briefcase' },
        { id: 'coworking', title: 'Коворкинг', priceText: 'Рабочие зоны', iconName: 'wifi' },
        { id: 'corporate', title: 'Корпоратив', priceText: 'Специальные тарифы', iconName: 'building' },
        { id: 'profile', title: 'Профиль', priceText: 'Бизнес-аккаунт', iconName: 'user' }
      ]
    }
  }
];
