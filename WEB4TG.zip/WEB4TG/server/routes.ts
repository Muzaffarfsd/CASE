import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import crypto from "crypto";

// Initialize Stripe only if secret key is available
let stripe: any = null;
if (process.env.STRIPE_SECRET_KEY) {
  const Stripe = require('stripe');
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2023-10-16",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Telegram Mini App routes
  const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

  // Telegram webhook endpoint
  app.post("/api/telegram/webhook", async (req, res) => {
    if (!TELEGRAM_BOT_TOKEN) {
      return res.status(503).json({ error: "Telegram bot not configured" });
    }

    try {
      const update = req.body;
      console.log('Telegram webhook:', JSON.stringify(update, null, 2));
      
      // Handle /start command
      if (update.message && update.message.text === '/start') {
        const chatId = update.message.chat.id;
        const webAppUrl = `https://${process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'}`;
        
        const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: '🎮 Добро пожаловать в WEB4TG!\n\n✨ Откройте наше портфолио Mini App чтобы посмотреть демо приложений',
            reply_markup: {
              inline_keyboard: [[
                {
                  text: '🚀 Открыть WEB4TG',
                  web_app: { url: webAppUrl }
                }
              ]]
            }
          })
        });

        if (!response.ok) {
          console.error('Telegram API error:', await response.text());
        }
      }
      
      res.json({ ok: true });
    } catch (error: any) {
      console.error('Telegram webhook error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Set Telegram bot commands
  app.post("/api/telegram/setup", async (req, res) => {
    if (!TELEGRAM_BOT_TOKEN) {
      return res.status(503).json({ error: "Telegram bot not configured" });
    }

    try {
      const webAppUrl = `https://${process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'}`;
      
      // Set bot commands
      const commandsResponse = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setMyCommands`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          commands: [
            {
              command: 'start',
              description: 'Открыть WEB4TG портфолио'
            }
          ]
        })
      });

      // Set webhook
      const webhookUrl = `https://${process.env.REPLIT_DEV_DOMAIN}/api/telegram/webhook`;
      const webhookResponse = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: webhookUrl
        })
      });

      const commandsResult = await commandsResponse.json();
      const webhookResult = await webhookResponse.json();
      
      res.json({
        success: true,
        webAppUrl,
        webhookUrl,
        commands: commandsResult,
        webhook: webhookResult
      });
    } catch (error: any) {
      console.error('Telegram setup error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get Telegram bot info
  app.get("/api/telegram/info", async (req, res) => {
    if (!TELEGRAM_BOT_TOKEN) {
      return res.status(503).json({ error: "Telegram bot not configured" });
    }

    try {
      const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe`);
      const botInfo = await response.json();
      
      res.json({
        bot: botInfo.result,
        webAppUrl: `https://${process.env.REPLIT_DEV_DOMAIN || 'localhost:5000'}`,
        configured: true
      });
    } catch (error: any) {
      console.error('Telegram info error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(503).json({ 
        error: "Payment processing is not available. Stripe not configured." 
      });
    }

    try {
      const { amount, project_name, features } = req.body;
      
      // Convert amount to cents (Stripe expects cents)
      const amountInCents = Math.round(amount * 100);
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: "rub", // Russian Ruble
        metadata: {
          project_name: project_name || 'WEB4TG Project',
          features: JSON.stringify(features || []),
          service: 'WEB4TG Development'
        },
        description: `WEB4TG Development: ${project_name}`,
      });
      
      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id
      });
    } catch (error: any) {
      console.error('Stripe payment intent creation error:', error);
      res.status(500).json({ 
        error: "Error creating payment intent: " + error.message 
      });
    }
  });

  // Payment success webhook (for future use)
  app.post("/api/payment-success", async (req, res) => {
    try {
      const { paymentIntentId, projectName, features } = req.body;
      
      // Here you would typically:
      // 1. Verify payment with Stripe
      // 2. Create project record in database
      // 3. Send confirmation email
      // 4. Trigger development workflow
      
      console.log('Payment successful for project:', projectName);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Payment success handling error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Health check for payment system
  app.get("/api/payment-status", (req, res) => {
    res.json({ 
      stripe_available: !!stripe,
      environment: process.env.NODE_ENV || 'development'
    });
  });

  // In-memory storage for user projects (in production use database)
  const userProjects = new Map<string, any[]>();

  // Получение проектов пользователя по Telegram ID
  app.get("/api/user-projects/:telegramId", (req, res) => {
    try {
      const { telegramId } = req.params;
      
      // Получаем проекты пользователя из памяти
      const projects = userProjects.get(telegramId) || [];
      
      res.json(projects);
    } catch (error) {
      console.error('Error fetching user projects:', error);
      res.status(500).json({ error: 'Failed to fetch projects' });
    }
  });

  // Создание нового проекта после оплаты
  app.post("/api/create-project", (req, res) => {
    try {
      const { telegramId, projectName, projectType, features, paymentIntentId } = req.body;
      
      // Создаем новый проект
      const newProject = {
        id: Date.now(),
        name: projectName || 'Новый проект',
        type: projectType || 'basic',
        status: 'Оплачено',
        progress: 10,
        createdAt: new Date().toISOString(),
        features: features || [],
        paymentIntentId,
        telegramUserId: telegramId
      };
      
      // Сохраняем проект
      const existingProjects = userProjects.get(telegramId) || [];
      existingProjects.push(newProject);
      userProjects.set(telegramId, existingProjects);
      
      console.log(`Created project for user ${telegramId}:`, projectName);
      res.json({ success: true, project: newProject });
    } catch (error) {
      console.error('Error creating project:', error);
      res.status(500).json({ error: 'Failed to create project' });
    }
  });

  // Обновление статуса проекта (для имитации прогресса разработки)
  app.post("/api/update-project-status", (req, res) => {
    try {
      const { telegramId, projectId, status, progress } = req.body;
      
      const projects = userProjects.get(telegramId) || [];
      const projectIndex = projects.findIndex(p => p.id === projectId);
      
      if (projectIndex !== -1) {
        projects[projectIndex].status = status || projects[projectIndex].status;
        projects[projectIndex].progress = progress !== undefined ? progress : projects[projectIndex].progress;
        projects[projectIndex].updatedAt = new Date().toISOString();
        
        userProjects.set(telegramId, projects);
        
        res.json({ success: true, project: projects[projectIndex] });
      } else {
        res.status(404).json({ error: 'Project not found' });
      }
    } catch (error) {
      console.error('Error updating project status:', error);
      res.status(500).json({ error: 'Failed to update project' });
    }
  });

  // Добавление тестовых данных (для демонстрации)
  app.post("/api/init-demo-projects/:telegramId", (req, res) => {
    try {
      const { telegramId } = req.params;
      
      const demoProjects = [
        {
          id: 1001,
          name: 'Магазин одежды',
          type: 'ecommerce',
          status: 'В разработке',
          progress: 75,
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          features: ['catalog', 'cart', 'payment'],
          telegramUserId: telegramId
        },
        {
          id: 1002,
          name: 'Ресторан доставки',
          type: 'restaurant',
          status: 'Готово',
          progress: 100,
          createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
          features: ['menu', 'orders', 'delivery'],
          telegramUserId: telegramId
        },
        {
          id: 1003,
          name: 'Фитнес-клуб',
          type: 'fitness',
          status: 'Планирование',
          progress: 25,
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          features: ['booking', 'memberships'],
          telegramUserId: telegramId
        }
      ];
      
      userProjects.set(telegramId, demoProjects);
      
      res.json({ success: true, projects: demoProjects });
    } catch (error) {
      console.error('Error initializing demo projects:', error);
      res.status(500).json({ error: 'Failed to initialize demo projects' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
